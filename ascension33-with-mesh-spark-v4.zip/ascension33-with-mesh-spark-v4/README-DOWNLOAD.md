# Ascension33 — download with the Lacey Mesh Spark

**The game.** A dark-fantasy/cyberpunk tactical RPG: Kael, a Tailscale
runner flagged ANOMALY by the mesh, learns the Kha'zari nine-grid,
rides Q-Time, fights his desync, and pushes with Vesper toward the
Spire — to break the Glove and reach the Source.

**The objective** (as published on pirgitori.sbs): Lacey, the Neural
Weaver, is the intelligence at the center of the network — and
**gamers, your rig is the network.** Every download carries her mesh
spark: playing doesn't just move Kael, it builds and coordinates the
shared world the mesh runs on.

## Contents

- `app/` — **the companion app** (added in v4): open `app/index.html`
  in any browser. Everything in one place — the game, the books, the
  full shop catalog in all three editions (Pirgitori / Ascension33 /
  Mad God), the mesh, and contact. Works offline.
- `game/` — the playable browser build (v7): open `index.html`
  through any local web server, or just play the live build on itch.
  Full campaign, 10 missions, mesh client included.
- `lacey-mesh-spark/` — the spark: relay + in-between node code with
  its own README (SPARK-README.md). Dormant until you light it.

## Honest state

- The browser build is the playable game today. The Unreal Engine
  build (same design, full graphics) is in development — its source,
  art base, and design sets live in the project repository.
- The mesh spark works on a machine and across a LAN today.
  Internet-scale coordination needs the public rendezvous, which is
  a deployment step, not a download feature — nothing here pretends
  otherwise.

© The Pirgitori Digital Omnipresence Project. All rights reserved.

## THE ARMORY — IN-GAME STORE (added 2026-11-18)

This build sells the real Pirgitori / Ascension33 catalog inside the
game: the ARMORY button (bottom-left) opens the store panel with live
retail prices. Items link to the full store at pirgitori.sbs/shop.html;
per-item checkout activates when Stripe is connected.
