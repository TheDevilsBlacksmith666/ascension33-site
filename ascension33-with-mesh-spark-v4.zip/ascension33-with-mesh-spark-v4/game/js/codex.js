/* =====================================================================
 * ASCENSION33 — GAME-LEVEL CODEX (additive layer)
 *
 * Follows the mesh.js pattern: wraps window.showStory and
 * window.finishMission additively, creates its own DOM, uses its own
 * localStorage key (asc33_codex), and works fully offline.
 *
 * BOUNDARY, stated plainly: each entry below is a clue and a book
 * pointer only, never an answer. Finding an entry, or collecting all
 * ten, does NOT solve the Codex, is NOT verification, and is NOT
 * traction. No answer text, no fragment quotation, and no assembled
 * answer exists in this file. No offer of any kind is made here.
 * No network traffic is sent from this file.
 * ===================================================================== */
(function(){
'use strict';

var LS_KEY = 'asc33_codex';

/* ---------- canonical table: mission index 0-9 -> Codex entry I-X ----------
 * Title, pointer line, and book pointer copied exactly from the
 * approved game-level Codex draft (2026-10-25), section 1. */
var ENTRIES = [
  { roman:'I',   title:'ANOMALY',              pointer:'The mesh has a word for you, and it is not the name you were given.', book:'Book 1, Chapter 8.' },
  { roman:'II',  title:'THIRTY-THREE TIMES',   pointer:'Time stutters, and the stutter repeats. Count the returns, not the days.', book:'Book 1, Chapter 33.' },
  { roman:'III', title:'18.98 HERTZ',          pointer:'Listen, do not only read. Something here is felt before it is heard.', book:'Book 3, Chapter 5.' },
  { roman:'IV',  title:'THE RESONANCE',        pointer:'A place can go quiet without a battle. Ask what made it quiet.', book:'Book 2, Chapter 5.' },
  { roman:'V',   title:'DESYNC',               pointer:'Your meter is not only a meter. Watch what it does to the story you tell.', book:'Book 1, Chapter 7.' },
  { roman:'VI',  title:"THE RU'YA ANCHOR",     pointer:'What holds when everything else drifts?', book:'Book 1, Chapter 11.' },
  { roman:'VII', title:'THE GLOVE',            pointer:'The city is watching, and it is wearing what it watched.', book:'Book 2, Chapter 13.' },
  { roman:'VIII',title:'THE SPIRE COUNTS SOULS', pointer:'A tower keeps a count that will not close. Ask why it will not close.', book:'Book 2, Chapter 31.' },
  { roman:'IX',  title:'PIRGITORI',            pointer:'Past the boundary, the map stops. Ask what lies past the map.', book:'Book 3, Chapter 10.' },
  { roman:'X',   title:'THE SOURCE',           pointer:'The end of the line is not a throne. Ask what the line is for.', book:'Book 3, Chapter 32.' }
];

/* ---------- tiny utils ---------- */
function $(id){ return document.getElementById(id); }
function lsGet(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }
function lsSet(k,v){ try{ localStorage.setItem(k,v); }catch(e){} }
function el(tag, cls, text){
  var d = document.createElement(tag);
  if(cls) d.className = cls;
  if(text != null) d.textContent = text;
  return d;
}

/* ---------- collection (local only; a new game does NOT clear it) ---------- */
function getFound(){
  try{
    var v = JSON.parse(lsGet(LS_KEY) || '[]');
    return Array.isArray(v) ? v : [];
  }catch(e){ return []; }
}
function isFound(idx){
  return getFound().some(function(e){ return e && e.missionIdx === idx; });
}
function markFound(idx){
  if(typeof idx !== 'number' || idx < 0 || idx >= ENTRIES.length) return;
  var list = getFound();
  if(list.some(function(e){ return e && e.missionIdx === idx; })) return;
  list.push({ missionIdx: idx, foundAt: Date.now() });
  lsSet(LS_KEY, JSON.stringify(list));
  updateButtonLabel();
}
function resetCollection(){
  try{ localStorage.removeItem(LS_KEY); }catch(e){}
  updateButtonLabel();
  renderPanel();
}

/* ---------- story-screen block (after the field-brief area) ---------- */
function renderStoryBlock(){
  var old = $('codex-story-block');
  if(old && old.parentNode) old.parentNode.removeChild(old);
  var tip = $('story-tip');
  if(!tip || !tip.parentNode) return;
  var idx = (typeof App !== 'undefined') ? App.missionIdx : -1;
  if(typeof idx !== 'number' || idx < 0 || idx >= ENTRIES.length) return;
  var e = ENTRIES[idx];
  var block = el('div', 'codex-story-block');
  block.id = 'codex-story-block';
  block.style.cssText = 'margin-top:14px;padding:12px 14px;border:1px solid var(--line);border-left:3px solid var(--cyan);background:rgba(0,240,255,0.05);';
  var h = el('div', null, 'CODEX \u2014 ' + e.roman + ' \u2014 ' + e.title);
  h.style.cssText = 'font-family:Orbitron,monospace;font-size:12px;letter-spacing:.15em;color:var(--cyan);margin-bottom:6px;';
  var p = el('div', null, e.pointer);
  p.style.cssText = 'font-size:15px;line-height:1.5;';
  var b = el('div', null, 'Book pointer: ' + e.book);
  b.style.cssText = 'font-size:13px;color:var(--dim);margin-top:6px;font-family:"Share Tech Mono",monospace;';
  block.appendChild(h); block.appendChild(p); block.appendChild(b);
  tip.parentNode.insertBefore(block, tip.nextSibling);
}

/* ---------- title-screen button + panel ---------- */
var panel, panelBody, codexBtn;

function updateButtonLabel(){
  if(!codexBtn) return;
  codexBtn.textContent = 'CODEX \u00b7 ' + getFound().length + '/10';
}

function renderPanel(){
  if(!panelBody) return;
  panelBody.innerHTML = '';
  ENTRIES.forEach(function(e, i){
    var row = el('div');
    row.style.cssText = 'padding:8px 0;border-bottom:1px solid var(--line);font-size:15px;line-height:1.5;';
    if(isFound(i)){
      var head = el('div', null, 'CODEX \u2014 ' + e.roman + ' \u2014 ' + e.title);
      head.style.cssText = 'font-family:Orbitron,monospace;font-size:12px;letter-spacing:.12em;color:var(--cyan);';
      var bp = el('div', null, 'Book pointer: ' + e.book);
      bp.style.cssText = 'font-size:13px;color:var(--dim);font-family:"Share Tech Mono",monospace;';
      row.appendChild(head); row.appendChild(bp);
    } else {
      var locked = el('div', null, e.roman + ' \u2014 LOCKED');
      locked.style.cssText = 'font-family:Orbitron,monospace;font-size:12px;letter-spacing:.12em;color:var(--dim);';
      row.appendChild(locked);
    }
    panelBody.appendChild(row);
  });
  updateButtonLabel();
}

function buildTitleUi(){
  var titleWrap = document.querySelector('#scr-title .title-wrap');
  if(!titleWrap) return;
  var btnRow = titleWrap.querySelector('div:last-child');
  codexBtn = el('button', 'btn', 'CODEX \u00b7 0/10');
  codexBtn.id = 'btn-codex';
  if(btnRow) btnRow.appendChild(codexBtn); else titleWrap.appendChild(codexBtn);

  panel = el('div');
  panel.id = 'codex-panel';
  panel.style.cssText = 'display:none;max-width:640px;margin:22px auto 0;text-align:left;padding:18px 20px;border:1px solid var(--line);background:var(--panel);';
  var head = el('div');
  head.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;';
  var ht = el('div', null, 'CODEX COLLECTION');
  ht.style.cssText = 'font-family:Orbitron,monospace;letter-spacing:.15em;color:#fff;';
  var close = el('button', 'btn', '\u2715');
  close.style.cssText = 'padding:6px 14px;margin:0;';
  close.onclick = function(){ panel.style.display = 'none'; };
  head.appendChild(ht); head.appendChild(close);
  panel.appendChild(head);

  var note = el('div', null, 'Found entries are collected here. Collecting entries is not solving the Codex.');
  note.style.cssText = 'font-size:13px;color:var(--dim);margin-bottom:12px;line-height:1.5;';
  panel.appendChild(note);

  panelBody = el('div');
  panel.appendChild(panelBody);

  var foot = el('div');
  foot.style.cssText = 'margin-top:14px;padding-top:12px;border-top:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:12px;';
  var link = el('a', null, 'pirgitori.sbs');
  link.href = 'https://pirgitori.sbs';
  link.target = '_blank';
  link.rel = 'noopener';
  link.style.cssText = 'color:var(--cyan);font-family:"Share Tech Mono",monospace;font-size:13px;';
  var reset = el('button', 'btn', 'Reset collection');
  reset.style.cssText = 'padding:8px 16px;margin:0;';
  reset.onclick = function(){
    if(window.confirm('Reset the Codex collection? Found entries will be cleared. Your game save is not affected.')) resetCollection();
  };
  foot.appendChild(link); foot.appendChild(reset);
  panel.appendChild(foot);

  titleWrap.appendChild(panel);
  codexBtn.onclick = function(){
    var open = panel.style.display === 'none';
    if(open) renderPanel();
    panel.style.display = open ? 'block' : 'none';
  };
  updateButtonLabel();
}

/* ---------- additive hooks into game (no engine/ui edits) ---------- */
function installHooks(){
  if(typeof window.finishMission === 'function'){
    var _fm = window.finishMission;
    window.finishMission = function(){
      try{
        if(typeof App !== 'undefined' && App.combat && App.combat.over === 'win'){
          markFound(App.missionIdx);
        }
      }catch(e){}
      try{ _fm(); }catch(e){}
    };
  }
  if(typeof window.showStory === 'function'){
    var _ss = window.showStory;
    window.showStory = function(){
      _ss();
      try{ renderStoryBlock(); }catch(e){}
    };
  }
}

/* ---------- boot ---------- */
document.addEventListener('DOMContentLoaded', function(){
  buildTitleUi();
  installHooks();
});
window.Asc33Codex = { entries: ENTRIES, getFound: getFound, isFound: isFound, markFound: markFound, renderPanel: renderPanel };
})();
