"""Python port of the Pirgitori onion layer — Step 6 client side.

This module implements the onion wire format specified in
~/workspace/pirgitori-mesh/relay/PROTOCOL.md ("Onion routing
(Step 6)") and mirrors the reference implementation
relay/onion.js behavior-for-behavior: same curve, same HKDF,
same layer JSON. A layer built here peels in onion.js and vice
versa — that interop is proven by test_onion_python.py, not
assumed.

Construction (per layer):
- Keys: P-256 (SECP256R1) ECDH. A relay's onion keypair is
  EPHEMERAL per run; the sender generates a FRESH ephemeral
  keypair per layer per message.
- Public form: the raw uncompressed point, 65 bytes
  0x04 || X || Y, lowercase hex (130 chars) — in this library,
  Encoding.X962 / PublicFormat.UncompressedPoint.
- Layer key: ECDH(sender ephemeral private, recipient onion
  public) -> HKDF-SHA256 (salt empty, info
  "pirgitori-onion-v1", 32 bytes) -> AES-256-GCM key.
- Layer JSON (all binary as hex):
    {"v": 1, "eph": <sender ephemeral pubkey hex>,
     "iv": <12-byte hex>, "tag": <16-byte hex>, "ct": <hex>}
- Layer plaintext (JSON): {"next": <relay id | node id |
  "registry">, "body": <inner layer object>} for every layer
  except that the INNERMOST layer's body is the final payload
  envelope {"final": true, "to": <destination>,
  "payload": <string>} and its "next" is that destination.

Uses the `cryptography` library (the same library the node's
Ed25519 identity code already depends on).
"""
import json
import os
import re
import urllib.request

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ONION_HKDF_INFO = b"pirgitori-onion-v1"
_ONION_PUB_HEX_RE = re.compile(r"^[0-9a-f]{130}$")
_HEX_RE = re.compile(r"^[0-9a-f]*$")


# ---- P-256 public key <-> raw uncompressed point hex -------------------
def public_hex_from_key(public_key):
    raw = public_key.public_bytes(
        serialization.Encoding.X962,
        serialization.PublicFormat.UncompressedPoint)
    if len(raw) != 65 or raw[0] != 0x04:
        raise ValueError("not a P-256 uncompressed point")
    return raw.hex()


def is_onion_pub_hex(s):
    return (isinstance(s, str) and bool(_ONION_PUB_HEX_RE.match(s))
            and s.startswith("04"))


def public_key_from_hex(hex_str):
    if not is_onion_pub_hex(hex_str):
        raise ValueError("invalid P-256 onion public key hex")
    raw = bytes.fromhex(hex_str)
    x = int.from_bytes(raw[1:33], "big")
    y = int.from_bytes(raw[33:65], "big")
    numbers = ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1())
    return numbers.public_key()


# ---- Key generation ------------------------------------------------------
# Returns {"private_key", "public_key", "public_hex"}. The private
# key is a cryptography key object: it stays in the caller's
# memory and is never serialized by this module.
def generate_onion_keys():
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_key = private_key.public_key()
    return {
        "private_key": private_key,
        "public_key": public_key,
        "public_hex": public_hex_from_key(public_key),
    }


# ---- Per-layer key derivation ---------------------------------------------
def _derive_layer_key(my_private_key, peer_pub_hex):
    peer_public = public_key_from_hex(peer_pub_hex)
    secret = my_private_key.exchange(ec.ECDH(), peer_public)
    return HKDF(
        algorithm=hashes.SHA256(), length=32, salt=b"",
        info=ONION_HKDF_INFO).derive(secret)


# ---- One layer -------------------------------------------------------------
def _encrypt_layer(plaintext_str, recipient_pub_hex):
    eph = generate_onion_keys()  # fresh ephemeral per layer
    key = _derive_layer_key(eph["private_key"], recipient_pub_hex)
    iv = os.urandom(12)
    # cryptography's AESGCM appends the 16-byte tag to the
    # ciphertext; the wire format carries them separately.
    ct_and_tag = AESGCM(key).encrypt(
        iv, plaintext_str.encode("utf-8"), None)
    ct, tag = ct_and_tag[:-16], ct_and_tag[-16:]
    return {
        "v": 1,
        "eph": eph["public_hex"],
        "iv": iv.hex(),
        "tag": tag.hex(),
        "ct": ct.hex(),
    }


def _js_json(obj):
    """JSON.stringify-compatible encoding: compact separators,
    UTF-8 (no \\uXXXX escaping of non-ASCII), insertion key order.
    Matches the bytes onion.js encrypts for the same object."""
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=False)


def _path_entry(entry):
    """A path entry is a (relay_id, onion_pub_hex) pair; a dict
    with relayId/onionPubHex keys (the onion.js shape) is also
    accepted."""
    if isinstance(entry, dict):
        return entry.get("relayId"), entry.get("onionPubHex")
    relay_id, pub_hex = entry
    return relay_id, pub_hex


def build_onion(payload, to, path):
    """build_onion(payload, to, path) -> the outermost layer dict.

    path is a list of (relay_id, onion_pub_hex) in entry -> exit
    order. The sender generates a fresh ephemeral keypair per
    layer (inside _encrypt_layer). The innermost layer's "next"
    is the destination itself and its body is the final payload
    envelope; every other layer's "next" is the following
    relay's id and its body is the next layer in.
    """
    if not isinstance(payload, str):
        raise ValueError("payload must be a string")
    if not isinstance(to, str) or not to:
        raise ValueError("to must be a destination id string")
    if not isinstance(path, (list, tuple)) or len(path) == 0:
        raise ValueError(
            "path must be a non-empty list of (relay_id, onion_pub_hex)")
    hops = [_path_entry(entry) for entry in path]
    for relay_id, pub_hex in hops:
        if not isinstance(relay_id, str) or not is_onion_pub_hex(pub_hex):
            raise ValueError(
                "each path entry needs (relay_id, onion_pub_hex)")
    body = {"final": True, "to": to, "payload": payload}
    layer = None
    for i in range(len(hops) - 1, -1, -1):
        next_id = to if i == len(hops) - 1 else hops[i + 1][0]
        layer = _encrypt_layer(
            _js_json({"next": next_id, "body": body}), hops[i][1])
        body = layer
    return layer


def peel_onion(layer, private_key):
    """peel_onion(layer, private_key) -> the parsed plaintext
    object ({"next", "body"}). Raises on ANY failure: malformed
    layer, bad ephemeral key, AEAD tag mismatch (wrong key or
    tampered ciphertext), non-JSON plaintext. Callers treat a
    raise as "drop silently" — a relay must never act on an
    unpeeled layer."""
    if not isinstance(layer, dict) or layer.get("v") != 1:
        raise ValueError("not an onion layer")
    if not is_onion_pub_hex(layer.get("eph")):
        raise ValueError("bad ephemeral key in onion layer")
    iv_hex = layer.get("iv")
    if not isinstance(iv_hex, str) or not re.match(r"^[0-9a-f]{24}$", iv_hex):
        raise ValueError("bad iv in onion layer")
    tag_hex = layer.get("tag")
    if (not isinstance(tag_hex, str)
            or not re.match(r"^[0-9a-f]{32}$", tag_hex)):
        raise ValueError("bad tag in onion layer")
    ct_hex = layer.get("ct")
    if (not isinstance(ct_hex, str) or not _HEX_RE.match(ct_hex)
            or len(ct_hex) % 2 != 0):
        raise ValueError("bad ciphertext in onion layer")
    key = _derive_layer_key(private_key, layer["eph"])
    pt = AESGCM(key).decrypt(
        bytes.fromhex(iv_hex),
        bytes.fromhex(ct_hex) + bytes.fromhex(tag_hex),
        None)  # raises InvalidTag on AEAD failure — by design
    return json.loads(pt.decode("utf-8"))


# ---- Relay key discovery ---------------------------------------------------
def fetch_onion_key(relay_url, timeout=5.0, ssl_context=None):
    """GET /onion-key from a relay's HTTP port (the same port as
    its WebSocket listener). relay_url is the ws:// or wss://
    URL the node would dial; the scheme is mapped to http/https
    and any path is dropped. Returns {"relayId", "onionPub"} —
    the only two fields the endpoint serves. Raises on any
    transport or shape failure; callers decide the fallback."""
    url = relay_url
    if url.startswith("ws://"):
        url = "http://" + url[len("ws://"):]
    elif url.startswith("wss://"):
        url = "https://" + url[len("wss://"):]
    authority = url.split("://", 1)[-1].split("/", 1)[0]
    scheme = url.split("://", 1)[0]
    req = urllib.request.Request(f"{scheme}://{authority}/onion-key")
    with urllib.request.urlopen(
            req, timeout=timeout, context=ssl_context) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if (not isinstance(data, dict)
            or not isinstance(data.get("relayId"), str)
            or not is_onion_pub_hex(data.get("onionPub"))):
        raise ValueError(f"malformed /onion-key reply from {relay_url}")
    return {"relayId": data["relayId"], "onionPub": data["onionPub"]}
