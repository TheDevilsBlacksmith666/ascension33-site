"""Identity files for mesh-auth-v1 (2026-11-06).

An identity file binds a node id to one Ed25519 keypair, persistently.
It is the file the ghost owns and the node reads (except for the
single rotation rewrite, which is atomic).

Format v2 (extends the ghost's v1 file):

    {"version": 2,
     "node_id": "ghost-<12 hex>" | "node-<12 hex>" | ...,
     "public_key_hex": "<64 hex>",
     "private_key_hex": "<64 hex>",
     "previous_key": null
       | {"public_key_hex": "<64 hex>",
          "private_key_hex": "<64 hex>",
          "expires_at": <ms epoch> | null},
     "rotated_at": null | "<ISO timestamp>",
     "rotation_pending": false}

A v1 file (no previous_key / rotated_at / rotation_pending fields)
loads as if previous_key were null — the ghost's existing identity
migrates by reading, not by re-issuing.

Validation is fail-fast: a mismatched identity is exactly the
impersonation shape auth v1 exists to prevent.

- public_key_hex must be the public key of private_key_hex.
- With no rotation yet (previous_key is null), node_id must equal
  the id derived from the current public key: the file's own prefix
  plus the first 12 hex chars of the public key.
- After a rotation the node id is PINNED (design §6: rotation
  preserves the node id, so the current key no longer derives it).
  The derive check then cannot apply to the current key, and it
  cannot apply to the previous key either after a second rotation
  (only the immediately previous key is kept). In the pinned case
  the file's node_id is validated structurally (registry id shape,
  12 trailing hex chars), and the registry's key-mismatch rule is
  the live enforcement: a file whose key does not match the
  registry's key for that id fails at hello with key-mismatch.

Rotation-pending state (design §6, lost-ack recovery): the node
writes the new key into the file as current, the old key as
previous, with rotation_pending=true, BEFORE sending key_rotate.
If the ack never arrives, the file still holds both keys, and the
next connect tries the new key first, then the old key. On ack the
node confirms the rotation (previous.expires_at from the server,
rotation_pending=false).
"""
import json
import os
import re
import time
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
)
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)

_NODE_ID_RE = re.compile(r"^[a-zA-Z0-9-]{4,64}$")
_HEX_64_RE = re.compile(r"^[0-9a-f]{64}$")
_HEX_12_RE = re.compile(r"^[0-9a-f]{12}$")


def _now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def public_key_hex(private_key):
    """Raw 32-byte public key of a private key, as 64 hex chars."""
    return private_key.public_key().public_bytes(
        Encoding.Raw, PublicFormat.Raw).hex()


def derive_node_id(public_key_hex, prefix):
    """Key-derived node id: prefix + first 12 hex of the public key."""
    return prefix + public_key_hex[:12]


def _private_hex(private_key):
    return private_key.private_bytes(
        Encoding.Raw, PrivateFormat.Raw, NoEncryption()).hex()


def _ensure_private_dir(path):
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass


def _write_atomic(path, payload):
    """Write the identity file atomically (temp + os.replace, 0600)."""
    path = Path(path)
    _ensure_private_dir(path.parent)
    tmp_path = path.with_name("." + path.name + ".tmp")
    tmp_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.chmod(tmp_path, 0o600)
    os.replace(tmp_path, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _key_dict(private_key, expires_at=None):
    return {
        "public_key_hex": public_key_hex(private_key),
        "private_key_hex": _private_hex(private_key),
        "expires_at": expires_at,
    }


def _load_key_dict(data, what):
    """Parse a stored key dict into {public_key_hex, private_key}.

    Raises ValueError on a malformed key. The private key object is
    returned so callers never handle raw private bytes themselves.
    """
    if not isinstance(data, dict):
        raise ValueError(f"{what} is not an object")
    pub = data.get("public_key_hex")
    priv = data.get("private_key_hex")
    if not isinstance(pub, str) or not _HEX_64_RE.match(pub):
        raise ValueError(f"{what} public_key_hex is not 64 hex chars")
    if not isinstance(priv, str) or not _HEX_64_RE.match(priv):
        raise ValueError(f"{what} private_key_hex is not 64 hex chars")
    try:
        private_key = Ed25519PrivateKey.from_private_bytes(
            bytes.fromhex(priv))
    except ValueError as exc:
        raise ValueError(f"{what} private key is not usable: {exc}") from exc
    if public_key_hex(private_key) != pub:
        raise ValueError(
            f"{what} public_key_hex does not match its private key")
    return {"public_key_hex": pub, "private_key": private_key}


def create_identity_file(path, prefix="node-"):
    """Create a fresh v2 identity file and return the loaded dict.

    The node id is derived from the fresh key (prefix + first 12
    hex). The file is written atomically with mode 0600 in a 0700
    directory. Raises ValueError if a file already exists at path —
    creation must never silently overwrite an existing identity.
    """
    path = Path(path)
    if path.exists():
        raise ValueError(
            f"identity file {path} already exists; refusing to overwrite")
    private_key = Ed25519PrivateKey.generate()
    pub_hex = public_key_hex(private_key)
    payload = {
        "version": 2,
        "node_id": derive_node_id(pub_hex, prefix),
        "public_key_hex": pub_hex,
        "private_key_hex": _private_hex(private_key),
        "previous_key": None,
        "rotated_at": None,
        "rotation_pending": False,
    }
    _write_atomic(path, payload)
    return load_identity_file(path)


def load_identity_file(path):
    """Load and validate an identity file (v1 or v2).

    Returns {"version", "node_id", "public_key_hex",
    "private_key" (Ed25519PrivateKey), "previous_key" (None or
    {"public_key_hex", "private_key", "expires_at"}), "rotated_at",
    "rotation_pending" (bool)}.

    Raises FileNotFoundError when the file is missing and
    ValueError on anything malformed or mismatched — including a
    node_id that does not derive from the current key when no
    rotation has happened.
    """
    path = Path(path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise
    except (OSError, ValueError) as exc:
        raise ValueError(
            f"identity file {path} cannot be read as JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"identity file {path} is not a JSON object")
    version = data.get("version", 1)
    if version not in (1, 2):
        raise ValueError(
            f"identity file {path} has unsupported version {version!r}")
    node_id = data.get("node_id")
    if not isinstance(node_id, str) or not _NODE_ID_RE.match(node_id):
        raise ValueError(
            f"identity file {path} has an unusable node_id {node_id!r}")
    current = _load_key_dict(
        {"public_key_hex": data.get("public_key_hex"),
         "private_key_hex": data.get("private_key_hex")},
        "identity file current key")
    previous = None
    previous_raw = data.get("previous_key")
    if previous_raw is not None:
        previous = _load_key_dict(previous_raw, "identity file previous key")
        expires_at = previous_raw.get("expires_at")
        if expires_at is not None and (
                isinstance(expires_at, bool)
                or not isinstance(expires_at, (int, float))
                or expires_at < 0):
            raise ValueError(
                "identity file previous key expires_at is not a "
                "non-negative number")
        previous["expires_at"] = expires_at
    rotated_at = data.get("rotated_at")
    if rotated_at is not None and not isinstance(rotated_at, str):
        raise ValueError("identity file rotated_at is not a string")
    rotation_pending = data.get("rotation_pending", False)
    if not isinstance(rotation_pending, bool):
        raise ValueError("identity file rotation_pending is not a boolean")
    if previous is None:
        # No rotation yet: the node id must derive from the current
        # key. The prefix is the file's own (everything before the
        # trailing 12 hex chars).
        if len(node_id) <= 12 or node_id[:-12] == "":
            raise ValueError(
                f"identity file {path}: node_id {node_id!r} is too short "
                "to be key-derived")
        if node_id != node_id[:-12] + current["public_key_hex"][:12]:
            raise ValueError(
                f"identity file {path}: node_id {node_id!r} does not "
                "derive from its public key "
                f"({current['public_key_hex'][:12]}); refusing to run "
                "under a mismatched id")
    else:
        # Pinned id (a rotation happened): structural check only.
        if not _HEX_12_RE.match(node_id[-12:]):
            raise ValueError(
                f"identity file {path}: pinned node_id {node_id!r} does "
                "not end in 12 hex chars")
    return {
        "version": version,
        "node_id": node_id,
        "public_key_hex": current["public_key_hex"],
        "private_key": current["private_key"],
        "previous_key": previous,
        "rotated_at": rotated_at,
        "rotation_pending": rotation_pending,
    }


def _payload_from_loaded(loaded):
    """Serialize a loaded identity dict back to file format."""
    previous = None
    if loaded["previous_key"] is not None:
        prev = loaded["previous_key"]
        previous = {
            "public_key_hex": prev["public_key_hex"],
            "private_key_hex": _private_hex(prev["private_key"]),
            "expires_at": prev.get("expires_at"),
        }
    return {
        "version": 2,
        "node_id": loaded["node_id"],
        "public_key_hex": loaded["public_key_hex"],
        "private_key_hex": _private_hex(loaded["private_key"]),
        "previous_key": previous,
        "rotated_at": loaded.get("rotated_at"),
        "rotation_pending": bool(loaded.get("rotation_pending", False)),
    }


def write_identity_file(path, loaded):
    """Rewrite an identity file atomically from a loaded dict."""
    _write_atomic(path, _payload_from_loaded(loaded))


def write_pending_rotation(path, new_private_key):
    """Record a rotation that has been generated but not yet acked.

    The file's current key becomes the NEW key, the old key moves to
    previous (expires_at null until the server's ack supplies it),
    rotation_pending becomes true, rotated_at is set. Returns the
    new loaded dict. The caller sends key_rotate after this returns;
    if the ack never arrives, the file still holds both keys and
    the next connect recovers per design §6.
    """
    loaded = load_identity_file(path)
    old_key = {
        "public_key_hex": loaded["public_key_hex"],
        "private_key": loaded["private_key"],
        "expires_at": None,
    }
    new_loaded = {
        "version": 2,
        "node_id": loaded["node_id"],
        "public_key_hex": public_key_hex(new_private_key),
        "private_key": new_private_key,
        "previous_key": old_key,
        "rotated_at": _now_iso(),
        "rotation_pending": True,
    }
    write_identity_file(path, new_loaded)
    return new_loaded


def confirm_rotation(path, previous_expires_at_ms):
    """Mark a pending rotation complete after the server's ack.

    Fills previous.expires_at from the ack and clears
    rotation_pending. Returns the new loaded dict. Raises
    ValueError if no rotation is pending.
    """
    loaded = load_identity_file(path)
    if not loaded["rotation_pending"] or loaded["previous_key"] is None:
        raise ValueError(
            f"identity file {path} has no pending rotation to confirm")
    loaded["previous_key"]["expires_at"] = previous_expires_at_ms
    loaded["rotation_pending"] = False
    write_identity_file(path, loaded)
    return loaded


def cancel_pending_rotation(path):
    """Undo a pending rotation the server refused.

    Restores the previous key as current and drops the pending
    state, so the file is exactly as it was before the rotation
    was attempted. Returns the new loaded dict. Raises ValueError
    if no rotation is pending.
    """
    loaded = load_identity_file(path)
    if not loaded["rotation_pending"] or loaded["previous_key"] is None:
        raise ValueError(
            f"identity file {path} has no pending rotation to cancel")
    old = loaded["previous_key"]
    restored = {
        "version": 2,
        "node_id": loaded["node_id"],
        "public_key_hex": old["public_key_hex"],
        "private_key": old["private_key"],
        "previous_key": None,
        "rotated_at": None,
        "rotation_pending": False,
    }
    write_identity_file(path, restored)
    return restored


__all__ = [
    "public_key_hex",
    "derive_node_id",
    "create_identity_file",
    "load_identity_file",
    "write_identity_file",
    "write_pending_rotation",
    "confirm_rotation",
    "cancel_pending_rotation",
]
