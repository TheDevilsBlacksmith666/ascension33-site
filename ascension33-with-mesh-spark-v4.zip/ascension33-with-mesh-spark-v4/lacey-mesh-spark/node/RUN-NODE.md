# RUN-NODE — the runnable in-between node

Lacey v1 running as a real process on a node, speaking the mesh
protocol. Research-mesh core only. This is the step past the library
tests: the same Lacey code, but live on a socket, with heartbeats,
severance, reconnect, and reconcile happening in real time.

## What it is

`node.py` is one node process. It:

- connects to a mesh registry over WebSocket and speaks the real
  registry protocol: hello → challenge → hello-proof → welcome
  (mesh-auth-v1 challenge-response; the registry never trusts a
  self-asserted node id), heartbeat → hb-ack,
  request_task → task, submit_task → task_result,
  attest → attest_ack, peers count broadcasts;
- runs Lacey v1 as its agent on every real protocol message:
  sense / verify / attest / sever / reconcile, through the approved
  wiring (10% random per-index attestation, seeded; time-critical
  always 100%);
- solves real SHA-256 nonce tasks from the registry and submits
  them, with the nonce count and wall-clock time measured on the
  line (the registry's $PIRG awards in this setup are test awards,
  labeled `tpirg(test)`, not real $PIRG);
- runs Pattern C through a STUB draft/verifier — fixed toy tokens,
  labeled STUB in every log line and in the code. There is no model
  and no acceptance or latency figure. The stub exercises the
  protocol path only;
- keeps working while severed: local events are recorded with
  provisional receipts, and on reconnect the node relays its
  manifest and reconciles. Conflicting unique claims freeze the
  item instead of awarding it, and the daily-batch adjudicator
  decides from the real claims.

Every log line carries a measured-vs-modeled label: MEASURED,
MODELED, SIMULATED, or STUB. Anything simulated or stubbed says so
on the line. Radio transport (BLE, Wi-Fi Aware, Wi-Fi Direct) is
reported as unknown everywhere — no measurement exists yet.

## Which registry it talks to

There are two registries. The node says which one on every
connection line, and the status endpoint names it too.

1. **LOCAL TEST REGISTRY (default).** The real v0 registry server
   (`~/workspace/pirgitori-mesh/server/server.js`) started on this
   machine on a local port, with a fresh throwaway ledger and a
   fresh throwaway secret in a temp dir. Nothing about it is
   production: plain `ws://`, no TLS, no real $PIRG, no real peers.
   This is what the live scenario test uses.
2. **The production registry on the VPS.** Not deployed. The VPS
   212.227.14.120 has no answering service and no TLS certificate,
   so the game correctly shows MESH: OFFLINE and the node cannot
   reach it. To use it, deploy the registry with TLS first
   (`~/workspace/pirgitori-mesh/VPS-TLS-RUNBOOK.md`) and point the
   node at `wss://...`. Do not point a node at the VPS until then.

The node never deploys anything and never tries SSH.

## How to start it

Prerequisites: Node.js (for the registry) and the Lacey venv
(`~/workspace/lacey/v1/.venv` — the system Python lacks the
`cryptography` module Lacey needs).

### 1. Start a local test registry

```sh
cd ~/workspace/pirgitori-mesh/in-between-node-v1
./run-local-registry.sh 8787
```

That starts the real `server.js` on port 8787 with a throwaway
ledger and secret under `/tmp/pirgitori-local-registry-8787-<pid>/`, and
prints the registry's health JSON. Leave it running in its own
terminal. Stop it with Ctrl-C. The ledger and secret in that temp
dir are throwaway: delete them when done.

### 2. Create a node identity (auth v1)

The registry authenticates every node by Ed25519 key, and the
node id is derived from the public key. Create an identity file
first — without one, the node signs with a fresh ephemeral key:
it connects once, but a restart is rejected as `key-mismatch`
because the registry already has a different key for that id.

```sh
cd ~/workspace/pirgitori-mesh/in-between-node-v1
~/workspace/lacey/v1/.venv/bin/python -c \
  "from identity import create_identity_file; print(create_identity_file('node-a-identity.json')['node_id'])"
# prints e.g. node-3f9a1c2b4e5d — use that id in the node command
```

The file holds the private key: keep it private (0600, which
`create_identity_file` sets) and out of the repo. The node only
reads it, except for the single atomic rewrite a key rotation
performs. `LACEY_IDENTITY_FILE` sets the same file by
environment instead of `--identity-file`.

### 3. Start a node

```sh
cd ~/workspace/pirgitori-mesh/in-between-node-v1
~/workspace/lacey/v1/.venv/bin/python node.py \
  --node-id node-3f9a1c2b4e5d \
  --registry ws://127.0.0.1:8787 \
  --status-port 18891 \
  --seed <a-seed-you-choose> \
  --identity-file node-a-identity.json \
  --heartbeat-interval 2 \
  --missed-threshold 3
```

The seed is required: the wired Lacey factory refuses to build
without one. For a local run, any string works
(`--seed local-test-1`). **Never put a production seed in this repo
or in a shell history file you share** — the seed is held by the
core operator, rotated weekly, and never published to nodes. The
node logs only the seed source (parameter / file / environment),
never the seed value.

Options:

- `--node-id` — the node's id (**required**; there is no default).
  It must equal the id in `--identity-file` (derived from that
  file's public key); a mismatch fails fast at startup.
- `--identity-file` / `LACEY_IDENTITY_FILE` — the identity file
  holding this node's Ed25519 keypair (see step 2). Without it
  the node signs with a fresh ephemeral key.
- `--registry` — the registry WebSocket URL
  (default `ws://127.0.0.1:8787`). Use `wss://...` for a
  TLS-terminated registry; `--registry-ca-file` trusts a
  self-signed test certificate, otherwise the system trust store
  is used.
- `--status-port` — the local status HTTP port (**required**; each
  node needs its own).
- `--seed` / `--seed-file` / `LACEY_ATTEST_SEED` /
  `LACEY_ATTEST_SEED_FILE` — the attestation seed, in that order.
  `--seed-file` reads the seed from a file, which keeps it out of
  the process command line and shell history. Exactly one source
  is required; the factory refuses to build without one.
- `--state-file` — where to persist `next_mission_idx` (default
  `node-state-<node-id>.json` in the working directory). A
  restarted node resumes attesting from the saved index instead
  of re-sending indices the registry already saw. Unsampled
  attestations are appended to a JSONL log next to it
  (`node-state-<node-id>.attest.jsonl`).
- `--heartbeat-interval` — seconds between heartbeats (default 5).
- `--missed-threshold` — missed heartbeats before severance
  (default 3).
- `--log-file` — also write the log to a file.
- `--fog-relay` — (Step 4) a parked relay URL for the fog
  envelope link: a second WebSocket used only for node-to-node
  manifest envelopes. The node announces itself to the relay on
  connect (the socket enters the relay's envelope mode — no
  registry pairing exists on it), and reconnects with backoff if
  the link drops. The registry session is unaffected in either
  direction: the fog link works with the registry entirely down.
  Without this flag the node behaves exactly as before.
- `--peer-key <nodeId>=<pubkeyHex>` — (Step 4, repeatable) the
  public key of a fog peer whose manifest envelopes this node
  will reconcile. Keys come ONLY from this explicit config: a
  manifest envelope from a sender with no configured key is
  rejected untrusted (counted in `/status` under
  `fog.rejected_untrusted`, logged, never reconciled), and a key
  carried inside an envelope is never trusted. **Key
  distribution is a future step** — today the operator copies
  keys between nodes by hand, the same way identity files are
  handled.
- `--onion-relays <wsURL>[,<wsURL>...]` — (Step 6, only with
  `--fog-relay`) an ordered list of parked relay URLs forming an
  onion path. When set, `POST /send-manifest` wraps the manifest
  envelope's payload in an onion (`onion_py.py`: one P-256 ECDH
  layer per listed relay, per the relay `PROTOCOL.md` spec) and
  sends the onion frame to the FIRST listed relay over the fog
  link instead of the plain envelope — intermediate relays then
  learn only the next hop, and only the exit relay sees the
  destination and the payload. Each relay's ephemeral onion key
  is fetched from its `GET /onion-key` endpoint at send time
  (the keys change every relay run, so nothing is cached). If
  any fetch or the wrap fails, the node sends the plain envelope
  instead and logs the fallback (counted in `/status` under
  `fog.onion_fallbacks`; successful onion sends under
  `fog.onion_sent`). Receiving is unchanged: an onion delivery
  arrives at the destination node as a plain envelope from
  `"onion"`, and the manifest inside still has to pass the
  `--peer-key` trust check. Without this flag the node behaves
  exactly as before.

Stop a node with Ctrl-C. It logs `node stopping` and closes the
registry connection cleanly.

### 4. Talk to a running node

The status HTTP endpoint is on `127.0.0.1` only — it never listens
on a public interface.

```sh
# state: mode, peers, counters, frozen items, sampling, tasks, attestations
curl http://127.0.0.1:18891/status
curl http://127.0.0.1:18891/health

# emit a local event (counter_inc / position / unique_claim)
curl -X POST http://127.0.0.1:18891/act \
  -H 'Content-Type: application/json' \
  -d '{"op":"counter_inc","key":"score","payload":5}'

# request and solve a real task from the registry
curl -X POST http://127.0.0.1:18891/request-task \
  -H 'Content-Type: application/json' -d '{}'

# rotate this node's key (manual, operator-triggered; needs a live
# session — the old key signs the new key in, and the identity
# file is rewritten atomically)
curl -X POST http://127.0.0.1:18891/rotate-key \
  -H 'Content-Type: application/json' -d '{}'

# attest a batch: 20 standard + 1 time-critical by default
curl -X POST http://127.0.0.1:18891/attest-batch \
  -H 'Content-Type: application/json' \
  -d '{"count":20,"time_critical":1}'

# run one Pattern C job through the STUB draft/verifier
curl -X POST http://127.0.0.1:18891/pattern-c \
  -H 'Content-Type: application/json' \
  -d '{"mode":"classify","prompt":"test"}'

# relay another node's manifest and reconcile (body = their /manifest)
curl http://127.0.0.1:18892/manifest > /tmp/node-b-manifest.json
curl -X POST http://127.0.0.1:18891/reconcile \
  -H 'Content-Type: application/json' \
  --data-binary @/tmp/node-b-manifest.json

# (Step 4, fog link only) send this node's manifest batches to a
# peer node as ONE envelope over the relay matrix
curl -X POST http://127.0.0.1:18891/send-manifest \
  -H 'Content-Type: application/json' \
  -d '{"to":"node-<peer id>"}'
```

The fog link's state is in `/status` under `fog`: relay URL,
connected, sent/received envelope counts, `rejected_untrusted`,
the configured peer-key node ids, and `fog_peer` /
`fog_last_reconcile` (the last manifest envelope's sender,
outcome — `reconciled` or `rejected-untrusted` — and, when
reconciled, the reconcile report lines).

## What it proves

Run the live scenario test — it boots the real registry and two
real node processes and drives the whole loop:

```sh
cd ~/workspace/pirgitori-mesh/in-between-node-v1
~/workspace/lacey/v1/.venv/bin/python test_node_live.py
```

It asserts, end to end:

1. join — both nodes authenticate to the LOCAL TEST REGISTRY
   with the challenge-response handshake (hello → challenge →
   hello-proof → welcome) and see peers=2;
2. heartbeat — heartbeats flow and are acked;
3. task — node A requests a task, solves it with real SHA-256
   nonces (count and time measured), submits, and the registry
   verifies it;
4. attest — a batch of 20 standard + 1 time-critical claims is
   attested; the sampled set matches the seeded sampler exactly
   (sampled claims sent and acked, the rest recorded local-only);
5. Pattern C — a classify job runs the STUB path;
6. severance — the registry is killed and both nodes declare
   severance after the missed-heartbeat threshold, with receipts
   provisional;
7. act while severed — both nodes act locally, including both
   claiming the same unique item;
8. reconnect — the registry restarts and both nodes reconnect;
9. reconcile — manifests are relayed and both nodes converge to
   the same counters (score 5+7=12) with the contested item frozen
   on both;
10. adjudicate — the frozen item is decided from the real claims
    (earliest attested claim wins; tie broken by node-id hash),
    with a loser recorded and nothing auto-awarded;
11. the node logs contain the severance line, a STUB line, the
    local-test-registry label, and the radio-unknown line.

Expected output ends with `ALL LIVE NODE TESTS PASS`. The run
takes about five seconds.

The Step 4 envelope test is separate — it boots real relays and
real nodes with **no registry process at all**:

```sh
cd ~/workspace/pirgitori-mesh/in-between-node-v1
~/workspace/lacey/v1/.venv/bin/python test_step4_envelopes.py
```

It asserts: standalone reconcile across two relays (A's manifest
envelope reconciles on B, counters converge); store-and-forward
held delivery (B away → a relay reports `held_envelopes >= 1` →
B returns inside the hold and reconciles); hold expiry (relays
at `--hold-seconds 2` → `held_expired >= 1` → a late B does NOT
receive the envelope); and untrusted-sender rejection (B has no
`--peer-key` for C → C's manifest is counted
`rejected_untrusted` and B's state does not move). Expected
output ends with `ALL STEP 4 ENVELOPE TESTS PASS`.

## What is real, what is stub, what is still missing

**Real:**

- Lacey v1's sense / verify / attest / sever / reconcile loop,
  running on live protocol messages, not in a unit test.
- The registry protocol: the node speaks the real v0 registry's
  messages, against the real `server.js`.
- Task solving: real SHA-256 nonce search, real counts and times.
- Attestation: real Ed25519-signed claims, real seeded random
  sampling at the approved 10%.
- Severance and reconcile: real missed-heartbeat detection, real
  provisional receipts, real manifest relay and merge.
- Fog envelope transport (Step 4): real manifest envelopes over
  the real relay matrix, real store-and-forward in the relays.
  Manifests are signed, not encrypted — relays can read them;
  the fog link adds transport, not confidentiality.
- Onion manifest sends (Step 6, `--onion-relays`): real P-256
  ECDH onion wrapping of the manifest payload in `onion_py.py`,
  interoperable with the relay reference implementation
  (`onion.js`) — cross-implementation vectors and a live
  three-relay delivery are asserted by `test_onion_python.py`.
  Only messages sent with the flag get the confidentiality;
  plain fog envelopes stay readable by relays.
- Adjudication: the real daily-batch adjudicator on the real
  claims.

**Stub / simulated:**

- Pattern C draft/verifier: fixed toy tokens. The protocol path
  is real; the inference is not. No acceptance rate and no latency
  exist for Pattern C — the only number is the count of runs in
  this session, which is not a finding.
- The local loopback WebSocket stands in for the Wi-Fi link in
  the Pattern C transport line, labeled SIMULATED. No radio
  measurement exists.
- The registry's $PIRG awards are test awards (`tpirg(test)`),
  not real $PIRG. No real token exists.
- The LOCAL TEST REGISTRY is a throwaway local server, not the
  production registry.

**Still missing (needs Edward):**

- Phone measurement run: BLE, Wi-Fi Aware presence, Wi-Fi Direct
  behavior, throughput, BLE background behavior, battery cost.
  Until it runs, all radio behavior stays unknown and no radio
  code is written.
- VPS deploy + TLS: the production registry is not deployed, so
  the game and the node can only talk to a local test registry.
- A real inference model for on-node compute: Pattern C needs a
  real draft model and a real verifier before it can do anything
  beyond exercising the protocol path.
- Operator naming: who holds the attestation seed, and who runs
  the daily adjudication batch.

## Files

- `node.py` — the runnable node process.
- `identity.py` — identity files: create / load / rotate /
  confirm / cancel (auth v1, design §7).
- `test_auth.py` — the auth unit tests (identity files, signed
  bodies, the identity-key seam).
- `wsclient.py` — minimal stdlib-only WebSocket client (no
  third-party dependency; the system Python and the Lacey venv
  have no `websockets` package).
- `run-local-registry.sh` — starts the real v0 registry locally
  with a throwaway ledger and secret.
- `test_node_live.py` — the live scenario test (real processes,
  real registry, asserts the whole loop).
- `test_step4_envelopes.py` — the Step 4 live test (real relays,
  real nodes, no registry: standalone reconcile, held delivery,
  hold expiry, untrusted-sender rejection).
- `onion_py.py` — the Python port of the Step 6 onion layer
  (P-256 ECDH + HKDF-SHA256 + AES-256-GCM), mirroring
  `relay/onion.js`; used by `node.py --onion-relays`.
- `test_onion_python.py` — the onion port test: Python↔JS
  cross-implementation vectors in both directions, a live
  three-relay onion manifest delivery between two real nodes
  with no registry, and the plain-envelope fallback when a path
  relay's key cannot be fetched.
- `RUN-NODE.md` — this file.
- `inbetween.py`, `test_severance.py` — the merge/reconcile logic
  and its tests, unchanged.
