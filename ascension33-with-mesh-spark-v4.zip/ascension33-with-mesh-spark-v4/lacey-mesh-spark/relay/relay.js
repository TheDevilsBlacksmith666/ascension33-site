#!/usr/bin/env node
/*
 * Pirgitori parked relay — Step 8 (relay v0.7.0).
 *
 * A parked relay is an internet-resident, disposable, keyless
 * forwarder that sits between mesh endpoints and the registry and
 * carries their already-signed traffic. It gives the mesh a
 * persistent transport fabric that survives with zero game nodes
 * online, while originating no mesh state of its own.
 *
 * Step 1 cut (unchanged): end-to-end WebSocket frame forwarding,
 * node <-> relay <-> registry, byte-for-byte, for every
 * NON-envelope frame. No parsing, no rewriting, no re-signing.
 *
 * Step 4 additions (v0.3.0):
 *  - Envelope-mode client sockets: if a client socket's FIRST
 *    frame is a relay envelope, the socket enters envelope mode
 *    and NO Step 1 upstream pairing is created for it. It sends
 *    and receives envelopes only (non-envelope frames on an
 *    envelope-mode socket are dropped silently). Because no
 *    pairing exists, the socket is untouched by registry
 *    downtime — this is what lets a node's fog link operate
 *    standalone. (A raw first frame keeps the exact v0.1/v0.2
 *    paired behavior, and paired sockets can still send
 *    envelopes mid-session as in v0.2.) An envelope-mode socket
 *    that addresses an envelope to "registry" gets a lazily
 *    opened per-socket pipe to the registry whose replies return
 *    raw to that socket; the pipe is NOT a pairing — it is
 *    created only on demand and its failure never closes the
 *    client socket.
 *  - Store-and-forward (D6, decided by Edward 2026-11-18 at the
 *    proposed default): an envelope whose destination has been
 *    SEEN attached (locally or via gossip) but is not currently
 *    deliverable — not attached anywhere the gossip table can
 *    currently reach, or its holder relay's link is down — is
 *    held in memory only for up to --hold-seconds (default
 *    600 s), then dropped silently. On the destination attaching
 *    anywhere reachable, held envelopes are delivered in arrival
 *    order. Cap: 100 held envelopes per destination; excess
 *    drops silently. Envelopes to never-seen destinations are
 *    NOT held (the v0.2 drop/wander behavior stands). Held state
 *    dies with the process; nothing goes to disk, ever.
 *  - Envelopes addressed to the literal "relay" are control
 *    envelopes for THIS relay (a node's announce): the
 *    attachment is recorded and the envelope is consumed —
 *    delivered nowhere, forwarded nowhere.
 *
 * Step 5 additions (v0.4.0):
 *  - Relay hello-proof (design §5.2, PROTOCOL.md): peer hello now
 *    carries the sender's full public key, and the claimed relay
 *    id MUST equal relay- + first 12 hex of that key — a mismatch
 *    is an impersonation attempt: the link is dropped and counted.
 *    After the hello exchange, each side challenges the other
 *    (32-byte nonce, single-use, 30 s expiry) and the other proves
 *    key possession with an Ed25519 signature over
 *    ["pirgitori-relay-v1", nonce, relayId]. Proof runs in both
 *    modes; it proves a relay holds its claimed key NOW — not
 *    that it is honest.
 *  - Operator roster (design §4.5): with --roster <file> +
 *    --operator-pubkey <hex>, the roster's Ed25519 signature is
 *    verified at boot against the operator key; a forged or
 *    malformed roster is a REFUSAL TO START, never a warning.
 *    A peer is VERIFIED when its hello-proof passed AND its
 *    public key is on the roster. When any verified candidate
 *    exists, next-hop selection (weighted pick and gossip-holder
 *    forwarding) uses verified links only; unverified links carry
 *    traffic only when no verified candidate exists. Without a
 *    roster there are no verified peers and selection is exactly
 *    as before — proof then stops impersonation only, not Sybil.
 *    The operator is the roster's trust root: whoever holds the
 *    operator key decides which relays are legitimate.
 *  - Persistent identity (opt-in): --identity-file <path> loads
 *    an operator-provisioned Ed25519 keypair (see
 *    roster_tool.js), so the relay keeps the SAME id across
 *    restarts — required for a roster, which lists keys in
 *    advance. This trades the default ephemerality for Sybil
 *    resistance; the trade is inherent, not a bug. Without the
 *    flag the identity is ephemeral per run, exactly as before.
 *    Identity files are secrets (mode 0600, operator-side); the
 *    private key lives in memory only and is never logged,
 *    printed, or exposed in /health. This process still writes
 *    nothing to disk.
 *
 * Step 6 additions (v0.5.0):
 *  - Onion routing (design §4.4; D2 DECIDED by Edward 2026-11-18:
 *    onion NOW, P-256 ECDH so the browser game client can do the
 *    same math with WebCrypto later). The crypto lives in
 *    onion.js — the one implementation of the PROTOCOL.md layer
 *    format; this file is transport. Each relay generates an
 *    EPHEMERAL P-256 onion keypair per run (separate from its
 *    Ed25519 identity; ephemeral even for identity-file/roster
 *    relays) and advertises the public half in peer hello, in
 *    gossip, and at GET /onion-key (public keys are public
 *    material — the endpoint returns ONLY {relayId, onionPub}).
 *    A client (envelope-mode or paired) or a peer may send
 *    {relay:"v1", type:"onion", blob, ttl, hop}; this relay peels
 *    ONE layer with its onion private key and either forwards the
 *    still-wrapped remainder to the next relay, or — at the exit
 *    layer — delivers the payload to the attached destination as
 *    a plain envelope from "onion" (the sender is not named), or
 *    extracts it raw to the registry. AEAD failure, an unknown or
 *    unreachable next hop, and ttl exhaustion all drop silently
 *    (counted). Onion frames are NEVER store-and-forward held:
 *    an intermediate relay cannot know the final destination, so
 *    there is nothing safe to hold for. A successful onion
 *    forward to a peer counts as a successful send for that
 *    peer's synaptic weight, exactly like an envelope forward.
 *    Onion is opt-in per message: plain envelopes remain fully
 *    readable by every relay they cross.
 *
 * Step 7 additions (v0.6.0):
 *  - Auto-join (internet-native matrix): gossip already carries
 *    peer endpoints; now endpoints LEARNED from gossip (peers of
 *    peers, with a fresh lastSeen) become dial candidates. A
 *    relay started with a SINGLE --peer bootstrap address dials
 *    learned endpoints it is not already connected/connecting
 *    to and so joins the whole reachable matrix by itself; a
 *    relay started with NO --peer still accepts inbound peers
 *    and can be bootstrapped by others dialing it. Learned
 *    dials are disciplined: never the relay's own advertised
 *    endpoint, never an endpoint already represented by a live
 *    (or connecting, or seed-managed) link, never a relay that
 *    already has a live link. A failed learned dial backs off
 *    exponentially (1 s doubling, capped at 60 s) and the
 *    backoff resets when a dial completes a hello. In roster
 *    mode, dial candidates are ordered verified-first —
 *    endpoints whose relay's public key this relay has actually
 *    seen (in a prior hello) and that is on the roster go before
 *    unknown ones; a never-contacted relay's key is unknowable
 *    before its first hello, so first contact is still
 *    proof-checked at hello time and roster routing preference
 *    applies from then on. HONEST ABUSE NOTE: learned endpoints
 *    are UNTRUSTED input — a malicious peer can advertise junk
 *    endpoints and this relay will spend dial attempts on them.
 *    The cooldown, the freshness window, and the capacity caps
 *    bound that cost; roster mode's verified-first ordering
 *    limits exposure. Nothing here makes a learned endpoint
 *    trustworthy.
 *  - Capacity caps: --max-peers (default 16) bounds live peer
 *    links and --max-clients (default 256) bounds live client
 *    sockets, per process. At cap, new inbound peer links and
 *    client sockets are closed cleanly with close code 1013,
 *    outbound learned dials are not started, and seed dials
 *    retry later (a seed is operator intent, not dropped);
 *    existing links are untouched. /health reports max_peers,
 *    max_clients, at_peer_cap, at_client_cap, and the
 *    learned_dial_attempts counter. Caps are per-process
 *    operator settings, not network policy: each relay's
 *    operator chooses their own.
 *  - Roster preference refinement (Step 5 semantics under
 *    self-assembled topologies): with auto-join, a relay can
 *    hold an unverified link it never chose to dial. The
 *    verified-only restriction in weighted next-hop selection
 *    is now evaluated against ALL live links before the arrival
 *    link is excluded: if any verified link is up, unverified
 *    links are not used for wander forwarding — and if the
 *    only verified link is the arrival link, the envelope drops
 *    rather than spilling to an unverified peer. (Before, the
 *    arrival link was excluded first, so a relay whose only
 *    verified link was the arrival could spill to unverified.)
 *    Non-roster selection is byte-for-byte the v0.5 behavior.
 *
 * Step 8 additions (v0.7.0):
 *  - Tiered gossip (fractal scale): gossip no longer exchanges
 *    full tables. A relay sends FULL entries only for its LOCAL
 *    tier — itself, its direct peers, and attachments homed at
 *    itself or its direct peers. Everything beyond the local
 *    tier travels as compact SUMMARIES ({id, endpoint/onionPub
 *    or home relay, lastSeen, relay-hop distance}) in a rotating
 *    window of --gossip-summaries entries per class per message,
 *    so a relay with a small local tier sends a roughly
 *    constant-size gossip frame no matter how wide the network
 *    grows. Every table entry now carries `dist` (relay hops to
 *    the subject: 0 = this relay / homed here, 1 = direct peer /
 *    homed at a direct peer, >= 2 = summary knowledge) and `via`
 *    (the peer that reported the winning observation). Merge
 *    stays newest-lastSeen-wins; ties break toward the smaller
 *    dist. Local-tier entries expire on the 15 s liveness
 *    window as before; summary entries expire on the longer
 *    summary liveness (--summary-liveness-seconds, default
 *    120 s) — distant knowledge is a hint for aiming and
 *    lookup, and its lastSeen is the HOME relay's observation
 *    time, never refreshed by re-gossip, so a dead relay's
 *    summaries die on schedule even while peers keep relaying
 *    them. Retained summaries are capped per table by
 *    --max-summaries (default 10000, oldest-lastSeen evicted
 *    first): a memory bound, not network policy.
 *  - Routing with summaries: an envelope whose destination's
 *    home relay is known only as a summary is forwarded to the
 *    peer that reported it (`via`) — each hop re-aims from its
 *    own fresher knowledge, so the envelope walks toward the
 *    home relay. The Step 5 roster preference applies to the
 *    aim hop exactly as to a direct holder hop. Wander remains
 *    the fallback when no summary exists.
 *  - Sharded lookup: an envelope for a destination this relay
 *    has NEITHER a local attachment NOR a summary for (and has
 *    never seen — seen destinations keep the Step 4 hold) may
 *    trigger a bounded lookup before the wander fallback: a
 *    {type:"lookup"} frame walks peer links toward the peer
 *    whose relay id is closest (XOR distance over SHA-256 of
 *    the ids, Kademlia-style) to the destination's hash; a
 *    relay holding the destination answers along the recorded
 *    reverse path, the origin caches the answer as a summary
 *    and routes the parked envelope. TTL 6, one outstanding
 *    lookup per destination, failures negative-cached for
 *    30 s, parked envelopes capped. HONEST LIMITS: this is a
 *    hash-directed best-effort walk, NOT a DHT — no
 *    guarantee of finding a destination that exists;
 *    summaries can be stale, and a lying relay can poison
 *    summaries or lookup answers (it learns nothing it could
 *    not learn from gossip, and roster/verified preference
 *    remains the mitigation where it applies). Lookup frames
 *    carry no payload — only the destination id being asked
 *    about, which gossip would have revealed anyway.
 *
 * Step 2 additions (this file):
 *  - Relay peering: relays connect to seed peers (--peer,
 *    repeatable) over a dedicated /peer path with a first-frame
 *    peer hello, and accept peer connections from other relays.
 *    Peer links reconnect with backoff if dropped.
 *  - Gossip: peer relays periodically exchange the PROTOCOL.md
 *    gossip shape (peer table + attachment table). Entries not
 *    seen within the liveness window (15 s, with a 5 s gossip
 *    interval — MODELED, unmeasured in production) are dropped.
 *  - Envelope routing: frames that parse as JSON with
 *    "relay":"v1" and a string "payload" field are envelopes
 *    {to, from, ttl, hop, payload} and are routed per
 *    PROTOCOL.md instead of raw-forwarded: to "registry" the
 *    payload is forwarded upstream as a raw frame; to a locally
 *    attached client it is delivered; to a client attached at
 *    another relay (learned by gossip) it is forwarded to that
 *    peer; otherwise it goes to a peer chosen by
 *    synaptic-weighted random selection. ttl decrements per hop,
 *    hop increments; ttl 0 drops silently.
 *  - Synaptic weights (Edward's addition): an in-memory per-peer
 *    routing-preference table. Every peer starts at 1.0. A
 *    successful envelope send to a peer: +0.1 (cap 10). A send
 *    failure or an established peer's disconnect: x0.5 (floor
 *    0.1). Each gossip interval every weight decays 1% toward
 *    1.0. Weights are routing preference ONLY — not trust, not
 *    reputation — and die with the process, never on disk.
 *
 * HONEST LIMITS (do not remove): a relay CAN read the payloads
 * of PLAIN envelopes it forwards (onion routing, Step 6, is
 * opt-in per message and plain envelopes remain readable), and
 * CAN drop, delay, or duplicate traffic. For ONION frames, an
 * intermediate relay can no longer read the payload or learn
 * the final destination — but the entry relay knows the sender's
 * connection, the exit relay learns the destination, and timing
 * correlation is NOT solved (no padding, no delays).
 * Manifest envelopes are signed, not encrypted: a relay holding
 * one (including in its store-and-forward memory) can read it.
 * Held envelopes sit in relay memory for up to the hold window
 * and are gone when the process dies — never recovered, never
 * written anywhere.
 * It cannot forge or replay an attestation, impersonate a node,
 * or alter signed state undetected — those properties come from
 * mesh-auth-v1, which this relay does not touch: raw payloads are
 * never parsed, rewritten, or re-signed, and envelope payloads
 * are carried as opaque strings. See
 * parked-relay-matrix-design.md §4. "No way to trace or hack it"
 * is impossible as stated; this relay raises the cost, it does
 * not eliminate tracing or hacking. Synaptic weights change
 * which peer is preferred; they do not make any peer trustworthy
 * and a Sybil relay can earn weight like any other.
 *
 * WHAT THIS RELAY NEVER DOES: never attests, never originates
 * attested mesh state, never holds a node key, never runs Lacey,
 * never writes a ledger, never adjudicates, never awards
 * test-$PIRG, never writes anything to disk, never logs message
 * contents, node ids, IP addresses, public keys, or private keys.
 * Counts only (relay ids in /health are the one exception, as in
 * Step 1).
 *
 * Run: node relay.js --registry ws://127.0.0.1:8787 --port 8788 \
 *        [--peer ws://127.0.0.1:8789] [--advertise ws://127.0.0.1:8788] \
 *        [--hold-seconds 600] \
 *        [--identity-file <relay-key.json>] \
 *        [--roster <roster.json> --operator-pubkey <hex>] \
 *        [--max-peers 16] [--max-clients 256] \
 *        [--max-summaries 10000] [--gossip-summaries 50] \
 *        [--summary-liveness-seconds 120]
 * Kill: SIGINT / SIGTERM — closes every socket and exits.
 *
 * mesh-auth-v1 is UNTOUCHED by this file: no protocol change, no
 * new message type in the mesh protocol, no weakening. The
 * registry sees relay-forwarded connections as ordinary
 * connections and authenticates the nodes exactly as it does
 * today. The relay envelope and gossip live only between relays
 * and on the relay hop of a client connection.
 */
'use strict';
const http = require('http');
const fs = require('fs');
const crypto = require('crypto');
const { WebSocketServer, WebSocket } = require('ws');
const onion = require('./onion.js');

const RELAY_VERSION = '0.7.0';
const PROTOCOL = 'relay-v1';
// Step 5 hello-proof: challenge nonces are 32-byte CSPRNG hex,
// single-use, 30 s expiry — the mesh-auth-v1 parameters, reused
// deliberately (design §5.2).
const PROOF_TTL_MS = 30000;

// Step 2 timing constants — MODELED, not measured in production.
// Gossip convergence in the test run IS measured and printed by
// test_relay_step2.js; production convergence on real hosts is
// still unmeasured.
const GOSSIP_INTERVAL_MS = 5000;
const LIVENESS_WINDOW_MS = 15000;
const DEFAULT_ENVELOPE_TTL = 5;
// Step 4 store-and-forward: default hold 600 s (D6, decided by
// Edward 2026-11-18 at the proposed default), per-destination cap
// 100 envelopes, expiry swept every 250 ms so short test holds
// expire on time. All MODELED values, held in memory only.
const DEFAULT_HOLD_SECONDS = 600;
const HOLD_PER_DEST_CAP = 100;
const HOLD_SWEEP_MS = 250;

// Step 8 fractal-scale constants — MODELED, like the Step 2
// timings. Summary entries (dist >= 2) live longer than local
// entries because their lastSeen is the home relay's observation
// time and propagation across rotating windows takes cycles;
// 120 s is slack for that, not a freshness promise. The lookup
// bounds keep a single unknown destination cheap: TTL 6 hops,
// a 4 s wait for an answer, a 30 s negative cache, at most 10
// envelopes parked per destination and 100 destinations parked
// per relay.
const DEFAULT_MAX_SUMMARIES = 10000;
const DEFAULT_GOSSIP_SUMMARIES = 50;
const DEFAULT_SUMMARY_LIVENESS_SECONDS = 120;
const LOOKUP_TTL = 6;
const LOOKUP_TIMEOUT_MS = 4000;
const LOOKUP_NEGATIVE_SECONDS = 30;
const LOOKUP_PARK_PER_DEST_CAP = 10;
const LOOKUP_PARK_DEST_CAP = 100;

// ---- CLI (minimal, no dependency) ------------------------------------
// Step 7 capacity defaults: per-process operator settings, not
// network policy (see the Step 7 header note).
const DEFAULT_MAX_PEERS = 16;
const DEFAULT_MAX_CLIENTS = 256;
function parseArgs(argv) {
  const out = {
    registry: null, port: 8788, host: '0.0.0.0', peers: [],
    advertise: null, holdSeconds: DEFAULT_HOLD_SECONDS,
    identityFile: null, roster: null, operatorPubkey: null,
    maxPeers: DEFAULT_MAX_PEERS, maxClients: DEFAULT_MAX_CLIENTS,
    maxSummaries: DEFAULT_MAX_SUMMARIES,
    gossipSummaries: DEFAULT_GOSSIP_SUMMARIES,
    summaryLivenessSeconds: DEFAULT_SUMMARY_LIVENESS_SECONDS,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--registry') out.registry = argv[++i];
    else if (a === '--port') out.port = parseInt(argv[++i], 10);
    else if (a === '--host') out.host = argv[++i];
    else if (a === '--peer') out.peers.push(argv[++i]);
    else if (a === '--advertise') out.advertise = argv[++i];
    else if (a === '--hold-seconds') out.holdSeconds = parseFloat(argv[++i]);
    else if (a === '--identity-file') out.identityFile = argv[++i];
    else if (a === '--roster') out.roster = argv[++i];
    else if (a === '--operator-pubkey') out.operatorPubkey = argv[++i];
    else if (a === '--max-peers') out.maxPeers = parseInt(argv[++i], 10);
    else if (a === '--max-clients') out.maxClients = parseInt(argv[++i], 10);
    else if (a === '--max-summaries') out.maxSummaries = parseInt(argv[++i], 10);
    else if (a === '--gossip-summaries') out.gossipSummaries = parseInt(argv[++i], 10);
    else if (a === '--summary-liveness-seconds') out.summaryLivenessSeconds = parseFloat(argv[++i]);
    else if (a === '--help' || a === '-h') {
      console.log('usage: node relay.js --registry <ws://|wss:// url> [--port 8788] [--host 0.0.0.0] '
        + '[--peer <ws://|wss:// url>]... [--advertise <ws://|wss:// url>] '
        + '[--hold-seconds 600] [--identity-file <relay-key.json>] '
        + '[--roster <roster.json> --operator-pubkey <hex>] '
        + '[--max-peers 16] [--max-clients 256] '
        + '[--max-summaries 10000] [--gossip-summaries 50] '
        + '[--summary-liveness-seconds 120]');
      process.exit(0);
    } else {
      console.error(`relay: unknown argument ${a}`);
      process.exit(2);
    }
  }
  if (!out.registry) {
    console.error('relay: --registry is required (e.g. --registry ws://127.0.0.1:8787)');
    process.exit(2);
  }
  if (!/^wss?:\/\//.test(out.registry)) {
    console.error(`relay: --registry must be a ws:// or wss:// URL, got ${out.registry}`);
    process.exit(2);
  }
  for (const p of out.peers) {
    if (!/^wss?:\/\//.test(p || '')) {
      console.error(`relay: --peer must be a ws:// or wss:// URL, got ${p}`);
      process.exit(2);
    }
  }
  if (out.advertise && !/^wss?:\/\//.test(out.advertise)) {
    console.error(`relay: --advertise must be a ws:// or wss:// URL, got ${out.advertise}`);
    process.exit(2);
  }
  if (!Number.isInteger(out.port) || out.port < 1 || out.port > 65535) {
    console.error(`relay: --port must be 1-65535, got ${out.port}`);
    process.exit(2);
  }
  if (!(out.holdSeconds > 0) || !Number.isFinite(out.holdSeconds)) {
    console.error(`relay: --hold-seconds must be a positive number, got ${out.holdSeconds}`);
    process.exit(2);
  }
  if (out.identityFile !== null && !out.identityFile) {
    console.error('relay: --identity-file requires a path');
    process.exit(2);
  }
  // The roster and the operator key that vouches for it are a
  // pair: one without the other is a configuration error.
  if ((out.roster && !out.operatorPubkey) || (!out.roster && out.operatorPubkey)) {
    console.error('relay: --roster and --operator-pubkey must be given together');
    process.exit(2);
  }
  if (out.operatorPubkey && !/^[0-9a-f]{64}$/.test(out.operatorPubkey)) {
    console.error('relay: --operator-pubkey must be a 64-hex Ed25519 public key');
    process.exit(2);
  }
  if (!Number.isInteger(out.maxPeers) || out.maxPeers < 1) {
    console.error(`relay: --max-peers must be a positive integer, got ${out.maxPeers}`);
    process.exit(2);
  }
  if (!Number.isInteger(out.maxClients) || out.maxClients < 1) {
    console.error(`relay: --max-clients must be a positive integer, got ${out.maxClients}`);
    process.exit(2);
  }
  if (!Number.isInteger(out.maxSummaries) || out.maxSummaries < 1) {
    console.error(`relay: --max-summaries must be a positive integer, got ${out.maxSummaries}`);
    process.exit(2);
  }
  if (!Number.isInteger(out.gossipSummaries) || out.gossipSummaries < 0) {
    console.error(`relay: --gossip-summaries must be a non-negative integer, got ${out.gossipSummaries}`);
    process.exit(2);
  }
  if (!(out.summaryLivenessSeconds > 0) || !Number.isFinite(out.summaryLivenessSeconds)) {
    console.error(`relay: --summary-liveness-seconds must be a positive number, got ${out.summaryLivenessSeconds}`);
    process.exit(2);
  }
  return out;
}
const ARGS = parseArgs(process.argv.slice(2));

// Peers connect to the dedicated /peer path. A --peer value is the
// peer's base ws URL; /peer is appended unless already present.
function peerUrl(base) {
  const u = base.replace(/\/+$/, '');
  return u.endsWith('/peer') ? u : u + '/peer';
}

// ---- Ed25519 helpers ---------------------------------------------------
// Raw public keys travel as 64-hex (the last 32 bytes of the SPKI
// DER). A key object is rebuilt from raw hex with the fixed
// Ed25519 SPKI prefix.
const ED25519_SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');
function pubHexFromKey(publicKey) {
  return publicKey.export({ format: 'der', type: 'spki' }).slice(-32).toString('hex');
}
function pubKeyFromHex(hex) {
  return crypto.createPublicKey({
    key: Buffer.concat([ED25519_SPKI_PREFIX, Buffer.from(hex, 'hex')]),
    format: 'der', type: 'spki',
  });
}
function isPubHex(s) { return typeof s === 'string' && /^[0-9a-f]{64}$/.test(s); }

// ---- Roster canonical bytes (shared with roster_tool.js) ---------------
// The roster signature covers the roster object WITHOUT its
// signature field, serialized as JSON with object keys sorted
// recursively and compact separators. Keep this byte-identical to
// roster_tool.js — a drift here makes every roster unverifiable.
function canonicalize(value) {
  if (Array.isArray(value)) return '[' + value.map(canonicalize).join(',') + ']';
  if (value && typeof value === 'object') {
    return '{' + Object.keys(value).sort()
      .map((k) => JSON.stringify(k) + ':' + canonicalize(value[k])).join(',') + '}';
  }
  return JSON.stringify(value);
}
function rosterSigningBytes(roster) {
  const rest = { ...roster };
  delete rest.signature;
  return Buffer.from(canonicalize(rest), 'utf8');
}
function verifyRosterSignature(roster, operatorPubkeyHex) {
  if (!roster || typeof roster !== 'object' || Array.isArray(roster)) return false;
  if (roster.version !== 1 || typeof roster.issued !== 'string') return false;
  if (!Array.isArray(roster.relays) || !roster.relays.every(isPubHex)) return false;
  if (typeof roster.signature !== 'string' || !/^[0-9a-f]+$/.test(roster.signature)) return false;
  try {
    return crypto.verify(null, rosterSigningBytes(roster),
      pubKeyFromHex(operatorPubkeyHex), Buffer.from(roster.signature, 'hex'));
  } catch (e) { return false; }
}

// ---- Identity (Step 5: ephemeral by default, persistent opt-in) --------
// Default (no --identity-file): a fresh Ed25519 keypair per run, in
// memory only; the key is never written to disk, never logged,
// never backed up. When this process dies, the identity dies with
// it. A respawn is a different relay with a different id.
//
// With --identity-file: an operator-provisioned keypair (created
// by roster_tool.js relay-keygen, mode 0600) is loaded and the
// relay keeps the SAME id across restarts. A roster lists public
// keys in advance, so a roster relay cannot be ephemeral — this
// mode trades ephemerality for Sybil resistance, inherently.
// Either way the PRIVATE key is retained in memory (Step 5 signs
// hello-proofs with it) and is never logged, printed, or exposed.
// The id is derived the same way as the ghost and game clients:
// `relay-` + first 12 hex of the public key.
let privateKey;
let publicKey;
if (ARGS.identityFile) {
  let data;
  try {
    data = JSON.parse(fs.readFileSync(ARGS.identityFile, 'utf8'));
  } catch (e) {
    console.error(`relay: cannot read identity file: ${e.message}`);
    process.exit(2);
  }
  if (!data || typeof data.privateKeyHex !== 'string') {
    console.error('relay: identity file is not a key file (no privateKeyHex)');
    process.exit(2);
  }
  try {
    privateKey = crypto.createPrivateKey({
      key: Buffer.from(data.privateKeyHex, 'hex'), format: 'der', type: 'pkcs8',
    });
  } catch (e) {
    console.error(`relay: cannot load identity private key: ${e.message}`);
    process.exit(2);
  }
  publicKey = crypto.createPublicKey(privateKey);
  if (data.pubkeyHex && data.pubkeyHex !== pubHexFromKey(publicKey)) {
    console.error('relay: identity file pubkeyHex does not match its private key');
    process.exit(2);
  }
} else {
  const kp = crypto.generateKeyPairSync('ed25519');
  privateKey = kp.privateKey;
  publicKey = kp.publicKey;
}
const pubHex = pubHexFromKey(publicKey);
const PUBKEY_HEX = pubHex;
const RELAY_ID = 'relay-' + pubHex.slice(0, 12);
const RELAY_ID_SHORT = RELAY_ID.slice(-8); // last 8 chars, as the leaderboard does

// ---- Roster (Step 5, opt-in) ----------------------------------------------
// With --roster + --operator-pubkey, the roster file is loaded and
// its signature verified against the operator key BEFORE anything
// listens. A forged, tampered, or malformed roster is a refusal
// to start — never a warning, never silently ignored. The roster
// set lives in memory; the operator key itself is public material
// and is not stored beyond the boot check.
let rosterSet = null;
if (ARGS.roster) {
  let roster;
  try {
    roster = JSON.parse(fs.readFileSync(ARGS.roster, 'utf8'));
  } catch (e) {
    console.error(`relay: roster file unreadable (${e.message}) — refusing to start`);
    process.exit(2);
  }
  if (!verifyRosterSignature(roster, ARGS.operatorPubkey)) {
    console.error('relay: roster signature verification FAILED — refusing to start');
    process.exit(2);
  }
  rosterSet = new Set(roster.relays);
}

// ---- Onion keys (Step 6: EPHEMERAL P-256, per run) ----------------------
// Separate from the Ed25519 identity above, and ephemeral EVEN
// for identity-file/roster relays: forward secrecy for the onion
// layer must not depend on a long-lived key, and a roster lists
// identity keys, not onion keys (senders fetch the current onion
// key from hello/gossip//onion-key). The private half stays in
// memory, never logged, printed, written, or exposed; the public
// half is public material and is advertised freely.
const onionKeys = onion.generateOnionKeys();
const ONION_PUB_HEX = onionKeys.publicHex;

// ---- Counts only (no contents, no node ids, no IPs) ------------------
const startedAt = Date.now();
const counts = {
  toRegistry: 0,   // messages forwarded client -> registry
  toClient: 0,     // messages forwarded registry -> client
  connectionsTotal: 0,
  upstreamFailures: 0,
  proofsFailed: 0,        // Step 5: peer proofs that failed verification
  peerImpersonations: 0,  // Step 5: peer hellos whose id != f(pubkey)
  learnedDialAttempts: 0, // Step 7: outbound dials to gossip-learned endpoints
  envelopes: { received: 0, forwarded: 0, delivered: 0, toRegistry: 0, dropped: 0 },
  onion: { forwarded: 0, delivered: 0, dropped: 0 }, // Step 6
  // Step 8: gossip byte accounting (aggregate only — totals and
  // the size of the most recently built gossip frame) and the
  // sharded-lookup counters.
  gossip: { bytesSent: 0, framesSent: 0, lastBytes: 0 },
  lookups: { sent: 0, forwarded: 0, answered: 0, resolved: 0, failed: 0 },
};

// Step 5: a peer link is VERIFIED when this relay runs with a
// roster, the peer's hello-proof passed (it holds the key behind
// its claimed id, right now), and that public key is on the
// roster. Without a roster nothing is verified — proof alone
// stops impersonation, not Sybil (design §5.2).
function linkVerified(link) {
  return !!(rosterSet && link && link.proofOk && link.pubkey
    && rosterSet.has(link.pubkey));
}
const pairs = new Set(); // live {client, upstream, queue, open} (Step 1)

function logCounts(note) {
  const total = counts.toRegistry + counts.toClient;
  console.log(`RELAY: ${note} peers=${pairs.size} forwarded=${total} `
    + `(to-registry=${counts.toRegistry} to-client=${counts.toClient})`);
}
function logPeers(note) {
  console.log(`RELAY: ${note} peer-links=${peerLinks.size} known-relays=${peerTable.size} `
    + `envelopes=(recv=${counts.envelopes.received} fwd=${counts.envelopes.forwarded} `
    + `delivered=${counts.envelopes.delivered} dropped=${counts.envelopes.dropped})`);
}

// ---- Step 2 state (ALL in memory, dies with the process) -------------
const peerLinks = new Set();   // {ws, relayId, endpoint, direction, established}
const seedLinks = new Map();   // seed url -> {url, backoff, timer}
// Step 8: table entries carry dist (relay hops to the subject:
// 0 = this relay / homed here, 1 = direct peer / homed at a
// direct peer, >= 2 = summary knowledge) and via (the relay id
// whose report set the current entry — the aim target for
// summary routing). Local entries (dist <= 1) expire on the
// Step 2 liveness window; summaries expire on the longer
// summary liveness and are capped by --max-summaries.
const peerTable = new Map();   // relayId -> {relayId, endpoint, onionPub, lastSeen, dist, via}
const attachedTable = new Map(); // nodeId -> {nodeId, relayId, lastSeen, dist, via}
const localAttach = new Map(); // nodeId -> client endpoint (live local socket)
const weights = new Map();     // relayId -> synaptic weight (direct peers)

// ---- Step 8 state (ALL in memory, dies with the process) -------------
// Rotating-window cursors for the summary tier of gossip: each
// built gossip frame advances the window through the summary
// set, so every summary is re-sent regularly but no single
// frame carries them all.
let summaryPeerCursor = 0;
let summaryAttachedCursor = 0;
// Sharded lookup: at most one outstanding lookup per
// destination; envelopes park behind it; failures are
// negative-cached so a hot unknown destination cannot make the
// matrix walk for every envelope.
const outstandingLookups = new Map(); // destId -> {timer}
const parkedForLookup = new Map();    // destId -> [{env, arrival}]
const negativeLookups = new Map();    // destId -> expiresAt (ms)
function summaryLivenessMs() { return ARGS.summaryLivenessSeconds * 1000; }
function summaryCount() {
  let n = 0;
  for (const e of peerTable.values()) if (e.dist >= 2) n++;
  for (const e of attachedTable.values()) if (e.dist >= 2) n++;
  return n;
}

// ---- Step 7 state (ALL in memory, dies with the process) -------------
// learnedDials: normalized endpoint -> {failures, backoff, nextOk,
// connecting} for endpoints learned from gossip (NOT seeds — seeds
// keep their own reconnect machinery in seedLinks). The cooldown
// is the discipline that keeps a dead or junk learned endpoint
// from being hammered: backoff starts at 1 s, doubles per
// consecutive failure, caps at 60 s, and resets when a dial
// completes a peer hello.
// knownPubkeys: relayId -> Ed25519 pubkey hex, recorded from peer
// hellos this relay has actually received. A relay's key is
// unknowable before first contact, so this map is what roster
// mode's verified-first dial ordering can honestly consult.
const learnedDials = new Map();
const knownPubkeys = new Map();
const LEARNED_BACKOFF_MIN_MS = 1000;
const LEARNED_BACKOFF_MAX_MS = 60000;

// ---- Step 4 state (ALL in memory, dies with the process) -------------
// seenAttached: every destination this relay has ever seen attached
// (locally or via gossip) -> lastSeen. This is the store-and-forward
// memory: an envelope is held only for a destination in this map.
// Entries are pruned on the gossip tick once they are older than
// max(4x the hold window, the liveness window) — long enough that a
// destination returning within its envelopes' hold is still "seen".
const seenAttached = new Map(); // nodeId -> lastSeen (ms)
// heldEnvelopes: destination -> [{env, expiresAt}] in arrival order.
// The envelope is stored AS RECEIVED (ttl/hop untouched); the hop
// is charged when it is finally routed on delivery.
const heldEnvelopes = new Map();
const heldStats = { delivered: 0, expired: 0 };
function heldCount() {
  let n = 0;
  for (const list of heldEnvelopes.values()) n += list.length;
  return n;
}
function markSeen(nodeId, when) {
  const prev = seenAttached.get(nodeId) || 0;
  if (when > prev) seenAttached.set(nodeId, when);
}

function ensureWeight(relayId) {
  if (!weights.has(relayId)) weights.set(relayId, 1.0);
  return weights.get(relayId);
}
function weightUp(relayId) {
  if (!relayId) return;
  weights.set(relayId, Math.min(10, ensureWeight(relayId) + 0.1));
}
function weightDown(relayId) {
  if (!relayId) return;
  weights.set(relayId, Math.max(0.1, ensureWeight(relayId) * 0.5));
}
// Step 8: evict summary entries (dist >= 2) beyond the
// --max-summaries bound for one table, oldest lastSeen first.
// Local entries are never evicted by the cap — they are few by
// construction (bounded by the peer cap and local sockets).
function evictSummaries(table, keyName) {
  const summaries = [];
  for (const e of table.values()) if (e.dist >= 2) summaries.push(e);
  if (summaries.length <= ARGS.maxSummaries) return;
  summaries.sort((a, b) => a.lastSeen - b.lastSeen);
  const excess = summaries.length - ARGS.maxSummaries;
  for (let i = 0; i < excess; i++) table.delete(summaries[i][keyName]);
}
function pruneTables(now) {
  const sumMs = summaryLivenessMs();
  for (const [id, e] of peerTable) {
    if (id === RELAY_ID) continue;
    const window = e.dist >= 2 ? sumMs : LIVENESS_WINDOW_MS;
    if (now - e.lastSeen > window) peerTable.delete(id);
  }
  for (const [id, e] of attachedTable) {
    const window = e.dist >= 2 ? sumMs : LIVENESS_WINDOW_MS;
    if (now - e.lastSeen > window) attachedTable.delete(id);
  }
  evictSummaries(peerTable, 'relayId');
  evictSummaries(attachedTable, 'nodeId');
  for (const [id, expiresAt] of negativeLookups) {
    if (now > expiresAt) negativeLookups.delete(id);
  }
  const seenHorizon = Math.max(4 * ARGS.holdSeconds * 1000, LIVENESS_WINDOW_MS);
  for (const [id, seen] of seenAttached) {
    if (now - seen > seenHorizon) seenAttached.delete(id);
  }
  // Step 7: learned-dial state for an endpoint long past its
  // cooldown is dead weight; drop it so the map cannot grow
  // without bound on junk endpoints. A state still inside its
  // cooldown is KEPT — pruning it would forgive the backoff.
  for (const [endpoint, st] of learnedDials) {
    if (!st.connecting && st.nextOk > 0
      && now - st.nextOk > 4 * LEARNED_BACKOFF_MAX_MS) {
      learnedDials.delete(endpoint);
    }
  }
}

// ---- HTTP: GET /health and GET /onion-key ------------------------------
// /health is aggregate only: relay id (as Step 1), client-pair
// count, live relay-peer count, synaptic weights keyed by last-8
// of relay id, envelope counts, Step 5 counts (roster mode,
// verified / unverified / proof-ok peer counts, impersonation
// and proof failure totals), Step 6 onion counts, Step 7
// capacity fields (caps, at-cap flags, learned dial attempts),
// and Step 8 scale fields (known-relay / known-attachment
// counts, summaries held, gossip byte totals, lookup counts).
// NO node
// ids, NO IPs, NO attached-node info, NO private keys. /onion-key
// is the one deliberate exception to "no public keys": it returns
// ONLY this relay's own current onion public key (public
// material, needed by senders), as documented at the handler.
function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}
function handleHttp(req, res) {
  const u = new URL(req.url, 'http://x');
  if (req.method === 'GET' && u.pathname === '/onion-key') {
    // Step 6: the relay's CURRENT ephemeral onion public key, and
    // nothing else. Public keys are public material — a sender
    // needs this to wrap a layer for this relay, the same way it
    // needs an Ed25519 pubkey to verify a signature. The endpoint
    // exposes no private material, no peer/attachment info, no
    // counts: exactly {relayId, onionPub}, by design.
    return sendJson(res, 200, { relayId: RELAY_ID, onionPub: ONION_PUB_HEX });
  }
  if (req.method === 'GET' && u.pathname === '/health') {
    return sendJson(res, 200, {
      ok: true,
      relay: RELAY_ID_SHORT,
      v: RELAY_VERSION,
      protocol: PROTOCOL,
      peers: pairs.size,
      relay_peers: peerLinks.size,
      max_peers: ARGS.maxPeers,
      max_clients: ARGS.maxClients,
      at_peer_cap: peerLinks.size >= ARGS.maxPeers,
      at_client_cap: pairs.size >= ARGS.maxClients,
      learned_dial_attempts: counts.learnedDialAttempts,
      known_relays: peerTable.size,
      known_attached: attachedTable.size,
      summaries_held: summaryCount(),
      max_summaries: ARGS.maxSummaries,
      gossip_summaries: ARGS.gossipSummaries,
      summary_liveness_seconds: ARGS.summaryLivenessSeconds,
      gossip_bytes_sent: counts.gossip.bytesSent,
      gossip_frames_sent: counts.gossip.framesSent,
      gossip_last_bytes: counts.gossip.lastBytes,
      lookups_sent: counts.lookups.sent,
      lookups_forwarded: counts.lookups.forwarded,
      lookups_answered: counts.lookups.answered,
      lookups_resolved: counts.lookups.resolved,
      lookups_failed: counts.lookups.failed,
      roster_mode: !!rosterSet,
      peers_verified: [...peerLinks].filter((l) => linkVerified(l)).length,
      peers_unverified: [...peerLinks].filter((l) => l.established && !linkVerified(l)).length,
      peers_proof_ok: [...peerLinks].filter((l) => l.proofOk).length,
      peer_impersonations: counts.peerImpersonations,
      proofs_failed: counts.proofsFailed,
      weights: [...weights.entries()].map(([id, w]) => ({
        peer: id.slice(-8),
        weight: Math.round(w * 1000) / 1000,
      })),
      envelopes: { ...counts.envelopes },
      onion_forwarded: counts.onion.forwarded,
      onion_delivered: counts.onion.delivered,
      onion_dropped: counts.onion.dropped,
      held_envelopes: heldCount(),
      held_delivered: heldStats.delivered,
      held_expired: heldStats.expired,
      hold_seconds: ARGS.holdSeconds,
      uptime_seconds: Math.round((Date.now() - startedAt) / 1000),
      forwarded: {
        to_registry: counts.toRegistry,
        to_client: counts.toClient,
        total: counts.toRegistry + counts.toClient,
      },
      connections_total: counts.connectionsTotal,
    });
  }
  return sendJson(res, 404, { ok: false, reason: 'not-found' });
}

// ---- Envelope detection ------------------------------------------------
// An envelope is a TEXT frame that parses as JSON with
// "relay":"v1", a string "to", and a string "payload". Gossip and
// peer-hello frames also carry "relay":"v1" but have no payload,
// so they are not envelopes. Everything else is a Step 1 raw frame.
function parseEnvelope(data, isBinary) {
  if (isBinary) return null;
  let obj;
  try { obj = JSON.parse(data.toString('utf8')); } catch (e) { return null; }
  if (obj && obj.relay === 'v1' && typeof obj.payload === 'string'
    && typeof obj.to === 'string') return obj;
  return null;
}

// An onion frame (Step 6) is a TEXT frame that parses as JSON
// with "relay":"v1", "type":"onion", and a "blob" that is a
// layer object (see onion.js). It has no "to"/"payload" — the
// routing information is inside the encrypted layer — so it
// never parses as an envelope.
function parseOnionFrame(data, isBinary) {
  if (isBinary) return null;
  let obj;
  try { obj = JSON.parse(data.toString('utf8')); } catch (e) { return null; }
  if (obj && obj.relay === 'v1' && obj.type === 'onion'
    && obj.blob && typeof obj.blob === 'object' && !Array.isArray(obj.blob)) {
    return obj;
  }
  return null;
}

// ---- Client sockets: paired raw mode + envelope mode -----------------
// A client socket starts UNDECIDED. Its FIRST frame chooses the mode
// for the life of the socket:
//
//  - First frame is a relay envelope -> ENVELOPE MODE (Step 4): no
//    upstream pairing is created. The socket sends and receives
//    envelopes only; anything else is dropped silently. Registry
//    downtime cannot touch this socket — there is nothing paired
//    to die — which is what lets a node's fog link run standalone.
//
//  - Anything else -> PAIRED RAW MODE (Step 1, unchanged): the pair
//    is a client WebSocket and an upstream WebSocket to the
//    registry, created lazily at that first frame, with messages
//    forwarded both ways as raw buffers — never parsed, never
//    rewritten, never re-signed. The mesh-auth session passes
//    through untouched; the registry authenticates the node exactly
//    as it does on a direct connection. Paired sockets can also
//    send envelopes mid-session (Step 2), routed as before.
//
// The upstream used to be created at connect time; creating it at
// the first raw frame is the only way to know the socket is not an
// envelope-mode socket. No client of the Step 1/2 protocol waits
// for an upstream-initiated frame before sending its first frame
// (the registry speaks first only in reply), so the laziness is
// invisible to them: their first frame still queues until the
// upstream handshake completes, exactly as before.
function handleConnection(client) {
  const endpoint = {
    client, mode: null, upstream: null, queue: [], open: false,
    pipe: null, pipeQueue: [],
  };
  pairs.add(endpoint);
  counts.connectionsTotal++;
  logCounts('client connected');

  let tornDown = false;
  const teardown = (upstreamFailed) => {
    if (tornDown) return;
    tornDown = true;
    pairs.delete(endpoint);
    // This client's attachments lose their live socket; the gossip
    // table entry itself expires by liveness, as designed.
    for (const [nodeId, ep] of localAttach) {
      if (ep === endpoint) localAttach.delete(nodeId);
    }
    if (endpoint.pipe) {
      try { endpoint.pipe.close(1000); } catch (e) {}
      endpoint.pipe = null;
      endpoint.pipeQueue = [];
    }
    if (upstreamFailed) {
      counts.upstreamFailures++;
      try { client.close(1011, 'relay upstream unavailable'); } catch (e) {}
    } else {
      try { if (client.readyState === WebSocket.OPEN) client.close(1000); } catch (e) {}
    }
    const upstream = endpoint.upstream;
    if (upstream) {
      try {
        if (upstream.readyState === WebSocket.OPEN
          || upstream.readyState === WebSocket.CONNECTING) upstream.close(1000);
      } catch (e) {}
    }
    logCounts('client disconnected');
  };
  endpoint.teardown = teardown;

  // Paired raw mode: create the Step 1 upstream pairing on demand.
  function ensureUpstream() {
    if (endpoint.upstream) return endpoint.upstream;
    const upstream = new WebSocket(ARGS.registry);
    endpoint.upstream = upstream;
    upstream.on('open', () => {
      endpoint.open = true;
      // Flush anything the client sent during the upstream handshake.
      for (const [data, isBinary] of endpoint.queue) {
        try { upstream.send(data, { binary: isBinary }); counts.toRegistry++; } catch (e) {}
      }
      endpoint.queue = [];
    });
    upstream.on('message', (data, isBinary) => {
      if (client.readyState === WebSocket.OPEN) {
        try { client.send(data, { binary: isBinary }); counts.toClient++; } catch (e) {}
      }
    });
    upstream.on('close', () => teardown(false));
    upstream.on('error', () => teardown(true));
    return upstream;
  }

  client.on('message', (data, isBinary) => {
    const env = parseEnvelope(data, isBinary);
    const onionFrame = env ? null : parseOnionFrame(data, isBinary);
    if (endpoint.mode === null) {
      // The first frame decides the socket's mode, permanently.
      // An onion frame as the first frame also selects envelope
      // mode (Step 6): the socket is a fog-style sender, not a
      // raw registry session.
      if (env) {
        endpoint.mode = 'envelope';
        handleEnvelope(env, { kind: 'client', endpoint });
        return;
      }
      if (onionFrame) {
        endpoint.mode = 'envelope';
        handleOnion(onionFrame, { kind: 'client', endpoint });
        return;
      }
      endpoint.mode = 'raw';
    }
    if (endpoint.mode === 'envelope') {
      // Envelope-mode sockets speak envelopes and onion frames only.
      if (env) handleEnvelope(env, { kind: 'client', endpoint });
      else if (onionFrame) handleOnion(onionFrame, { kind: 'client', endpoint });
      return;
    }
    // Paired raw mode. Step 2: envelopes are routed, not
    // raw-forwarded. Step 6: onion frames are peeled and routed,
    // not raw-forwarded. Everything else takes the Step 1 raw
    // path, byte-for-byte, unchanged.
    if (env) {
      handleEnvelope(env, { kind: 'client', endpoint });
      return;
    }
    if (onionFrame) {
      handleOnion(onionFrame, { kind: 'client', endpoint });
      return;
    }
    const upstream = ensureUpstream();
    if (endpoint.open && upstream.readyState === WebSocket.OPEN) {
      try { upstream.send(data, { binary: isBinary }); counts.toRegistry++; } catch (e) {}
    } else if (upstream.readyState === WebSocket.CONNECTING) {
      // The upstream handshake is still in flight: hold the frame
      // in memory and flush it on open. If the upstream never opens,
      // the pair is torn down and the queued frames die with it —
      // the client sees the drop and reconnects, as it does today.
      endpoint.queue.push([data, isBinary]);
    }
    // Upstream closing/closed: drop. The pair is being torn down.
  });

  client.on('close', () => teardown(false));
  client.on('error', () => teardown(false));
}

// ---- Per-socket registry pipe (envelope-mode clients only) -----------
// An envelope-mode socket has no pairing, but it may still address
// an envelope to "registry". That payload rides a lazily opened
// pipe dedicated to this socket, and the registry's replies return
// RAW to the socket (a registry session begun by an enveloped
// hello expects its challenge back). The pipe is not a pairing:
// it opens only when the socket asks for the registry, and its
// failure drops the queued payloads and is forgotten — the client
// socket is never closed because a pipe died.
function sendViaSocketPipe(endpoint, payloadStr) {
  if (endpoint.pipe && endpoint.pipe.readyState === WebSocket.OPEN) {
    try {
      endpoint.pipe.send(payloadStr);
      counts.toRegistry++; counts.envelopes.toRegistry++;
      return true;
    } catch (e) { return false; }
  }
  if (!endpoint.pipe) {
    const ws = new WebSocket(ARGS.registry);
    endpoint.pipe = ws;
    ws.on('open', () => {
      for (const p of endpoint.pipeQueue) {
        try { ws.send(p); counts.toRegistry++; counts.envelopes.toRegistry++; }
        catch (e) { counts.envelopes.dropped++; }
      }
      endpoint.pipeQueue = [];
    });
    ws.on('message', (data, isBinary) => {
      if (endpoint.client.readyState === WebSocket.OPEN) {
        try { endpoint.client.send(data, { binary: isBinary }); counts.toClient++; }
        catch (e) {}
      }
    });
    const reset = () => {
      if (endpoint.pipe === ws) {
        endpoint.pipe = null;
        if (endpoint.pipeQueue.length) {
          counts.envelopes.dropped += endpoint.pipeQueue.length;
          endpoint.pipeQueue = [];
        }
      }
    };
    ws.on('close', reset);
    ws.on('error', reset);
  }
  endpoint.pipeQueue.push(payloadStr);
  return true;
}

// ---- Shared upstream pipe (envelopes to "registry" from peers) -------
// A locally attached client's registry-bound envelope rides its own
// pair upstream (above). An envelope that arrived from a PEER has
// no pair, so it rides this one lazily-opened pipe to the registry.
// Registry replies on the pipe have no client to deliver to and are
// counted and dropped — the pipe exists for one-way delivery of
// node-originated payloads that reached this relay by peer hops.
const registryPipe = { ws: null, queue: [] };
function sendViaRegistryPipe(payloadStr) {
  if (registryPipe.ws && registryPipe.ws.readyState === WebSocket.OPEN) {
    try { registryPipe.ws.send(payloadStr); counts.envelopes.toRegistry++; return true; }
    catch (e) { return false; }
  }
  if (!registryPipe.ws) {
    const ws = new WebSocket(ARGS.registry);
    registryPipe.ws = ws;
    ws.on('open', () => {
      for (const p of registryPipe.queue) {
        try { ws.send(p); counts.envelopes.toRegistry++; } catch (e) {}
      }
      registryPipe.queue = [];
    });
    ws.on('message', () => { /* no client to deliver to: drop */ });
    const reset = () => { if (registryPipe.ws === ws) registryPipe.ws = null; };
    ws.on('close', reset);
    ws.on('error', reset);
  }
  registryPipe.queue.push(payloadStr);
  return true;
}

// ---- Envelope routing (Step 2) -----------------------------------------
function recordAttachment(env, arrival) {
  if (typeof env.from !== 'string' || !env.from) return;
  const now = Date.now();
  if (arrival.kind === 'client') {
    const isNew = !localAttach.has(env.from);
    localAttach.set(env.from, arrival.endpoint);
    attachedTable.set(env.from, {
      nodeId: env.from, relayId: RELAY_ID, lastSeen: now, dist: 0, via: RELAY_ID,
    });
    markSeen(env.from, now);
    // A new attachment is worth an immediate gossip burst so peers
    // learn the route without waiting for the periodic interval
    // (bursts are rate-limited — see burstGossip).
    if (isNew) burstGossip();
    // And it may release held envelopes addressed to this node.
    tryDeliverHeld(env.from);
  }
  // Attachments arriving from peers are learned from gossip only —
  // the previous hop is not necessarily the holding relay.
}

// ---- Store-and-forward (Step 4) ----------------------------------------
// Hold an envelope for a SEEN-but-undeliverable destination. The
// envelope is stored as received; expiry is swept by holdTimer.
function holdEnvelope(env) {
  const list = heldEnvelopes.get(env.to) || [];
  if (list.length >= HOLD_PER_DEST_CAP) {
    counts.envelopes.dropped++;
    return;
  }
  list.push({ env: { ...env }, expiresAt: Date.now() + ARGS.holdSeconds * 1000 });
  heldEnvelopes.set(env.to, list);
}

// Try to deliver everything held for one destination, in arrival
// order: locally if it is attached here now, else by forwarding to
// the relay gossip says holds it (the stored envelope must still
// have a hop of ttl left for that). Anything still undeliverable
// stays held until it expires.
function tryDeliverHeld(nodeId) {
  const list = heldEnvelopes.get(nodeId);
  if (!list || list.length === 0) return;
  const endpoint = localAttach.get(nodeId);
  if (endpoint && endpoint.client.readyState === WebSocket.OPEN) {
    for (const item of list) {
      const out = {
        ...item.env,
        ttl: (typeof item.env.ttl === 'number' ? item.env.ttl : DEFAULT_ENVELOPE_TTL) - 1,
        hop: (typeof item.env.hop === 'number' ? item.env.hop : 0) + 1,
      };
      try {
        endpoint.client.send(JSON.stringify(out));
        counts.envelopes.delivered++;
        heldStats.delivered++;
      } catch (e) { counts.envelopes.dropped++; }
    }
    heldEnvelopes.delete(nodeId);
    return;
  }
  const holder = attachedTable.get(nodeId);
  if (holder && holder.relayId !== RELAY_ID) {
    let link = [...peerLinks].find((l) => l.relayId === holder.relayId
      && l.ws.readyState === WebSocket.OPEN);
    // Step 8: no direct link to a summary-known holder — aim at
    // the peer that reported the summary; it re-aims from its
    // own fresher knowledge (see aimLinkToward).
    if (!link) link = aimLinkToward(holder, null);
    // Step 5 roster preference: never hand held mail to an
    // unverified holder link while a verified peer exists — the
    // verified peer routes onward toward the holder instead.
    if (link && rosterSet && !linkVerified(link)) {
      const alt = pickWeightedPeer(null);
      if (alt && linkVerified(alt)) link = alt;
    }
    if (link) {
      const remaining = [];
      for (const item of list) {
        const ttl = typeof item.env.ttl === 'number' ? item.env.ttl : DEFAULT_ENVELOPE_TTL;
        if (ttl - 1 <= 0) { remaining.push(item); continue; }
        const out = {
          ...item.env, ttl: ttl - 1,
          hop: (typeof item.env.hop === 'number' ? item.env.hop : 0) + 1,
        };
        if (sendToPeerLink(link, JSON.stringify(out))) {
          counts.envelopes.forwarded++;
          heldStats.delivered++;
        } else {
          counts.envelopes.dropped++;
        }
      }
      if (remaining.length) heldEnvelopes.set(nodeId, remaining);
      else heldEnvelopes.delete(nodeId);
    }
  }
}
function tryDeliverAllHeld() {
  for (const nodeId of [...heldEnvelopes.keys()]) tryDeliverHeld(nodeId);
}

// Expiry sweep: held envelopes past their hold window drop
// silently (counted in held_expired, never written anywhere).
const holdTimer = setInterval(() => {
  const now = Date.now();
  for (const [nodeId, list] of heldEnvelopes) {
    const keep = list.filter((item) => item.expiresAt > now);
    heldStats.expired += list.length - keep.length;
    if (keep.length) heldEnvelopes.set(nodeId, keep);
    else heldEnvelopes.delete(nodeId);
  }
}, HOLD_SWEEP_MS);
holdTimer.unref();

function sendToPeerLink(link, str) {
  if (!link || link.ws.readyState !== WebSocket.OPEN) {
    weightDown(link && link.relayId);
    return false;
  }
  try {
    link.ws.send(str, (err) => { if (err) weightDown(link.relayId); });
    weightUp(link.relayId);
    return true;
  } catch (e) {
    weightDown(link.relayId);
    return false;
  }
}

// Synaptic-weighted random selection among live peer links,
// proportional to weight, excluding the arrival link. Step 5
// roster preference: when this relay runs with a roster and any
// candidate is VERIFIED (proof passed + key on the roster), the
// candidate set is restricted to verified links — unverified
// links carry wander traffic only when no verified candidate
// exists. Without a roster, selection is exactly as in v0.3.
// Step 7 refinement: the verified set is evaluated against ALL
// open links BEFORE the arrival link is excluded. With
// auto-join, a relay can hold unverified links it never chose;
// if the only verified link is the arrival link, the old order
// (exclude first, then test) spilled wander traffic to an
// unverified peer even though a verified link was up. Now the
// envelope drops instead — in roster mode, unverified links
// carry wander traffic only when NO verified link is up at all.
function pickWeightedPeer(excludeLink) {
  const open = [...peerLinks].filter((l) => l.ws.readyState === WebSocket.OPEN);
  let candidates = open.filter((l) => l !== excludeLink);
  if (rosterSet) {
    if (open.some((l) => linkVerified(l))) {
      candidates = candidates.filter((l) => linkVerified(l));
    }
  }
  if (candidates.length === 0) return null;
  let total = 0;
  for (const l of candidates) total += l.relayId ? ensureWeight(l.relayId) : 1.0;
  let r = Math.random() * total;
  for (const l of candidates) {
    r -= l.relayId ? ensureWeight(l.relayId) : 1.0;
    if (r <= 0) return l;
  }
  return candidates[candidates.length - 1];
}

// ---- Step 8: routing with summaries + sharded lookup -------------------
// The next hop TOWARD a summary-known home relay: the live link
// to the peer whose report set the current table entry (its
// `via`). That peer holds fresher knowledge (its dist to the
// home is one less), so each hop re-aims and the envelope walks
// home. Returns null when no via link is open or the only one
// is the excluded (arrival) link.
function aimLinkToward(entry, excludeLink) {
  if (!entry || !entry.via || entry.via === RELAY_ID) return null;
  const link = [...peerLinks].find((l) => l !== excludeLink
    && l.relayId === entry.via && l.ws.readyState === WebSocket.OPEN);
  return link || null;
}

// XOR distance over SHA-256 of the ids (Kademlia-style), as a
// BigInt. Used only to choose the lookup walk direction.
function idHashBig(id) {
  return BigInt('0x' + crypto.createHash('sha256').update(String(id), 'utf8').digest('hex'));
}
function xorDist(a, b) { return a ^ b; }

// Choose the peer link that should carry a lookup for destId
// one hop further: among open links with a known relay id, not
// the arrival link and not a relay already on the path, the one
// whose id hash is CLOSEST to the destination's hash — with the
// honest best-effort relaxation that if no candidate is
// strictly closer than this relay, the closest unvisited peer
// is used anyway (the walk degenerates to a bounded chain walk
// rather than giving up; ttl + the path bound it).
function pickLookupPeer(destId, excludeLink, path) {
  const target = idHashBig(destId);
  const myDist = xorDist(idHashBig(RELAY_ID), target);
  const visited = new Set(path || []);
  const open = [...peerLinks].filter((l) => l.relayId
    && l.ws.readyState === WebSocket.OPEN && l !== excludeLink
    && !visited.has(l.relayId));
  if (open.length === 0) return null;
  let best = null; let bestDist = null;
  for (const l of open) {
    const d = xorDist(idHashBig(l.relayId), target);
    if (bestDist === null || d < bestDist) { best = l; bestDist = d; }
  }
  if (bestDist < myDist) return best;
  return best; // best-effort: closest unvisited, even if not closer
}

// Send a lookup-answer back along the reverse path. rpath lists
// the relays the answer must still traverse, in order; the
// first element is the next hop. Each forwarder pops itself.
// If the next hop's link is gone the answer dies silently — the
// origin's timeout + negative cache is the backstop.
function sendLookupAnswer(answer, rpath) {
  if (!rpath || rpath.length === 0) return;
  const next = rpath[0];
  const link = [...peerLinks].find((l) => l.relayId === next
    && l.ws.readyState === WebSocket.OPEN);
  if (!link) return;
  try {
    link.ws.send(JSON.stringify({ ...answer, rpath: rpath.slice(1) }));
  } catch (e) { /* origin timeout is the backstop */ }
}

// Originate an answer for a lookup this relay can resolve (or
// definitively cannot — the closest relay on the walk says
// not-found so the origin falls back fast instead of waiting
// out its timeout).
function answerLookup(frame, found, homeRelayId, homeDist) {
  counts.lookups.answered++;
  const answer = {
    relay: 'v1', type: 'lookup-answer', id: frame.id, origin: frame.origin,
    found: !!found, home: found ? homeRelayId : null,
    // hops = links the lookup traveled to reach the answerer;
    // homeDist = the answerer's own dist to the home relay.
    // The origin caches dist = hops + homeDist.
    hops: Array.isArray(frame.path) ? frame.path.length : 0,
    homeDist: typeof homeDist === 'number' ? homeDist : 0,
  };
  sendLookupAnswer(answer, [...(frame.path || [])].reverse());
}

// A lookup frame arrives on a peer link. Resolve it here if
// possible; otherwise walk it one hash-directed hop further.
function handleLookup(frame, arrivalLink) {
  if (typeof frame.id !== 'string' || typeof frame.origin !== 'string'
    || !Array.isArray(frame.path)) return;
  const ttl = typeof frame.ttl === 'number' ? frame.ttl : LOOKUP_TTL;
  // Do we hold the destination — locally attached, or in the
  // attachment table at any dist (a summary is enough to aim
  // the origin's envelope)?
  if (localAttach.has(frame.id)) { answerLookup(frame, true, RELAY_ID, 0); return; }
  const entry = attachedTable.get(frame.id);
  if (entry) { answerLookup(frame, true, entry.relayId, entry.dist); return; }
  if (ttl <= 1) { answerLookup(frame, false, null, 0); return; }
  const next = pickLookupPeer(frame.id, arrivalLink, frame.path);
  if (!next) { answerLookup(frame, false, null, 0); return; }
  counts.lookups.forwarded++;
  const out = { ...frame, ttl: ttl - 1, path: [...frame.path, RELAY_ID] };
  try { next.ws.send(JSON.stringify(out)); } catch (e) { answerLookup(frame, false, null, 0); }
}

// A lookup-answer arrives. If it is ours, resolve the parked
// envelopes; otherwise pop the next hop off rpath and forward.
function handleLookupAnswer(frame, arrivalLink) {
  if (frame.origin !== RELAY_ID) {
    if (Array.isArray(frame.rpath) && frame.rpath.length > 0) {
      sendLookupAnswer({
        relay: 'v1', type: 'lookup-answer', id: frame.id, origin: frame.origin,
        found: !!frame.found, home: frame.home || null,
        hops: typeof frame.hops === 'number' ? frame.hops : 0,
        homeDist: typeof frame.homeDist === 'number' ? frame.homeDist : 0,
      }, frame.rpath);
    }
    return;
  }
  const destId = frame.id;
  const outstanding = outstandingLookups.get(destId);
  if (!outstanding) return; // late or duplicate answer: nothing parked
  clearTimeout(outstanding.timer);
  outstandingLookups.delete(destId);
  const parked = parkedForLookup.get(destId) || [];
  parkedForLookup.delete(destId);
  if (frame.found && typeof frame.home === 'string') {
    counts.lookups.resolved++;
    // Cache the answer as a summary: dist = links the lookup
    // traveled + the answerer's own dist to the home relay,
    // via = the link the answer arrived on. Newest-lastSeen-wins
    // is honored against any entry gossip delivered meanwhile.
    const now = Date.now();
    const prev = attachedTable.get(destId);
    if (!prev || now >= prev.lastSeen) {
      attachedTable.set(destId, {
        nodeId: destId, relayId: frame.home, lastSeen: now,
        dist: (typeof frame.hops === 'number' ? frame.hops : 1)
          + (typeof frame.homeDist === 'number' ? frame.homeDist : 0),
        via: arrivalLink && arrivalLink.relayId ? arrivalLink.relayId : frame.home,
      });
    }
    markSeen(destId, now);
    for (const item of parked) routeEnvelope(item.env, item.arrival, true);
  } else {
    counts.lookups.failed++;
    negativeLookups.set(destId, Date.now() + LOOKUP_NEGATIVE_SECONDS * 1000);
    for (const item of parked) routeEnvelope(item.env, item.arrival, true);
  }
}

// A lookup went unanswered in time: negative-cache the
// destination and release the parked envelopes to the ordinary
// fallback (wander while ttl allows, else drop — the v0.2
// behavior for never-seen destinations).
function failLookup(destId) {
  if (!outstandingLookups.has(destId)) return;
  outstandingLookups.delete(destId);
  counts.lookups.failed++;
  negativeLookups.set(destId, Date.now() + LOOKUP_NEGATIVE_SECONDS * 1000);
  const parked = parkedForLookup.get(destId) || [];
  parkedForLookup.delete(destId);
  for (const item of parked) routeEnvelope(item.env, item.arrival, true);
}

// Route an envelope that is not deliverable locally: direct
// holder hop, summary aim, store-and-forward hold, sharded
// lookup, wander — in that order. Called by handleEnvelope for
// fresh envelopes and by the lookup machinery for parked ones
// (skipLookup=true once a lookup has had its chance).
function routeEnvelope(env, arrival, skipLookup) {
  const ttl = typeof env.ttl === 'number' ? env.ttl : DEFAULT_ENVELOPE_TTL;
  const hop = typeof env.hop === 'number' ? env.hop : 0;
  const out = { ...env, ttl: ttl - 1, hop: hop + 1 };
  const exclude = arrival.kind === 'peer' ? arrival.link : null;

  // Gossip names a holder relay for this destination.
  const holder = attachedTable.get(env.to);
  let holderLink = null;
  if (holder && holder.relayId !== RELAY_ID) {
    holderLink = [...peerLinks].find((l) => l !== exclude
      && l.relayId === holder.relayId
      && l.ws.readyState === WebSocket.OPEN) || null;
    // Step 8: no direct link — aim toward the home relay via
    // the peer that reported the summary.
    if (!holderLink) holderLink = aimLinkToward(holder, exclude);
  }
  // Step 5 roster preference: if the chosen link is unverified
  // but a verified candidate exists, route via a verified peer
  // instead (pickWeightedPeer restricts to verified in roster
  // mode); the verified peer forwards onward toward the holder.
  if (holderLink && rosterSet && !linkVerified(holderLink)) {
    const alt = pickWeightedPeer(exclude);
    if (alt && linkVerified(alt)) holderLink = alt;
  }
  if (holderLink) {
    if (ttl - 1 <= 0) { counts.envelopes.dropped++; return; }
    if (sendToPeerLink(holderLink, JSON.stringify(out))) counts.envelopes.forwarded++;
    else counts.envelopes.dropped++;
    return;
  }

  // Step 4 store-and-forward: the destination has been SEEN
  // attached (here or via gossip) but is not currently
  // deliverable — not attached anywhere reachable, or its
  // holder relay's link is down. Hold it in memory instead of
  // wandering or dropping.
  if (seenAttached.has(env.to)) { holdEnvelope(env); return; }

  // Step 8 sharded lookup: never seen, no summary — ask the
  // matrix before falling back to the wander. Bounded: one
  // outstanding lookup per destination, parked envelopes
  // capped, failures negative-cached for 30 s.
  if (!skipLookup && ttl - 1 > 0 && peerLinks.size > 0) {
    const negExpires = negativeLookups.get(env.to) || 0;
    if (Date.now() >= negExpires) {
      let parked = parkedForLookup.get(env.to);
      if (!parked && parkedForLookup.size >= LOOKUP_PARK_DEST_CAP) {
        // Too many destinations parked already: fall through
        // to the wander for this envelope.
      } else {
        if (!parked) { parked = []; parkedForLookup.set(env.to, parked); }
        if (parked.length < LOOKUP_PARK_PER_DEST_CAP) {
          parked.push({ env, arrival });
          if (!outstandingLookups.has(env.to)) {
            const first = pickLookupPeer(env.to, exclude, [RELAY_ID]);
            if (first) {
              counts.lookups.sent++;
              const timer = setTimeout(() => failLookup(env.to), LOOKUP_TIMEOUT_MS);
              timer.unref();
              outstandingLookups.set(env.to, { timer });
              try {
                first.ws.send(JSON.stringify({
                  relay: 'v1', type: 'lookup', id: env.to,
                  origin: RELAY_ID, ttl: LOOKUP_TTL, path: [RELAY_ID],
                }));
              } catch (e) { failLookup(env.to); }
            } else {
              // No usable peer after all: release the parked
              // envelope straight to the fallback.
              parkedForLookup.delete(env.to);
              routeEnvelope(env, arrival, true);
            }
          }
          return;
        }
        // Parked cap reached for this destination: fall through
        // to the wander for this envelope.
      }
    }
  }

  // Never-seen destination (or lookup already had its chance):
  // the v0.2 behavior stands — wander to a weighted peer while
  // the ttl budget covers the hop, else drop.
  if (ttl - 1 <= 0) { counts.envelopes.dropped++; return; }
  const target = pickWeightedPeer(exclude);
  if (!target) { counts.envelopes.dropped++; return; }
  if (sendToPeerLink(target, JSON.stringify(out))) counts.envelopes.forwarded++;
  else counts.envelopes.dropped++;
}

function handleEnvelope(env, arrival) {
  counts.envelopes.received++;
  const ttl = typeof env.ttl === 'number' ? env.ttl : DEFAULT_ENVELOPE_TTL;
  const hop = typeof env.hop === 'number' ? env.hop : 0;
  if (ttl <= 0) { counts.envelopes.dropped++; return; }
  recordAttachment(env, arrival);
  const out = { ...env, ttl: ttl - 1, hop: hop + 1 };

  // Addressed to the literal "relay": a control envelope for THIS
  // relay (a node's announce). The attachment is already recorded;
  // the envelope is consumed — delivered nowhere, forwarded nowhere.
  if (env.to === 'relay') return;

  // To the registry: the payload leaves as a RAW frame, byte-for-byte.
  if (env.to === 'registry') {
    if (arrival.kind === 'client' && arrival.endpoint.mode === 'raw') {
      const endpoint = arrival.endpoint;
      const payloadBuf = Buffer.from(env.payload, 'utf8');
      const upstream = endpoint.upstream;
      if (endpoint.open && upstream && upstream.readyState === WebSocket.OPEN) {
        try { upstream.send(payloadBuf); counts.toRegistry++; counts.envelopes.toRegistry++; }
        catch (e) { counts.envelopes.dropped++; }
      } else if (upstream && upstream.readyState === WebSocket.CONNECTING) {
        endpoint.queue.push([payloadBuf, false]);
        counts.envelopes.toRegistry++;
      } else {
        counts.envelopes.dropped++;
      }
    } else if (arrival.kind === 'client') {
      // Envelope-mode client: its own lazily opened pipe.
      if (!sendViaSocketPipe(arrival.endpoint, env.payload)) {
        counts.envelopes.dropped++;
      }
    } else if (!sendViaRegistryPipe(env.payload)) {
      counts.envelopes.dropped++;
    }
    return;
  }

  // Addressed to this relay itself by id: deliver nowhere, drop.
  if (env.to === RELAY_ID) { counts.envelopes.dropped++; return; }

  // Addressed to a client attached to THIS relay: deliver locally.
  const localEndpoint = localAttach.get(env.to);
  if (localEndpoint && localEndpoint.client.readyState === WebSocket.OPEN) {
    try {
      localEndpoint.client.send(JSON.stringify(out));
      counts.envelopes.delivered++;
    } catch (e) { counts.envelopes.dropped++; }
    return;
  }

  // Not deliverable locally: holder hop, summary aim, hold,
  // lookup, wander — routeEnvelope (Step 8) decides.
  routeEnvelope(env, arrival, false);
}

// ---- Onion routing (Step 6) ---------------------------------------------
// Peel ONE layer of an onion frame with this relay's ephemeral
// onion private key and act on the plaintext {next, body}:
//  - Intermediate layer (body is the next relay's layer object):
//    forward the still-wrapped body to the peer link for `next`.
//    A successful send feeds that peer's synaptic weight via
//    sendToPeerLink, exactly like an envelope forward.
//  - Innermost layer (body is {final:true, to, payload} and
//    `next` names its destination): deliver. A locally attached
//    node receives a plain envelope {relay:"v1", to,
//    from:"onion", payload} — the sender is never named, because
//    the exit relay does not know it. "registry" extracts the
//    payload as a raw frame by the same paths envelope registry
//    extraction uses.
//  - Anything else — AEAD failure (wrong key or tampered layer),
//    malformed plaintext, ttl exhausted, next hop unknown or
//    unreachable: drop silently, counted in onion_dropped.
// Onion frames are NEVER held (store-and-forward does not
// apply): an intermediate relay cannot know the final
// destination, so there is no destination to hold for; the exit
// relay learns it only in the moment it can deliver locally, or
// not at all.
function handleOnion(frame, arrival) {
  const ttl = typeof frame.ttl === 'number' ? frame.ttl : DEFAULT_ENVELOPE_TTL;
  const hop = typeof frame.hop === 'number' ? frame.hop : 0;
  if (ttl <= 0) { counts.onion.dropped++; return; }
  let plain;
  try {
    plain = onion.peelOnion(frame.blob, onionKeys.privateKey);
  } catch (e) {
    counts.onion.dropped++;
    return;
  }
  if (!plain || typeof plain.next !== 'string' || !plain.body
    || typeof plain.body !== 'object' || Array.isArray(plain.body)) {
    counts.onion.dropped++;
    return;
  }

  if (plain.body.final === true) {
    if (typeof plain.body.payload !== 'string'
      || (typeof plain.body.to === 'string' && plain.body.to !== plain.next)) {
      counts.onion.dropped++;
      return;
    }
    if (plain.next === 'registry') {
      if (deliverOnionPayloadToRegistry(plain.body.payload, arrival)) {
        counts.onion.delivered++;
      } else {
        counts.onion.dropped++;
      }
      return;
    }
    const localEndpoint = localAttach.get(plain.next);
    if (localEndpoint && localEndpoint.client.readyState === WebSocket.OPEN) {
      try {
        localEndpoint.client.send(JSON.stringify({
          relay: 'v1', to: plain.next, from: 'onion', payload: plain.body.payload,
        }));
        counts.onion.delivered++;
      } catch (e) { counts.onion.dropped++; }
    } else {
      counts.onion.dropped++;
    }
    return;
  }

  if (ttl - 1 <= 0) { counts.onion.dropped++; return; }
  const link = [...peerLinks].find((l) => l.relayId === plain.next
    && l.ws.readyState === WebSocket.OPEN);
  if (!link) { counts.onion.dropped++; return; } // unreachable: drop, NEVER hold
  const out = {
    relay: 'v1', type: 'onion', blob: plain.body, ttl: ttl - 1, hop: hop + 1,
  };
  if (sendToPeerLink(link, JSON.stringify(out))) counts.onion.forwarded++;
  else counts.onion.dropped++;
}

// Registry extraction for an exit-layer onion payload: the same
// three paths handleEnvelope uses for envelopes to "registry"
// (the sender's own pair upstream / its per-socket pipe / the
// shared pipe for peer arrivals).
function deliverOnionPayloadToRegistry(payloadStr, arrival) {
  if (arrival.kind === 'client' && arrival.endpoint.mode === 'raw') {
    const endpoint = arrival.endpoint;
    const payloadBuf = Buffer.from(payloadStr, 'utf8');
    const upstream = endpoint.upstream;
    if (endpoint.open && upstream && upstream.readyState === WebSocket.OPEN) {
      try {
        upstream.send(payloadBuf);
        counts.toRegistry++; counts.envelopes.toRegistry++;
        return true;
      } catch (e) { return false; }
    }
    if (upstream && upstream.readyState === WebSocket.CONNECTING) {
      endpoint.queue.push([payloadBuf, false]);
      counts.envelopes.toRegistry++;
      return true;
    }
    return false;
  }
  if (arrival.kind === 'client') return sendViaSocketPipe(arrival.endpoint, payloadStr);
  return sendViaRegistryPipe(payloadStr);
}

// ---- Gossip (Step 8: tiered) ----------------------------------------------
// The gossip frame carries two tiers:
//  - LOCAL tier (peers / attached): full entries for this relay,
//    its direct peers, and attachments homed at either — the
//    entries whose dist here is <= 1.
//  - SUMMARY tier (sumPeers / sumAttached): compact entries for
//    everything known beyond the local tier, sent through a
//    rotating window of --gossip-summaries entries per class.
// A relay whose local tier is small therefore sends a roughly
// constant-size frame however wide the network grows; summaries
// still reach everyone, just spread over successive frames.
// A summary's lastSeen is the HOME relay's observation time and
// is never refreshed by re-gossip, so stale summaries expire on
// the summary liveness wherever they are held.
function rotateWindow(entries, cursorName, size) {
  if (entries.length === 0 || size <= 0) return [];
  if (entries.length <= size) return entries;
  const start = (cursorName === 'peers' ? summaryPeerCursor : summaryAttachedCursor)
    % entries.length;
  const out = [];
  for (let i = 0; i < size; i++) out.push(entries[(start + i) % entries.length]);
  if (cursorName === 'peers') summaryPeerCursor += size;
  else summaryAttachedCursor += size;
  return out;
}
function buildGossip() {
  const now = Date.now();
  peerTable.set(RELAY_ID, {
    relayId: RELAY_ID,
    ...(ARGS.advertise ? { endpoint: ARGS.advertise } : {}),
    // Step 6: gossip peer entries carry the relay's current
    // ephemeral onion public key, so a sender that learns the
    // matrix by gossip can wrap layers for relays it has no
    // direct link to. Optional/backward-compatible.
    onionPub: ONION_PUB_HEX,
    lastSeen: now,
    dist: 0, via: RELAY_ID,
  });
  pruneTables(now);
  const byId = (a, b) => (a.relayId || a.nodeId) < (b.relayId || b.nodeId) ? -1 : 1;
  const localPeers = [];
  const remotePeers = [];
  for (const e of peerTable.values()) (e.dist <= 1 ? localPeers : remotePeers).push(e);
  const localAttached = [];
  const remoteAttached = [];
  for (const e of attachedTable.values()) (e.dist <= 1 ? localAttached : remoteAttached).push(e);
  remotePeers.sort(byId);
  remoteAttached.sort(byId);
  return {
    relay: 'v1',
    type: 'gossip',
    from: RELAY_ID,
    peers: localPeers.map((e) => ({
      relayId: e.relayId,
      ...(e.endpoint ? { endpoint: e.endpoint } : {}),
      ...(e.onionPub ? { onionPub: e.onionPub } : {}),
      lastSeen: e.lastSeen,
    })),
    attached: localAttached.map((e) => ({
      nodeId: e.nodeId, relayId: e.relayId, lastSeen: e.lastSeen,
    })),
    sumPeers: rotateWindow(remotePeers, 'peers', ARGS.gossipSummaries).map((e) => ({
      relayId: e.relayId,
      ...(e.endpoint ? { endpoint: e.endpoint } : {}),
      ...(e.onionPub ? { onionPub: e.onionPub } : {}),
      lastSeen: e.lastSeen, dist: e.dist,
    })),
    sumAttached: rotateWindow(remoteAttached, 'attached', ARGS.gossipSummaries).map((e) => ({
      nodeId: e.nodeId, relayId: e.relayId, lastSeen: e.lastSeen, dist: e.dist,
    })),
  };
}
function broadcastGossip() {
  const msg = JSON.stringify(buildGossip());
  const bytes = Buffer.byteLength(msg);
  counts.gossip.lastBytes = bytes;
  for (const link of peerLinks) {
    if (link.ws.readyState === WebSocket.OPEN) {
      try {
        link.ws.send(msg);
        counts.gossip.bytesSent += bytes;
        counts.gossip.framesSent++;
      } catch (e) { /* link teardown handles it */ }
    }
  }
}
// Event-driven gossip bursts (peer hello completed, new local
// attachment) are rate-limited to one per second (Step 8 fix,
// scale run): during matrix assembly, hellos complete in
// storms, and an unrated burst per hello multiplied into
// megabytes of redundant gossip on busy relays. The periodic
// 5 s tick is NOT rate-limited — it is the metronome — and in
// calm conditions the first burst after any quiet second
// still fires immediately, so small-matrix convergence speed
// is unchanged.
let lastGossipBurstAt = 0;
function burstGossip() {
  const now = Date.now();
  if (now - lastGossipBurstAt < 1000) return;
  lastGossipBurstAt = now;
  broadcastGossip();
}
// Merge one gossiped peer observation. candidateDist is the
// distance the subject sits at FROM THIS RELAY via the sender:
// 1 for the sender itself, 2 for a member of the sender's local
// tier, reported dist + 1 for a summary. Newest lastSeen wins;
// an equal lastSeen breaks toward the smaller dist. An
// observation already older than its tier's liveness window is
// refused — re-gossip must not resurrect the dead.
function mergePeerObservation(p, candidateDist, fromId, now) {
  if (!p || typeof p.relayId !== 'string' || p.relayId === RELAY_ID) return;
  // A relay with a live link here is one hop away by definition,
  // whoever reported it — dist describes reachability from HERE.
  if ([...peerLinks].some((l) => l.relayId === p.relayId
    && l.ws.readyState === WebSocket.OPEN)) candidateDist = Math.min(candidateDist, 1);
  const seen = typeof p.lastSeen === 'number' ? p.lastSeen : 0;
  const window = candidateDist >= 2 ? summaryLivenessMs() : LIVENESS_WINDOW_MS;
  if (now - seen > window) return;
  const prev = peerTable.get(p.relayId);
  if (!prev || seen > prev.lastSeen
    || (seen === prev.lastSeen && candidateDist < prev.dist)) {
    peerTable.set(p.relayId, {
      relayId: p.relayId,
      endpoint: p.endpoint || (prev && prev.endpoint) || undefined,
      onionPub: (onion.isOnionPubHex(p.onionPub) ? p.onionPub : null)
        || (prev && prev.onionPub) || undefined,
      lastSeen: seen,
      dist: candidateDist,
      via: fromId,
    });
  }
}
function mergeAttachedObservation(a, candidateDist, fromId, now) {
  if (!a || typeof a.nodeId !== 'string' || typeof a.relayId !== 'string') return;
  // Same reachability clamp: an attachment whose home relay has
  // a live link here is one hop from delivery, whoever said so.
  if (a.relayId === RELAY_ID) candidateDist = 0;
  else if ([...peerLinks].some((l) => l.relayId === a.relayId
    && l.ws.readyState === WebSocket.OPEN)) candidateDist = Math.min(candidateDist, 1);
  const seen = typeof a.lastSeen === 'number' ? a.lastSeen : 0;
  const window = candidateDist >= 2 ? summaryLivenessMs() : LIVENESS_WINDOW_MS;
  if (now - seen > window) return;
  const prev = attachedTable.get(a.nodeId);
  if (!prev || seen > prev.lastSeen
    || (seen === prev.lastSeen && candidateDist < prev.dist)) {
    attachedTable.set(a.nodeId, {
      nodeId: a.nodeId, relayId: a.relayId, lastSeen: seen,
      dist: candidateDist, via: fromId,
    });
  }
  // Gossip-learned attachments count as "seen" for
  // store-and-forward, and learning one may release held mail.
  markSeen(a.nodeId, seen);
  if (heldEnvelopes.has(a.nodeId)) tryDeliverHeld(a.nodeId);
}
function mergeGossip(msg, fromLink) {
  const now = Date.now();
  const fromId = typeof msg.from === 'string' ? msg.from : null;
  if (fromId) {
    if (fromLink && !fromLink.relayId) fromLink.relayId = fromId;
    const prev = peerTable.get(fromId);
    peerTable.set(fromId, {
      relayId: fromId,
      endpoint: (prev && prev.endpoint) || undefined,
      onionPub: (fromLink && fromLink.onionPub)
        || (prev && prev.onionPub) || undefined,
      lastSeen: now, // direct observation beats the sender's clock
      dist: fromId === RELAY_ID ? 0 : 1,
      via: fromId,
    });
    if (fromId !== RELAY_ID) ensureWeight(fromId);
  }
  // Local tier of the sender: its own entry is a direct
  // observation (dist 1 — the from-handling above already set
  // it with lastSeen=now, which wins); its other local entries
  // sit one hop beyond it (dist 2).
  for (const p of msg.peers || []) {
    if (fromId && p && p.relayId === fromId) continue;
    mergePeerObservation(p, 2, fromId, now);
  }
  for (const a of msg.attached || []) {
    if (!a || typeof a.relayId !== 'string') continue;
    mergeAttachedObservation(a, a.relayId === fromId ? 1 : 2, fromId, now);
  }
  // Summary tier: the sender's dist + 1 from here.
  for (const p of msg.sumPeers || []) {
    const d = typeof p.dist === 'number' ? p.dist : 2;
    mergePeerObservation(p, d + 1, fromId, now);
  }
  for (const a of msg.sumAttached || []) {
    const d = typeof a.dist === 'number' ? a.dist : 2;
    mergeAttachedObservation(a, d + 1, fromId, now);
  }
  // Step 7: gossip is where new peer endpoints are learned —
  // reconsider learned dials now, not just on the periodic tick.
  considerLearnedDials();
}

// ---- Peer links ------------------------------------------------------------
// Peers are distinguished from clients by path: peer sockets connect
// to /peer, client sockets to anything else. Both sides of a peer
// link immediately send a peer hello as the first frame:
//   {relay:"v1", type:"peer-hello", from:<relay id>,
//    pubkey:<full pubkey hex>, onionPub:<onion pubkey hex>,
//    endpoint:<advertise>}
// Step 5: the hello carries the sender's full public key, and the
// claimed relay id MUST equal relay- + first 12 hex of that key —
// a mismatch is an impersonation attempt (the link is dropped and
// counted, and it is never gossiped with). After the hello
// exchange, each side challenges the other and verifies its proof
// (see the challenge/proof handlers below). Gossip follows on the
// same socket.
function helloFrame() {
  return JSON.stringify({
    relay: 'v1',
    type: 'peer-hello',
    from: RELAY_ID,
    pubkey: PUBKEY_HEX,
    // Step 6: this relay's current ephemeral onion public key
    // (optional/backward-compatible — a peer that omits it
    // simply cannot be an onion hop for senders learning keys
    // from hellos; /onion-key and gossip carry it too).
    onionPub: ONION_PUB_HEX,
    ...(ARGS.advertise ? { endpoint: ARGS.advertise } : {}),
  });
}
function registerPeerLink(ws, direction) {
  const link = {
    ws, relayId: null, endpoint: null, direction, established: false,
    // Step 7: the base URL this link was dialed to (outbound
    // links only; set by connectSeed/connectLearned). Together
    // with the hello's advertised endpoint it marks which
    // endpoints are already represented by a live link, so the
    // learned dialer never double-dials them.
    dialUrl: null,
    // Step 5 proof state: the peer's claimed pubkey (from its
    // hello), whether its proof verified (proofOk), the nonce of
    // the challenge WE issued to it (single-use), and a dead flag
    // for links dropped as impersonation attempts.
    pubkey: null, proofOk: false, pendingProof: null,
    challengeSent: false, dead: false,
    // Step 6: the peer's current ephemeral onion public key,
    // from its hello (null if absent or malformed).
    onionPub: null,
  };
  peerLinks.add(link);
  // Inbound sockets are already OPEN at the connection event;
  // outbound sockets are still CONNECTING (ws.send throws then),
  // so their hello waits for 'open'.
  const sendHello = () => { try { ws.send(helloFrame()); } catch (e) {} };
  if (ws.readyState === WebSocket.OPEN) sendHello();
  else ws.once('open', sendHello);
  ws.on('message', (data, isBinary) => {
    if (isBinary) return;
    if (link.dead) return; // dropped as an impersonation attempt
    let obj;
    try { obj = JSON.parse(data.toString('utf8')); } catch (e) { return; }
    if (!obj || obj.relay !== 'v1') return;
    if (obj.type === 'peer-hello' && typeof obj.from === 'string') {
      // Step 5 impersonation check: the claimed id must be the id
      // OF the claimed public key. A hello claiming a roster
      // relay's id under a different key is exactly the attack
      // the roster exists to stop: drop the link, count it, never
      // gossip with it, never count it verified.
      const claimedPub = typeof obj.pubkey === 'string' ? obj.pubkey : null;
      const idMismatch = claimedPub !== null
        && (!isPubHex(claimedPub) || obj.from !== 'relay-' + claimedPub.slice(0, 12));
      const idChanged = link.relayId !== null && link.relayId !== obj.from;
      if (idMismatch || idChanged) {
        counts.peerImpersonations++;
        link.dead = true;
        try { ws.close(1008, 'peer id/pubkey mismatch'); } catch (e) {}
        logPeers('peer impersonation rejected');
        return;
      }
      link.relayId = obj.from;
      link.endpoint = obj.endpoint || null;
      link.pubkey = claimedPub;
      // Step 7: remember the key behind this relay id (it passed
      // the id-derivation check above). Roster mode's
      // verified-first dial ordering consults this map — a
      // relay's key is knowable only after a hello like this one.
      if (claimedPub) knownPubkeys.set(obj.from, claimedPub);
      // Step 6: the peer's onion public key rides the same hello
      // (validated shape only; a malformed one is ignored, which
      // just means senders cannot wrap layers for this peer from
      // hello/gossip data — /onion-key remains authoritative).
      link.onionPub = onion.isOnionPubHex(obj.onionPub) ? obj.onionPub
        : (link.onionPub || null);
      link.established = true;
      // Step 8 fix (found by the real-process scale run, not by
      // any small-topology suite): when two relays learn-dial
      // each other at the same time, BOTH connections complete
      // hellos and the pair ends up with two live links. At
      // scale the duplicates eat the --max-peers cap (16 links
      // covering ~9 distinct relays), distinct links get
      // refused, the graph's diameter stays high, and distant
      // summaries expire in transit — the matrix cannot
      // assemble. Dedupe deterministically: for a pair, the
      // surviving link is the one dialed BY the relay with the
      // lexicographically smaller id (both sides compute the
      // same verdict from the same two ids and directions);
      // if both links are of the same class (should not
      // happen), the older link survives.
      for (const other of [...peerLinks]) {
        if (other === link || other.relayId !== obj.from || !other.established) continue;
        const iAmSmaller = RELAY_ID < obj.from;
        const thisBySmaller = (link.direction === 'out') === iAmSmaller;
        const otherBySmaller = (other.direction === 'out') === iAmSmaller;
        if (thisBySmaller && !otherBySmaller) {
          try { other.ws.close(1000, 'duplicate peer link'); } catch (e) {}
        } else if (otherBySmaller && !thisBySmaller) {
          link.dead = true;
          try { ws.close(1000, 'duplicate peer link'); } catch (e) {}
          return;
        } else {
          link.dead = true;
          try { ws.close(1000, 'duplicate peer link'); } catch (e) {}
          return;
        }
      }
      ensureWeight(obj.from);
      const prev = peerTable.get(obj.from);
      peerTable.set(obj.from, {
        relayId: obj.from,
        endpoint: obj.endpoint || (prev && prev.endpoint) || undefined,
        onionPub: link.onionPub || (prev && prev.onionPub) || undefined,
        lastSeen: Date.now(),
        dist: 1, via: obj.from, // a live link: one hop, by definition
      });
      logPeers('peer link up');
      // Step 5 hello-proof: challenge the peer to prove it holds
      // the key behind its claimed id. One outstanding nonce per
      // link, single-use, 30 s expiry. (A hello without a pubkey
      // is a legacy peer: no proof is possible and the link stays
      // unverified forever.)
      if (claimedPub && !link.challengeSent) {
        link.challengeSent = true;
        const nonce = crypto.randomBytes(32).toString('hex');
        link.pendingProof = { nonce, expiresAt: Date.now() + PROOF_TTL_MS };
        try {
          ws.send(JSON.stringify({ relay: 'v1', type: 'peer-challenge', nonce }));
        } catch (e) { /* link teardown handles it */ }
      }
      burstGossip();
      // A fresh peer link may make a held envelope's holder
      // reachable: retry everything held.
      tryDeliverAllHeld();
      return;
    }
    if (obj.type === 'peer-challenge' && typeof obj.nonce === 'string'
      && /^[0-9a-f]{64}$/.test(obj.nonce)) {
      // Prove WE hold our key: sign the PROTOCOL.md body with the
      // private key retained in memory. The key itself never
      // leaves this process; only the signature travels.
      try {
        const body = Buffer.from(
          JSON.stringify(['pirgitori-relay-v1', obj.nonce, RELAY_ID]), 'utf8');
        const signature = crypto.sign(null, body, privateKey).toString('hex');
        ws.send(JSON.stringify({ relay: 'v1', type: 'peer-proof', signature }));
      } catch (e) { /* link teardown handles it */ }
      return;
    }
    if (obj.type === 'peer-proof' && typeof obj.signature === 'string') {
      // The nonce is consumed on the FIRST proof attempt,
      // success or failure — single-use means exactly that.
      const pending = link.pendingProof;
      link.pendingProof = null;
      let ok = false;
      if (pending && Date.now() <= pending.expiresAt && link.pubkey && link.relayId) {
        try {
          const body = Buffer.from(
            JSON.stringify(['pirgitori-relay-v1', pending.nonce, link.relayId]), 'utf8');
          ok = crypto.verify(null, body, pubKeyFromHex(link.pubkey),
            Buffer.from(obj.signature, 'hex'));
        } catch (e) { ok = false; }
      }
      if (ok) link.proofOk = true;
      else counts.proofsFailed++;
      return;
    }
    if (obj.type === 'gossip') { mergeGossip(obj, link); return; }
    // Step 8: sharded-lookup frames walk peer links only.
    if (obj.type === 'lookup') { handleLookup(obj, link); return; }
    if (obj.type === 'lookup-answer') { handleLookupAnswer(obj, link); return; }
    // Step 6: onion frames arrive from peers too — the previous
    // hop forwards the still-wrapped remainder, this relay peels
    // its layer the same way as for a client-sent frame.
    const onionFrame = parseOnionFrame(data, isBinary);
    if (onionFrame) { handleOnion(onionFrame, { kind: 'peer', link }); return; }
    const env = parseEnvelope(data, isBinary);
    if (env) handleEnvelope(env, { kind: 'peer', link });
    // Anything else on a peer link is not relay protocol: drop silently.
  });
  let closed = false;
  const onClose = () => {
    if (closed) return;
    closed = true;
    peerLinks.delete(link);
    // An ESTABLISHED peer disconnecting halves its synaptic weight.
    // A seed connect attempt that never completed a hello does not —
    // otherwise every failed reconnect would halve it again.
    if (link.established && link.relayId) weightDown(link.relayId);
    logPeers('peer link down');
    // Step 7: a freed peer slot may let a learned dial proceed.
    considerLearnedDials();
  };
  ws.on('close', onClose);
  ws.on('error', () => { try { ws.close(); } catch (e) {} });
  return link;
}

// Outbound seed links reconnect with backoff: 1s, 2s, 4s, ... cap 15s.
function connectSeed(url) {
  const seed = seedLinks.get(url) || { url, backoff: 1000, timer: null };
  seedLinks.set(url, seed);
  if (shuttingDown) return;
  // Step 7 capacity: at the peer cap a seed is not dropped — it
  // is operator intent — so it retries on a slow timer until a
  // slot frees. (A seed that never connects has no close event
  // to drive the usual reconnect loop, hence the explicit retry.)
  if (peerLinks.size >= ARGS.maxPeers) {
    if (seed.timer) clearTimeout(seed.timer);
    seed.timer = setTimeout(() => connectSeed(url), 5000);
    return;
  }
  const ws = new WebSocket(peerUrl(url));
  const link = registerPeerLink(ws, 'out');
  link.dialUrl = url;
  ws.on('open', () => { seed.backoff = 1000; });
  ws.on('close', () => {
    if (shuttingDown) return;
    seed.timer = setTimeout(() => connectSeed(url), seed.backoff);
    seed.backoff = Math.min(seed.backoff * 2, 15000);
  });
}

// ---- Step 7: auto-join — dialing endpoints learned from gossip --------
// Endpoints are compared in normalized base form: trailing
// slashes and a trailing /peer path are presentation, not
// identity (a --peer value is a base URL; /peer is appended at
// dial time; an advertised endpoint is a base URL too).
function normalizeEndpoint(u) {
  if (typeof u !== 'string' || !u) return null;
  let s = u.replace(/\/+$/, '');
  if (s.endsWith('/peer')) s = s.slice(0, s.length - '/peer'.length).replace(/\/+$/, '');
  return s || null;
}
// Endpoints already represented: every live or connecting link's
// dialed URL and hello-advertised endpoint, plus every seed URL
// (seeds have their own reconnect machinery — the learned dialer
// must never double-dial a seed).
function representedEndpoints() {
  const set = new Set();
  for (const link of peerLinks) {
    const d = normalizeEndpoint(link.dialUrl);
    if (d) set.add(d);
    const e = normalizeEndpoint(link.endpoint);
    if (e) set.add(e);
  }
  for (const url of seedLinks.keys()) {
    const n = normalizeEndpoint(url);
    if (n) set.add(n);
  }
  return set;
}

// One learned dial. The attempt is counted in /health
// (learned_dial_attempts) and its outcome drives the endpoint's
// cooldown state: a socket that closes BEFORE completing a peer
// hello is a failure (backoff doubles, capped at 60 s); a socket
// that got established resets the backoff, and its eventual
// close schedules eligibility after the base cooldown so the
// matrix can heal a dropped learned link.
function connectLearned(endpoint) {
  const st = learnedDials.get(endpoint)
    || { failures: 0, backoff: LEARNED_BACKOFF_MIN_MS, nextOk: 0, connecting: false };
  learnedDials.set(endpoint, st);
  if (st.connecting || shuttingDown) return;
  st.connecting = true;
  counts.learnedDialAttempts++;
  const ws = new WebSocket(peerUrl(endpoint));
  const link = registerPeerLink(ws, 'out');
  link.dialUrl = endpoint;
  ws.on('close', (code) => {
    st.connecting = false;
    if (shuttingDown) return;
    if (link.established) {
      st.failures = 0;
      st.backoff = LEARNED_BACKOFF_MIN_MS;
      st.nextOk = Date.now() + LEARNED_BACKOFF_MIN_MS;
    } else {
      st.failures++;
      // Step 8 fix (scale run): a pre-hello close with code
      // 1013 is a capacity refusal — the endpoint is FULL, not
      // dead, and it will stay full for a while. Start its
      // cooldown at 5 s instead of 1 s so a matrix assembling
      // around full relays does not storm them with redials
      // (measured before the fix: 140-200 learned dials per
      // relay in 40 s at N=50, most of them cap refusals).
      if (code === 1013 && st.backoff < 5000) st.backoff = 5000;
      st.nextOk = Date.now() + st.backoff;
      st.backoff = Math.min(st.backoff * 2, LEARNED_BACKOFF_MAX_MS);
    }
  });
}

// Consider every gossip-learned peer endpoint as a dial
// candidate. A candidate must be FRESH (inside the liveness
// window), must not be this relay (by id or by its own
// advertised endpoint), must not already be represented by a
// live/connecting/seed link, must not be a relay that already
// has a live link, and must not be inside its failure cooldown.
// In roster mode, candidates whose relay key this relay has
// actually seen and that is on the roster dial first
// (verified-first); within a class, freshest lastSeen first.
// Dialing stops at the peer cap. Called on every gossip merge,
// on the gossip tick, and whenever a peer link closes.
function considerLearnedDials() {
  if (shuttingDown) return;
  const now = Date.now();
  const represented = representedEndpoints();
  const selfEndpoint = ARGS.advertise ? normalizeEndpoint(ARGS.advertise) : null;
  const linkedRelayIds = new Set();
  for (const l of peerLinks) if (l.relayId) linkedRelayIds.add(l.relayId);
  const candidates = [];
  for (const [relayId, e] of peerTable) {
    if (relayId === RELAY_ID || !e.endpoint) continue;
    if (now - e.lastSeen > LIVENESS_WINDOW_MS) continue;
    const base = normalizeEndpoint(e.endpoint);
    if (!base || base === selfEndpoint) continue;
    if (represented.has(base)) continue;
    if (linkedRelayIds.has(relayId)) continue;
    const st = learnedDials.get(base);
    if (st && (st.connecting || st.nextOk > now)) continue;
    let cls = 1;
    if (rosterSet) {
      const pk = knownPubkeys.get(relayId);
      if (pk && rosterSet.has(pk)) cls = 0;
    }
    candidates.push({ relayId, endpoint: base, lastSeen: e.lastSeen, cls });
  }
  candidates.sort((a, b) => (a.cls - b.cls) || (b.lastSeen - a.lastSeen));
  for (const c of candidates) {
    if (peerLinks.size >= ARGS.maxPeers) break;
    connectLearned(c.endpoint);
  }
}

// Periodic tick: decay weights 1% toward 1.0, prune stale table
// entries, gossip to every live peer link, and (Step 7)
// reconsider learned dials — the tick is what retries a learned
// endpoint once its cooldown expires.
const gossipTimer = setInterval(() => {
  for (const [id, w] of weights) weights.set(id, w + (1.0 - w) * 0.01);
  broadcastGossip();
  considerLearnedDials();
}, GOSSIP_INTERVAL_MS);
gossipTimer.unref();

// ---- Boot ---------------------------------------------------------------
const server = http.createServer(handleHttp);
const wss = new WebSocketServer({ server });
wss.on('connection', (ws, req) => {
  const pathname = (req.url || '/').split('?')[0];
  // Step 7 capacity caps: at cap, the new socket is closed
  // cleanly with 1013 (try again later) BEFORE any link or pair
  // state is created; existing links are untouched.
  if (pathname === '/peer') {
    if (peerLinks.size >= ARGS.maxPeers) {
      try { ws.close(1013, 'peer capacity'); } catch (e) {}
      return;
    }
    registerPeerLink(ws, 'in');
  } else {
    if (pairs.size >= ARGS.maxClients) {
      try { ws.close(1013, 'client capacity'); } catch (e) {}
      return;
    }
    handleConnection(ws);
  }
});

let shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  clearInterval(gossipTimer);
  clearInterval(holdTimer);
  for (const seed of seedLinks.values()) {
    if (seed.timer) clearTimeout(seed.timer);
  }
  for (const link of [...peerLinks]) {
    try { link.ws.close(1000); } catch (e) {}
  }
  peerLinks.clear();
  if (registryPipe.ws) {
    try { registryPipe.ws.close(1000); } catch (e) {}
    registryPipe.ws = null;
  }
  for (const endpoint of [...pairs]) {
    try { endpoint.client.close(1000); } catch (e) {}
    if (endpoint.upstream) {
      try { endpoint.upstream.close(1000); } catch (e) {}
    }
    if (endpoint.pipe) {
      try { endpoint.pipe.close(1000); } catch (e) {}
    }
  }
  pairs.clear();
  server.close(() => {
    logCounts(`shutdown (${signal})`);
    process.exit(0);
  });
  // Do not hang on a stuck socket: exit anyway after 2 s.
  setTimeout(() => process.exit(0), 2000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

server.listen(ARGS.port, ARGS.host, () => {
  console.log(`RELAY: id=${RELAY_ID} listening on :${ARGS.port} (v${RELAY_VERSION}, ${PROTOCOL}); `
    + (ARGS.identityFile
      ? 'persistent identity from an operator-provisioned key file — id stable across restarts; private key in memory only, never logged'
      : 'ephemeral key — dies with this process, never written to disk'));
  console.log('RELAY: forwarder only — no attestation, no ledger, no state on disk; PLAIN payloads are readable by this relay — onion frames (Step 6) are not: this relay peels one layer and cannot read the rest');
  console.log(rosterSet
    ? `RELAY: roster mode ON (${rosterSet.size} roster relays, signature verified at boot); verified peers are preferred for routing`
    : 'RELAY: roster mode OFF — hello-proof stops impersonation only; Sybil relays remain possible');
  console.log(`RELAY: auto-join ON — endpoints learned from gossip are dialed with cooldown (1s doubling, cap 60s); capacity max-peers=${ARGS.maxPeers} max-clients=${ARGS.maxClients}`);
  console.log(`RELAY: tiered gossip ON — full entries for the local tier only, summaries beyond it (window ${ARGS.gossipSummaries}/class, summary liveness ${ARGS.summaryLivenessSeconds}s, max ${ARGS.maxSummaries} summaries/table); sharded lookup ON (ttl ${LOOKUP_TTL}, negative cache ${LOOKUP_NEGATIVE_SECONDS}s)`);
  for (const url of ARGS.peers) connectSeed(url);
});
