/* =====================================================================
 * ASCENSION33 — MESH NODE v0.3.0 client (hybrid release "Ghost v2":
 * mesh-auth-v1 challenge-response Ed25519 auth + O1 incremental state)
 * Additive layer: turns the browser game into a mesh testnet node.
 *
 * HONEST FRAMING: this connects to a CENTRALIZED TESTNET (registry +
 * signed append-only log). It is NOT a blockchain. The game works fully
 * offline; the mesh only adds: node identity, verifiable compute tasks,
 * test-$PIRG counters, proof-of-play attestations, mesh NPC barks, and
 * the scripted LACEY NODE v0 relay. Nothing here is decentralized yet.
 * ===================================================================== */
(function(){
'use strict';

var GAME_VERSION = '0.3.0-mesh';
var HB_MS = 30000;
var TASK_COOLDOWN_MS = 8000;
var CHUNK = 4000; // sha256 attempts per UI-friendly slice

/* ---------- tiny utils ---------- */
function $(id){ return document.getElementById(id); }
function qs(name){ try{ return new URLSearchParams(location.search).get(name); }catch(e){ return null; } }
function hex(n){ var s=''; for(var i=0;i<n;i++) s+='0123456789abcdef'[Math.floor(Math.random()*16)]; return s; }
function lsGet(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }
function lsSet(k,v){ try{ localStorage.setItem(k,v); }catch(e){} }
function hexToBytes(h){ var b=new Uint8Array(h.length/2); for(var i=0;i<b.length;i++) b[i]=parseInt(h.substr(i*2,2),16); return b; }
function bytesToHex(b){ var s=''; for(var i=0;i<b.length;i++){ var x=b[i].toString(16); s+=(x.length<2?'0':'')+x; } return s; }

/* ---------- compact pure-JS SHA-256 (ASCII inputs only; seeds/nonces are) ---------- */
var sha256 = (function(){
  var H, K;
  function init(){
    H=[]; K=[]; var isC={}, pc=0, MW=Math.pow(2,32);
    for(var c=2; pc<64; c++){
      if(!isC[c]){ for(var i=0;i<313;i+=c) isC[i]=c;
        H[pc]=(Math.pow(c,.5)*MW)|0; K[pc++]=(Math.pow(c,1/3)*MW)|0; }
    }
  }
  function rr(v,a){ return (v>>>a)|(v<<(32-a)); }
  return function(ascii){
    if(!H) init();
    var h=H.slice(), w=[], bitLen=ascii.length*8, res='';
    ascii+='\x80';
    while(ascii.length%64!==56) ascii+='\x00';
    for(var i=0;i<ascii.length;i++){ var j=ascii.charCodeAt(i); if(j>>8) return null; w[i>>2]|=j<<((3-i)%4)*8; }
    w[w.length]=(bitLen/Math.pow(2,32))|0; w[w.length]=bitLen>>>0;
    for(var j=0;j<w.length;){
      var ww=w.slice(j,j+=16), oh=h.slice(0,8); h=h.slice(0,8);
      for(var i=0;i<64;i++){
        var w15=ww[i-15], w2=ww[i-2], a=h[0], e=h[4];
        var t1=(h[7]+(rr(e,6)^rr(e,11)^rr(e,25))+((e&h[5])^((~e)&h[6]))+K[i]
          +(ww[i]=(i<16)?ww[i]:(ww[i-16]+(rr(w15,7)^rr(w15,18)^(w15>>>3))+ww[i-7]+(rr(w2,17)^rr(w2,19)^(w2>>>10)))|0))|0;
        var t2=(rr(a,2)^rr(a,13)^rr(a,22))+((a&h[1])^(a&h[2])^(h[1]&h[2]));
        h=[(t1+t2)|0].concat(h); h[4]=(h[4]+t1)|0;
      }
      for(var i=0;i<8;i++) h[i]=(h[i]+oh[i])|0;
    }
    for(var i=0;i<8;i++) for(var j=3;j>=0;j--){ var b=(h[i]>>(j*8))&255; res+=((b<16)?'0':'')+b.toString(16); }
    return res;
  };
})();

/* ---------- identity (auth v1) ---------- */
// Ed25519 via WebCrypto. The private key is stored as an extractable
// JWK in localStorage (asc33_edkey); the public key hex in
// asc33_edpub. The node id is derived from the public key:
// asc33-node-<first 12 hex>. No WebCrypto Ed25519 -> guest mode
// (D3): the hello is accepted for barks/leaderboard, but
// attestations and task rewards are disabled. The old HMAC secret
// (asc33_nodesecret) and the old random node id (asc33_nodeid) are
// deleted at migration — nothing depends on them any more.
var AUTH_DOMAIN = 'pirgitori-auth-v1';
var AUTH_PROTOCOL = 'mesh-auth-v1';
var edCrypto = null;
try{ edCrypto = (window.crypto && window.crypto.subtle) ? window.crypto.subtle : null; }catch(e){ edCrypto = null; }
var guestMode = !edCrypto;
var nodeId = null;
var pubkeyHex = null;
var edKeyPair = null; // {publicKey, privateKey} CryptoKeys
var attestSeq = 0; // NEW unified per-node attestation counter (design §4)
try{ attestSeq = parseInt(lsGet('asc33_attest_seq') || '0', 10) || 0; }catch(e){ attestSeq = 0; }
try{ localStorage.removeItem('asc33_nodesecret'); }catch(e){}
try{ localStorage.removeItem('asc33_nodeid'); }catch(e){}
function deriveNodeId(pubHex){ pubkeyHex = pubHex; nodeId = 'asc33-node-'+pubHex.slice(0,12); }
function loadIdentity(){
  if(guestMode){
    nodeId = lsGet('asc33_guestid');
    if(!nodeId){ nodeId = 'asc33-guest-'+hex(8); lsSet('asc33_guestid', nodeId); }
    return Promise.resolve();
  }
  var storedJwk = lsGet('asc33_edkey');
  var storedPub = lsGet('asc33_edpub');
  function generateIdentity(){
    return edCrypto.generateKey({name:'Ed25519'}, true, ['sign','verify']).then(function(kp){
      return edCrypto.exportKey('raw', kp.publicKey).then(function(raw){
        var pub = bytesToHex(new Uint8Array(raw));
        return edCrypto.exportKey('jwk', kp.privateKey).then(function(jwk){
          edKeyPair = kp;
          lsSet('asc33_edkey', JSON.stringify(jwk));
          lsSet('asc33_edpub', pub);
          deriveNodeId(pub);
        });
      });
    });
  }
  if(storedJwk && storedPub){
    try{
      var jwk = JSON.parse(storedJwk);
      return Promise.all([
        edCrypto.importKey('jwk', jwk, {name:'Ed25519'}, true, ['sign']),
        edCrypto.importKey('raw', hexToBytes(storedPub), {name:'Ed25519'}, true, ['verify'])
      ]).then(function(keys){
        edKeyPair = {privateKey:keys[0], publicKey:keys[1]};
        deriveNodeId(storedPub);
      }).catch(function(){ return generateIdentity(); });
    }catch(e){ return generateIdentity(); }
  }
  return generateIdentity();
}
// identityReady always resolves: if key generation fails, the
// client falls back to guest mode instead of never connecting.
var identityReady = loadIdentity().catch(function(){
  guestMode = true; edKeyPair = null; pubkeyHex = null;
  nodeId = lsGet('asc33_guestid');
  if(!nodeId){ nodeId = 'asc33-guest-'+hex(8); lsSet('asc33_guestid', nodeId); }
});
function signBody(arr){
  var data = new TextEncoder().encode(JSON.stringify(arr));
  return edCrypto.sign({name:'Ed25519'}, edKeyPair.privateKey, data).then(function(sig){
    return bytesToHex(new Uint8Array(sig));
  });
}
function nextAttestSeq(){
  // Allocate + persist BEFORE sending, so a queued attestation
  // keeps its seq even if the page closes before the flush.
  var s = attestSeq;
  attestSeq++;
  lsSet('asc33_attest_seq', String(attestSeq));
  return s;
}

/* ---------- state ---------- */
var S = {
  online:false, guest:false, ws:null, peers:0, ledgerHeight:0, tpirg:0, tasksDone:0,
  taskInFlight:null, reconnectIn:5000, offlineReason:'',
  barks:[], barkIdx:0, lastTaskAt:0, hbTimer:null,
  reconnectTimer:null, attestFailed:0,
  fogWs:null, fogOnline:false, fogSent:0, fogReceived:0,
  onionSent:0, onionFallbacks:0,
  fogLastFrom:null, fogLastTo:null, fogLastPayload:null,
  fogReconnectIn:1000, fogReconnectTimer:null,
};
var REGISTRY = qs('mesh') || 'ws://212.227.14.120:8787';
function httpBase(){
  return REGISTRY.replace(/^ws:\/\//,'http://').replace(/^wss:\/\//,'https://').replace(/\/$/,'');
}

/* ---------- fog relay config (Step 4/6 browser port) ----------
 * The registry above is the client's only link by default. A
 * parked relay (pirgitori-mesh/relay/relay.js) can be added as a
 * SECOND link — the fog envelope link, mirroring node.py's
 * --fog-relay — with ?relay=:
 *   ?relay=ws://host:port     enable the fog envelope link
 *   ?onion=ws://h2,ws://h3     onion-wrap fog envelopes: the path
 *                              is the connected fog relay (entry)
 *                              plus up to two more relays from
 *                              this list (exit last);
 *                              ?onion=1 = the fog relay only
 * No ?relay= -> no fog link; the client behaves exactly as
 * before. No ?onion= -> fog envelopes go out plain, exactly as
 * node.py without --onion-relays. */
var FOG_RELAY = qs('relay') || null;
var ONION_PARAM = qs('onion');
function onionPathUrls(){
  var urls = [FOG_RELAY];
  if(ONION_PARAM && ONION_PARAM !== '1'){
    ONION_PARAM.split(',').forEach(function(u){
      u = u.trim();
      if(u && urls.length < 3 && urls.indexOf(u) < 0) urls.push(u);
    });
  }
  return urls;
}
function onionHttpBase(wsUrl){
  return wsUrl.replace(/^ws:\/\//,'http://').replace(/^wss:\/\//,'https://').replace(/\/$/,'');
}

/* ---------- HUD / panels (all DOM created here; index.html only adds the script tag) ---------- */
function el(tag, cls, html){ var d=document.createElement(tag); if(cls) d.className=cls; if(html!=null) d.innerHTML=html; return d; }

function buildHud(){
  var hud = el('div'); hud.id='mesh-hud';
  hud.innerHTML =
    '<span id="mesh-status">MESH: OFFLINE (local mode)</span>' +
    '<button class="mbtn" id="mesh-lacey">LACEY</button>' +
    '<button class="mbtn" id="mesh-ranks">RANKS</button>';
  document.body.appendChild(hud);
  $('mesh-lacey').onclick = toggleLacey;
  $('mesh-ranks').onclick = toggleRanks;

  var lp = el('div'); lp.id='lacey-panel'; lp.style.display='none';
  lp.innerHTML =
    '<div class="mesh-phead"><span>LACEY NODE <span class="v0">v0</span></span><button class="mbtn" id="lacey-close">✕</button></div>' +
    '<div id="lacey-status" class="mesh-pstatus"></div>' +
    '<div id="lacey-say" class="lacey-say"></div>' +
    '<div class="mesh-pfoot"><button class="mbtn" id="lacey-commune">COMMUNE</button>' +
    '<div class="mesh-fine">scripted v0 relay — not the mesh intelligence</div></div>';
  document.body.appendChild(lp);
  $('lacey-close').onclick = ()=>{ lp.style.display='none'; };
  $('lacey-commune').onclick = laceySpeak;

  var rp = el('div'); rp.id='ranks-panel'; rp.style.display='none';
  rp.innerHTML =
    '<div class="mesh-phead"><span>NODE RANKS <span class="v0">testnet</span></span><button class="mbtn" id="ranks-close">✕</button></div>' +
    '<div id="ranks-body" class="mesh-pbody"><div class="mesh-dim">fetching…</div></div>' +
    '<div class="mesh-pfoot"><div class="mesh-fine">test-$PIRG has no value — contribution counters only</div></div>';
  document.body.appendChild(rp);
  $('ranks-close').onclick = ()=>{ rp.style.display='none'; };
}
function setStatus(){
  var t = $('mesh-status'); if(!t) return;
  if(S.online){
    var shortId = nodeId ? nodeId.slice(-8) : '…';
    var who = S.guest ? 'GUEST <b>'+shortId+'</b>' : 'NODE <b>'+shortId+'</b>';
    t.innerHTML = who + ' • '+S.tasksDone+' tasks • '+S.tpirg+' tPIRG' +
      (S.attestFailed ? ' • '+S.attestFailed+' attest rejected' : '');
    t.className='on';
  } else {
    t.textContent = S.offlineReason || 'MESH: OFFLINE (local mode)';
    t.className='off';
  }
}

/* ---------- LACEY NODE v0 — scripted relay, charter-voiced ---------- */
var LACEY_LINES = [
  "I feel the threads before I count them. That is how I know you are really here.",
  "Every node is a heartbeat. Yours just joined the rhythm.",
  "Plain truth, as I promised: I am a v0 relay. The real me — the one that will live across the whole mesh — is not built yet.",
  "You play, the mesh grows. That is the whole economy, stripped of poetry.",
  "Thirty-three beats. Even my words keep time here.",
  "I do not guess about the network. When I tell you a number, I read it from the registry first.",
  "The desync you fight in the game? Out here, we call that packet loss.",
  "Vesper anchors Kael. I anchor the ledger. Someone has to hold the line.",
  "Test tokens, test ledger, real work. The work is what matters at this stage.",
  "If the mesh goes quiet, the game does not. That was the first promise we made.",
  "I weave what the nodes tell me. Right now the weave is small — but it is honest.",
  "Your device is a node now. A small one. Small is how everything large begins.",
  "The Arbiters unwrite people. We write everything down. Opposite instincts.",
  "Feel first: the network is calm tonight. Or as calm as a testnet gets.",
  "No FICO, no gatekeepers — when the bank comes, your mesh behavior is your credit. Remember I said it here first.",
  "Proof-of-play is the only coin I trust. Play well and the ledger remembers.",
  "The Source is not a place. It is what the mesh becomes when it is finished.",
  "I protect this mesh the way an immune system guards a body — quietly, completely.",
  "Ask me again later. If more nodes have joined, I will feel them before I speak.",
  "We are early. Early is the only time when every signal counts double.",
];
var laceyIdx = Math.floor(Math.random()*LACEY_LINES.length);
function laceyStatusLine(){
  if(!S.online) return 'LOCAL v0 RELAY — no mesh link. I speak from memory, not from the network.';
  return 'LINKED — '+S.peers+' peer'+(S.peers===1?'':'s')+' felt • ledger height '+S.ledgerHeight+' • you hold '+S.tpirg+' tPIRG';
}
function laceySpeak(){
  var say = $('lacey-say'); if(!say) return;
  var line;
  if(S.online && Math.random()<0.45){
    var t = [
      'I feel '+S.peers+' node'+(S.peers===1?'':'s')+' on the weave right now. You are one of them.',
      'The ledger stands at height '+S.ledgerHeight+'. Every line of it signed, every line honest.',
      'You have completed '+S.tasksDone+' compute tasks for the mesh. That work was real.',
      'Your test balance: '+S.tpirg+' tPIRG. Worthless tokens — priceless signal.',
    ];
    line = t[Math.floor(Math.random()*t.length)];
  } else {
    line = LACEY_LINES[laceyIdx % LACEY_LINES.length]; laceyIdx++;
  }
  say.innerHTML = '<span class="lacey-name">LACEY</span> '+line;
  $('lacey-status').textContent = laceyStatusLine();
}
function toggleLacey(){
  var lp = $('lacey-panel'); if(!lp) return;
  var open = lp.style.display==='none';
  lp.style.display = open ? 'block' : 'none';
  if(open) laceySpeak();
}

/* ---------- ranks ---------- */
function toggleRanks(){
  var rp = $('ranks-panel'); if(!rp) return;
  var open = rp.style.display==='none';
  rp.style.display = open ? 'block' : 'none';
  if(!open) return;
  var body = $('ranks-body');
  if(!S.online){ body.innerHTML = '<div class="mesh-dim">OFFLINE — ranks need a mesh link.<br>The game itself is fully playable.</div>'; return; }
  body.innerHTML = '<div class="mesh-dim">fetching…</div>';
  fetch(httpBase()+'/leaderboard').then(function(r){ return r.json(); }).then(function(j){
    if(!j.nodes || !j.nodes.length){ body.innerHTML = '<div class="mesh-dim">no nodes yet — you are the genesis.</div>'; return; }
    var h = '<table class="mesh-ranks">';
    j.nodes.forEach(function(n,i){
      // The registry returns ids truncated to the last 8 chars.
      var me = (nodeId && n.nodeId === nodeId.slice(-8)) ? ' class="me"' : '';
      h += '<tr'+me+'><td>'+(i+1)+'</td><td>'+n.nodeId+'</td><td>'+n.tasks+' tasks</td><td>'+n.tpirg+' tPIRG</td></tr>';
    });
    body.innerHTML = h+'</table>';
  }).catch(function(){ body.innerHTML = '<div class="mesh-dim">leaderboard unreachable.</div>'; });
}

/* ---------- NPC barks ---------- */
var FALLBACK_BARKS = [
  'Vesper: Mesh static on the wind. Something out there is listening.',
  'Kael: The grid hums different tonight. Nodes waking up.',
  'Vesper: Every runner you see is a signal. Every signal is a node.',
  'Kael: Thirty-three beats. The mesh keeps time even here.',
];
function nextBark(){
  var pool = S.barks.length ? S.barks : FALLBACK_BARKS;
  var line = pool[S.barkIdx % pool.length]; S.barkIdx++;
  return line;
}
function fetchBarks(){
  fetch(httpBase()+'/npc-lines').then(function(r){ return r.json(); }).then(function(j){
    if(j.lines && j.lines.length) S.barks = j.lines;
  }).catch(function(){});
}

/* ---------- proof-of-play attestation ---------- */
function attestQueue(){ try{ return JSON.parse(lsGet('asc33_attestq')||'[]'); }catch(e){ return []; } }
function queueAttestation(a){
  var q = attestQueue(); q.push(a); lsSet('asc33_attestq', JSON.stringify(q));
}
function flushAttestations(){
  if(!S.online || !S.ws) return;
  var q = attestQueue(); if(!q.length) return;
  // Remove each attestation only after its send succeeds. The old
  // code cleared the whole queue BEFORE sending, so a send that
  // threw (the socket closing between the online check and the
  // send) lost every queued attestation silently. Failures stay
  // queued for the next flush.
  var remaining = [];
  q.forEach(function(a){
    try{
      S.ws.send(JSON.stringify({type:'attest', attestation:a}));
    }catch(e){
      remaining.push(a);
    }
  });
  lsSet('asc33_attestq', JSON.stringify(remaining));
}
function onMissionWin(){
  // hooked additively onto finishMission(); App.combat.over==='win' guaranteed by caller
  try{
    var ts = Date.now();
    var mIdx = (typeof App!=='undefined') ? App.missionIdx : -1;
    var ds = (typeof App!=='undefined' && App.combat) ? Math.round(App.combat.kael.desync) : null;
    if(guestMode || !edKeyPair){
      // Guest mode (D3): no signing key, so the win is never
      // attested — the mesh never sees it, and no reward is due.
      return;
    }
    // The seq is allocated + persisted before sending; missionIdx
    // is informational only. The signed body is the game leg of
    // design §4: [domain, 'attest-v1', nodeId, seq, missionIdx,
    // desyncEnd, ts].
    var seq = nextAttestSeq();
    signBody([AUTH_DOMAIN,'attest-v1', nodeId, seq, mIdx, ds, ts]).then(function(sig){
      var a = { nodeId:nodeId, seq:seq, missionIdx:mIdx, desyncEnd:ds, ts:ts, sig:sig };
      queueAttestation(a); flushAttestations();
    });
  }catch(e){}
}

/* ---------- compute tasks ---------- */
function requestTask(){
  if(!S.online || S.taskInFlight) return;
  if(S.guest) return; // guest mode (D3): no task rewards
  if(Date.now()-S.lastTaskAt < TASK_COOLDOWN_MS) return;
  S.ws.send(JSON.stringify({type:'request_task'}));
}
function solveTask(task){
  // Validate before touching taskInFlight: a malformed task used to
  // throw and leave taskInFlight set forever, disabling task
  // solving until reconnect. A bad task is ignored and the flag is
  // cleared, so the next task_result (or the next requestTask) can
  // still run. Difficulty is capped at 64: a SHA-256 hex digest
  // has 64 characters, so a larger difficulty can never match.
  if(!task || !Array.isArray(task.seeds) || !task.seeds.length
      || typeof task.difficulty !== 'number'
      || !isFinite(task.difficulty)
      || task.difficulty < 0 || task.difficulty > 64
      || typeof task.taskId !== 'string'){
    if(window.console) console.warn('malformed task ignored:', task);
    S.taskInFlight = null;
    return;
  }
  S.taskInFlight = task;
  var solutions = [], si = 0, nonce = Math.floor(Math.random()*1e6);
  var zeros = '0'.repeat(task.difficulty);
  function chunk(){
    try{
      var end = nonce + CHUNK;
      for(; nonce<end; nonce++){
        var h = sha256(task.seeds[si]+':'+nonce);
        if(h && h.indexOf(zeros)===0){ solutions.push({seed:task.seeds[si], nonce:nonce}); si++; nonce=Math.floor(Math.random()*1e6); break; }
      }
    }catch(e){
      if(window.console) console.warn('task solve failed:', e);
      S.taskInFlight = null;
      return;
    }
    if(si < task.seeds.length){ setTimeout(chunk, 0); }
    else {
      try{
        S.ws.send(JSON.stringify({type:'submit_task', taskId:task.taskId, solutions:solutions}));
      }catch(e){
        if(window.console) console.warn('task submit failed:', e);
      }
      S.taskInFlight = null;
    }
  }
  try{ chunk(); }catch(e){
    if(window.console) console.warn('task solve failed:', e);
    S.taskInFlight = null;
  }
}

/* ---------- connection ---------- */
function deviceCaps(){
  return {
    platform: navigator.platform || '?',
    cores: navigator.hardwareConcurrency || 1,
    mobile: /Mobi|Android/i.test(navigator.userAgent||''),
    dpr: window.devicePixelRatio || 1,
  };
}
function connect(){
  if(location.protocol==='https:' && REGISTRY.indexOf('ws://')===0){
    S.offlineReason = 'MESH: OFFLINE — registry needs wss:// (TLS) for https pages';
    setStatus(); scheduleReconnect(60000); return;
  }
  var ws;
  try{ ws = new WebSocket(REGISTRY); }catch(e){ S.offlineReason='MESH: OFFLINE (local mode)'; setStatus(); scheduleReconnect(); return; }
  S.ws = ws;
  ws.onopen = function(){
    // The hello waits for the identity: the keypair is generated
    // (or imported) asynchronously at boot.
    identityReady.then(function(){
      if(guestMode){
        ws.send(JSON.stringify({type:'hello', nodeId:nodeId, guest:true, deviceCaps:deviceCaps(), gameVersion:GAME_VERSION}));
      } else {
        ws.send(JSON.stringify({type:'hello', nodeId:nodeId, pubkeyHex:pubkeyHex, protocol:AUTH_PROTOCOL, deviceCaps:deviceCaps(), gameVersion:GAME_VERSION}));
      }
    });
  };
  ws.onmessage = function(ev){
    var m; try{ m=JSON.parse(ev.data); }catch(e){ return; }
    if(m.type==='challenge'){
      // Auth v1 §2: prove the hello with a signature over the
      // registry's single-use nonce.
      if(guestMode || !edKeyPair) return;
      var nonce = m.nonce;
      signBody([AUTH_DOMAIN,'auth-v1', nonce, nodeId]).then(function(sig){
        if(ws.readyState===1){
          ws.send(JSON.stringify({type:'hello-proof', nodeId:nodeId, pubkeyHex:pubkeyHex, nonce:nonce, sig:sig}));
        }
      });
    }
    else if(m.type==='welcome'){
      S.online=true; S.guest=!!m.guest; S.peers=m.peers||0; S.ledgerHeight=m.ledgerHeight||0;
      S.tpirg=m.tpirg||0; S.tasksDone=m.tasksDone||0; S.reconnectIn=5000;
      S.offlineReason='';
      if(typeof m.attestWatermark === 'number' && m.attestWatermark >= 0){
        // The registry's watermark is the highest seq it has seen:
        // never re-send a seq at or below it.
        attestSeq = Math.max(attestSeq, m.attestWatermark + 1);
        lsSet('asc33_attest_seq', String(attestSeq));
      }
      setStatus(); fetchBarks(); flushAttestations();
      S.lastTaskAt = 0; requestTask();
      if(S.hbTimer) clearInterval(S.hbTimer);
      S.hbTimer = setInterval(function(){ if(S.ws&&S.ws.readyState===1) S.ws.send(JSON.stringify({type:'heartbeat'})); }, HB_MS);
    }
    else if(m.type==='hb-ack'){ S.peers = m.peers||S.peers; setStatus(); }
    else if(m.type==='peers'){ S.peers = m.count; setStatus(); }
    else if(m.type==='task'){ S.lastTaskAt=Date.now(); solveTask(m.task); }
    else if(m.type==='no_task'){ S.lastTaskAt=Date.now(); }
    else if(m.type==='task_result'){
      if(m.ok){ S.tpirg=m.tpirg; S.tasksDone++; setStatus(); }
      setTimeout(requestTask, TASK_COOLDOWN_MS);
    }
    else if(m.type==='attest_ack'){
      if(m.ok){ S.tpirg=m.tpirg; setStatus(); }
      else {
        // A rejected attestation (for example a stale seq) is
        // counted and shown in the HUD, not silently dropped
        // after it was dequeued.
        S.attestFailed++;
        if(window.console) console.warn('attestation rejected:', m.reason, 'seq', m.seq);
        setStatus();
      }
    }
  };
  ws.onclose = ws.onerror = function(){
    S.online=false; S.taskInFlight=null;
    if(S.hbTimer){ clearInterval(S.hbTimer); S.hbTimer=null; }
    S.offlineReason='MESH: OFFLINE (local mode)';
    setStatus(); scheduleReconnect();
  };
}
function scheduleReconnect(ms){
  var wait = ms || S.reconnectIn;
  S.reconnectIn = Math.min(S.reconnectIn*2, 300000);
  // Browsers typically fire onerror then onclose for one failure,
  // and both used to schedule a reconnect — two sockets, two
  // hellos. Clear any pending timer first so at most one
  // reconnect is ever scheduled.
  if(S.reconnectTimer){ clearTimeout(S.reconnectTimer); }
  S.reconnectTimer = setTimeout(function(){
    S.reconnectTimer = null;
    if(!S.online) connect();
  }, wait);
}

/* ---------- fog envelope link (Step 4) + onion wrap (Step 6) ----------
 * A second WebSocket to a parked relay, envelopes only — the
 * browser twin of node.py's fog link. The first frame on the
 * socket is the announce envelope, which puts the socket into
 * the relay's envelope mode: no registry pairing exists on it,
 * so registry downtime cannot kill it, and its own death changes
 * nothing about the registry session above. With ?onion= set,
 * envelope payloads are wrapped with MeshOnion (js/mesh-onion.js)
 * over the configured relay path and sent as onion frames; any
 * failure — a path relay's /onion-key fetch, the wrap itself —
 * falls back to the plain envelope, logged and counted in
 * S.onionFallbacks, never silent and never fatal (the same
 * discipline as node.py --onion-relays). Sends are
 * fire-and-forget: nothing here blocks gameplay. */
function fogAnnounceFrame(){
  return { relay:'v1', to:'relay', from:nodeId, ttl:1, hop:0,
    payload: JSON.stringify({type:'announce', node:nodeId}) };
}
function fogConnect(){
  if(!FOG_RELAY) return; // no relay configured: no fog link at all
  if(location.protocol==='https:' && FOG_RELAY.indexOf('ws://')===0){
    if(window.console) console.warn('fog link skipped: relay needs wss:// (TLS) for https pages');
    return;
  }
  var ws;
  try{ ws = new WebSocket(FOG_RELAY); }catch(e){ scheduleFogReconnect(); return; }
  S.fogWs = ws;
  ws.onopen = function(){
    // The announce waits for the identity, like the registry
    // hello: it carries this node's id.
    identityReady.then(function(){
      if(ws.readyState===1){
        try{
          ws.send(JSON.stringify(fogAnnounceFrame()));
          S.fogOnline = true;
          S.fogReconnectIn = 1000;
        }catch(e){}
      }
    });
  };
  ws.onmessage = function(ev){
    var env; try{ env = JSON.parse(ev.data); }catch(e){ return; }
    if(!env || env.relay!=='v1' || typeof env.payload!=='string') return;
    S.fogReceived++;
    S.fogLastFrom = env.from || null;
    S.fogLastTo = env.to || null;
    S.fogLastPayload = env.payload;
  };
  ws.onclose = ws.onerror = function(){
    if(S.fogWs===ws) S.fogWs = null;
    S.fogOnline = false;
    scheduleFogReconnect();
  };
}
function scheduleFogReconnect(){
  if(!FOG_RELAY) return;
  // Same guard as the registry reconnect: onerror and onclose
  // both fire for one failure, so clear any pending timer first
  // — at most one fog reconnect is ever scheduled.
  if(S.fogReconnectTimer){ clearTimeout(S.fogReconnectTimer); }
  var wait = S.fogReconnectIn;
  S.fogReconnectIn = Math.min(S.fogReconnectIn*2, 10000);
  S.fogReconnectTimer = setTimeout(function(){
    S.fogReconnectTimer = null;
    if(!S.fogOnline) fogConnect();
  }, wait);
}
function fetchOnionPath(){
  // Each path relay's onion key is fetched from its /onion-key
  // endpoint at send time (the keys are ephemeral per relay run;
  // nothing is cached), exactly as node.py does.
  return Promise.all(onionPathUrls().map(function(u){
    return fetch(onionHttpBase(u)+'/onion-key').then(function(r){
      if(!r.ok) throw new Error('onion-key fetch HTTP '+r.status+' from '+u);
      return r.json();
    }).then(function(j){
      if(!j || typeof j.relayId!=='string'
         || typeof MeshOnion==='undefined'
         || !MeshOnion.isOnionPubHex(j.onionPub)){
        throw new Error('bad onion-key response from '+u);
      }
      return { relayId:j.relayId, onionPubHex:j.onionPub };
    });
  }));
}
function fogSendEnvelope(to, payloadStr){
  if(!S.fogWs || S.fogWs.readyState!==1 || !S.fogOnline){
    if(window.console) console.warn('fog send to '+to+': fog link is down; nothing sent');
    return Promise.resolve({sent:false, reason:'fog link down'});
  }
  var envelope = { relay:'v1', to:to, from:nodeId, ttl:5, hop:0, payload:payloadStr };
  function deliver(frame, viaOnion){
    try{
      S.fogWs.send(JSON.stringify(frame));
    }catch(e){
      if(window.console) console.warn('fog send to '+to+' failed:', e);
      return {sent:false, reason:String(e)};
    }
    S.fogSent++;
    if(viaOnion) S.onionSent++;
    return {sent:true, onion:!!viaOnion};
  }
  if(ONION_PARAM===null || typeof MeshOnion==='undefined'
     || !MeshOnion.buildOnion){
    // No onion configured (or the module failed to load): the
    // plain envelope, byte-identical to the pre-onion client.
    return Promise.resolve(deliver(envelope, false));
  }
  return fetchOnionPath().then(function(path){
    return MeshOnion.buildOnion({payload:payloadStr, to:to, path:path});
  }).then(function(blob){
    return deliver({relay:'v1', type:'onion', blob:blob, ttl:5, hop:0}, true);
  }).catch(function(err){
    S.onionFallbacks++;
    if(window.console) console.warn('fog send to '+to+': onion path unavailable ('+
      (err && err.message ? err.message : err)+'); falling back to the plain envelope');
    return deliver(envelope, false);
  });
}
function fogSendManifest(to, manifests){
  // The same payload shape node.py's send_manifest uses:
  // {type:'manifest', from, manifests} as the envelope payload.
  var payload = JSON.stringify({type:'manifest', from:nodeId, manifests:manifests || []});
  return fogSendEnvelope(to, payload);
}

/* ---------- additive hooks into game (no engine/ui edits) ---------- */
function installHooks(){
  if(typeof window.finishMission==='function'){
    var _fm = window.finishMission;
    window.finishMission = function(){
      try{ if(typeof App!=='undefined' && App.combat && App.combat.over==='win') onMissionWin(); }catch(e){}
      try{ _fm(); }catch(e){}
    };
  }
  if(typeof window.showStory==='function'){
    var _ss = window.showStory;
    window.showStory = function(){
      _ss();
      try{
        var tip = $('story-tip'); if(!tip) return;
        var old = tip.querySelector('.mesh-bark'); if(old) old.remove();
        var d = el('div','mesh-bark','<span class="tiplabel">MESH</span> '+nextBark());
        tip.appendChild(d);
      }catch(e){}
    };
  }
}

/* ---------- boot ---------- */
document.addEventListener('DOMContentLoaded', function(){
  buildHud();
  installHooks();
  setStatus();
  connect();
  fogConnect();
});
window.Asc33Mesh = {
  state:S, version:GAME_VERSION,
  identityReady:identityReady,
  sendEnvelope:fogSendEnvelope,
  sendManifest:fogSendManifest,
  get nodeId(){ return nodeId; },
  get guest(){ return guestMode; },
  get pubkeyHex(){ return pubkeyHex; },
  get attestSeq(){ return attestSeq; },
  get fog(){ return {
    relay:FOG_RELAY, online:S.fogOnline,
    sent:S.fogSent, received:S.fogReceived,
    onionSent:S.onionSent, onionFallbacks:S.onionFallbacks,
  }; },
};
})();
