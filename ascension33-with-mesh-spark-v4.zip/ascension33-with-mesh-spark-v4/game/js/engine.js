'use strict';
/* ================= ASCENSION33 — COMBAT ENGINE =================
   Kha'zari 9-Grid Matrix · Desync · Ru'ya Anchor · Base-33 Q-Time */

const DIRS8 = [[-1,-1],[0,-1],[1,-1],[-1,0],[1,0],[-1,1],[0,1],[1,1]];
function rnd(a,b){ return a + Math.floor(Math.random()*(b-a+1)); }
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function cheb(a,b){ return Math.max(Math.abs(a.x-b.x), Math.abs(a.y-b.y)); }

class Combat {
  constructor(mdef, P){
    this.mdef = mdef; this.P = P;
    this.units = []; this.clock = 0; this.nextSurge = 33;
    this.over = null; this.log = []; this.fx = [];
    this._id = 1; this.wavesFired = {};
    const k = mdef.kael;
    this.kael = this.mk({ name:'Kael', side:'player', hero:true,
      x:k.x, y:k.y, hp:P.hp, maxhp:P.maxhp, dmg:[8,12], q:0, moveQ:4, strikeQ:6, desync:0 });
    this.kael.stance = 'flow'; this.kael.flow = 0; this.kael.lastTarget = null;
    this.kael.guard = false; this.kael.glitchMarkUntil = -1;
    this.vesper = null;
    if (mdef.vesper){
      const v = mdef.vesperPos || {x:0,y:0};
      this.vesper = this.mk({ name:'Vesper', side:'player', auto:true,
        x:v.x, y:v.y, hp:P.vesperHp, maxhp:P.vesperHp, dmg:[9,9+P.vesperBond*3+3],
        q:2, moveQ:4, strikeQ:6, desync:0 });
      this.vesper.stab = 2;
    }
    let q = 4;
    (mdef.enemies||[]).forEach(e=>{
      const d = ENEMIES[e.t];
      const u = this.mk({ name:d.name, side:'enemy', etype:e.t,
        x:e.x, y:e.y, hp:e.hp||d.hp, maxhp:e.hp||d.hp, dmg:d.dmg.slice(),
        q:q, moveQ:d.moveQ, strikeQ:d.actQ, desync:0 });
      u.count = 0; q += 2;
    });
    (mdef.nodes||[]).forEach(n=>{
      const u = this.mk({ name:'City Mesh Node', side:'enemy', etype:'node',
        x:n.x, y:n.y, hp:n.hp, maxhp:n.hp, dmg:[6,6],
        q:q, moveQ:99, strikeQ:6, node:true, immobile:true, desync:0 });
      u.count = 0; q += 2;
    });
    this.logAdd('— ' + mdef.name + ' —', 'sys');
  }

  mk(o){
    o.id = this._id++; o.alive = true;
    o.flow = 0; o.lastTarget = null; o.guard = false; o.glitchMarkUntil = -1; o.count = 0;
    o._stagger = false;
    if (!o.maxhp) o.maxhp = o.hp;
    this.units.push(o); return o;
  }

  /* ---------- helpers ---------- */
  alive(){ return this.units.filter(u=>u.alive); }
  at(x,y){ return this.units.find(u=>u.alive && u.x===x && u.y===y); }
  inGrid(x,y){ return x>=0 && x<3 && y>=0 && y<3; }
  freeCell(x,y){ return this.inGrid(x,y) && !this.at(x,y); }
  adj(u){ const r=[]; for (const [dx,dy] of DIRS8){ const x=u.x+dx, y=u.y+dy; if(this.inGrid(x,y)) r.push({x,y}); } return r; }
  foesOf(u){ return this.alive().filter(v=>v.side!==u.side); }
  current(){
    return this.alive().slice().sort((a,b)=>
      a.q-b.q || (a.side===b.side ? 0 : (a.side==='player' ? -1 : 1)) || a.id-b.id)[0];
  }
  order(n){
    return this.alive().slice().sort((a,b)=>
      a.q-b.q || (a.side===b.side ? 0 : (a.side==='player' ? -1 : 1)) || a.id-b.id).slice(0,n);
  }
  qcost(u, base){ return u.side==='player' ? Math.max(2, base-(this.P.qEdge?1:0)) : base; }
  logAdd(text, cls){ this.log.push({text, cls:cls||''}); }
  nearestFree(x,y){
    const seen = new Set(); const q = [{x,y}];
    while(q.length){
      const c = q.shift(); const k = c.x+','+c.y;
      if(seen.has(k)) continue; seen.add(k);
      if(this.freeCell(c.x,c.y)) return c;
      for(const [dx,dy] of DIRS8){ const nx=c.x+dx, ny=c.y+dy; if(this.inGrid(nx,ny)) q.push({x:nx,y:ny}); }
    }
    return null;
  }
  misfireChance(){
    const k = this.kael; if(!k || !k.alive) return 0;
    let c = 0;
    if(k.desync >= 70) c = 0.30; else if(k.desync >= 40) c = 0.15;
    if(k.glitchMarkUntil > this.clock) c += 0.10;
    return c;
  }

  /* ---------- desync ---------- */
  addDesync(n){
    if(this.P.ward) n = Math.round(n*0.7);
    const k = this.kael; if(!k || !k.alive || this.over) return;
    k.desync = Math.min(100, k.desync + n);
    if(k.desync >= 100){
      k.hp = 1; k.desync = 50; k.flow = 0; k.lastTarget = null; k.glitchMarkUntil = -1;
      k._stagger = true; // applied to Kael's next Q computation in takeTurn
      this.fx.push({type:'deletion'});
      this.logAdd('DELETION EVENT! Kael is unmade \u2014 barely re-coheres at 1 HP. Desync reset to 50.', 'crit');
      this.checkEnd();
    }
  }

  /* ---------- damage ---------- */
  dealDamage(t, amt, src){
    if(!t || !t.alive || this.over) return;
    let d = amt;
    if(t.hero){
      if(t.stance==='iron') d = Math.round(d*0.6);
      else if(t.stance==='ember') d = Math.round(d*1.2);
      if(t.guard) d = Math.round(d*0.4);
    }
    t.hp -= d;
    this.fx.push({type:'dmg', id:t.id, amt:d});
    this.logAdd((src ? src.name+' hits ' : '') + t.name + ' for ' + d + '.', t.side==='player' ? 'hurt' : 'hit');
    if(t.hero && d >= 10) this.addDesync(6);
    if(t.hp <= 0){
      t.hp = 0; t.alive = false;
      this.logAdd(t.name + ' is deleted.', 'die');
      if(t.node) this.maybeWave('nodeDown');
    } else if(t.node){
      this.maybeWave('nodeHalf');
    }
    this.checkEnd();
  }
  maybeWave(kind){
    (this.mdef.waves||[]).forEach((w,i)=>{
      if(this.wavesFired[i] || w.trigger!==kind) return;
      if(kind==='nodeHalf'){
        const nodes = this.alive().filter(u=>u.node);
        const hurt = this.units.some(u=>u.node && u.alive && u.hp <= u.maxhp/2);
        if(!hurt) return;
      }
      this.wavesFired[i] = true;
      w.spawn.forEach(s=>{
        const c = this.nearestFree(s.x, s.y); if(!c) return;
        const d = ENEMIES[s.t];
        const u = this.mk({ name:d.name, side:'enemy', etype:s.t, x:c.x, y:c.y,
          hp:d.hp, maxhp:d.hp, dmg:d.dmg.slice(), q:this.clock+4, moveQ:d.moveQ, strikeQ:d.actQ, desync:0 });
        u.count = 0;
        this.logAdd('Mesh reinforcements arrive: ' + d.name + '!', 'warn');
      });
    });
  }

  /* ---------- player actions ---------- */
  takeTurn(u, act){
    if(this.over) return {ok:false};
    if(this.current() !== u || !u.alive) return {ok:false};
    this.clock = u.q;
    this.fx = [];
    if(u.hero && !(act.kind==='tech' && act.tech==='guard')) u.guard = false;
    let cost = 0, ok = true;
    switch(act.kind){
      case 'move': {
        cost = this.qcost(u, (u.hero && u.stance==='flow') ? 2 : u.moveQ);
        if(cheb(u,{x:act.x,y:act.y})!==1 || !this.freeCell(act.x,act.y)) ok = false;
        else { u.x = act.x; u.y = act.y; if(u.hero){ u.flow=0; u.lastTarget=null; } this.logAdd(u.name+' moves.','mv'); }
        break;
      }
      case 'strike': cost = this.qcost(u, u.strikeQ); ok = this.doStrike(u, act.x, act.y, act); break;
      case 'tech':   cost = this.qcost(u, TECHNIQUES[act.tech].q); ok = this.doTech(u, act.tech, act); break;
      case 'stance': cost = this.qcost(u, 3);
        u.stance = act.stance; u.flow = 0; u.lastTarget = null;
        this.logAdd(u.name+' takes '+act.stance.toUpperCase()+' stance.','st'); break;
      case 'anchor': cost = this.qcost(u, 2); ok = this.doAnchor(u); break;
      case 'stabilize': cost = this.qcost(u, 4); ok = this.doStabilize(u); break;
      case 'suppress': {
        cost = this.qcost(u, u.strikeQ);
        const t = this.at(act.x,act.y); if(!t||t.side===u.side){ ok=false; break; }
        this.dealDamage(t, 4, u);
        if(t.hero) this.addDesync(6);
        this.logAdd(u.name+' suppresses '+t.name+' (+desync).','warn'); break;
      }
      case 'pulse': {
        cost = this.qcost(u, 8);
        let hit = false;
        this.adj(u).forEach(c=>{ const t=this.at(c.x,c.y);
          if(t && t.side!==u.side){ this.dealDamage(t, 8, u); hit=true; } });
        this.logAdd(hit ? u.name+' discharges a suppression pulse!' : u.name+' pulses harmlessly.', hit?'warn':'miss');
        break;
      }
      case 'slam': {
        cost = this.qcost(u, 8);
        const t = this.at(act.x,act.y); if(!t||t.side===u.side){ ok=false; break; }
        this.dealDamage(t, 18, u);
        if(t.hero) this.addDesync(10);
        this.logAdd(u.name+' SLAMS '+t.name+' across the timeline!','warn'); break;
      }
      case 'summon': {
        cost = this.qcost(u, 7);
        const drones = this.alive().filter(v=>v.etype==='drone').length;
        const c = this.adj(u).find(c=>!this.at(c.x,c.y));
        if(drones < 2 && c){
          const d = ENEMIES.drone;
          const s = this.mk({ name:d.name, side:'enemy', etype:'drone', x:c.x, y:c.y,
            hp:d.hp, maxhp:d.hp, dmg:d.dmg.slice(), q:this.clock+4, moveQ:d.moveQ, strikeQ:d.actQ, desync:0 });
          s.count = 0;
          this.logAdd(u.name+' fabricates a Sentinel Drone!','warn');
        } else { this.logAdd(u.name+' holds position.','mv'); }
        break;
      }
      case 'pass': cost = this.qcost(u, 4); break;
      default: ok = false;
    }
    if(!ok) return {ok:false};
    u.q = this.clock + cost;
    if(u._stagger){ u.q += 12; u._stagger = false; }
    const nx = this.current();
    if(nx && nx.q > this.clock) this.clock = nx.q;
    this.surgeCheck();
    this.checkEnd();
    return {ok:true};
  }

  doStrike(u, tx, ty, act){
    act = act||{};
    let target = this.at(tx,ty);
    if(u.hero && Math.random() < this.misfireChance()){
      const cells = this.adj(u);
      const c = pick(cells);
      target = this.at(c.x,c.y);
      this.logAdd('GLITCH! '+u.name+'\u2019s strike veers off-target!','glitch');
    }
    if(!target || !target.alive){ this.logAdd(u.name+' strikes empty air.','miss'); if(u.hero) this.addDesync(2); return true; }
    if(target.side===u.side) return false;
    let dmg = rnd(u.dmg[0], u.dmg[1]);
    if(u.hero){
      if(u.stance==='ember') dmg = Math.round(dmg*1.3);
      else if(u.stance==='iron') dmg = Math.round(dmg*0.75);
      if(u.stance==='flow'){
        if(u.lastTarget===target.id) u.flow = Math.min(3, u.flow+1); else u.flow = 1;
        u.lastTarget = target.id;
        dmg = Math.round(dmg*(1+0.25*u.flow));
        if(u.flow>=2) this.logAdd('Flow chain x'+(u.flow+1)+'!','combo');
      } else { u.flow = 0; u.lastTarget = null; }
      this.addDesync(2);
    }
    if(act.suppress){ /* handled by suppress case */ }
    this.dealDamage(target, dmg, u);
    return true;
  }

  doTech(u, tech, act){
    const T = TECHNIQUES[tech];
    if(u.hero) this.addDesync(T.desync);
    if(tech==='guard'){ u.guard = true; this.logAdd(u.name+' enters the Ninefold Guard.','st'); return true; }
    if(tech==='phase'){
      if(!this.freeCell(act.x,act.y)) return false;
      u.x = act.x; u.y = act.y; u.flow = 0; u.lastTarget = null;
      this.logAdd(u.name+' phase-steps across the grid.','tech'); return true;
    }
    if(u.hero && Math.random() < this.misfireChance()){
      this.logAdd('GLITCH! '+T.name+' misfires!','glitch');
      if(tech==='flow'){
        const cells = this.adj(u).map(c=>this.at(c.x,c.y)).filter(t=>t&&t.side!==u.side);
        cells.sort(()=>Math.random()-0.5);
        cells.slice(0, Math.ceil(cells.length/2)).forEach(t=>this.dealDamage(t,7,u));
      }
      return true;
    }
    if(tech==='flow'){
      let hit = false;
      this.adj(u).forEach(c=>{ const t=this.at(c.x,c.y);
        if(t && t.side!==u.side){ this.dealDamage(t,7,u); hit=true; } });
      this.logAdd(hit ? u.name+' unleashes '+T.name+'!' : T.name+' hits nothing.', hit?'tech':'miss');
      return true;
    }
    if(tech==='rend'){
      const t = this.at(act.x,act.y);
      if(!t || !t.alive || t.side===u.side) return false;
      this.dealDamage(t, 22, u);
      this.logAdd(u.name+' rends '+t.name+' across time.','tech');
      return true;
    }
    return false;
  }

  doAnchor(u){
    if(u!==this.kael || this.P.anchorCharges<=0) return false;
    this.P.anchorCharges--;
    u.desync = 0; u.glitchMarkUntil = -1;
    this.logAdd('Ru\u2019ya Anchor discharges \u2014 desync purged to zero. ('+this.P.anchorCharges+' charges left)','anchor');
    return true;
  }
  doStabilize(u){
    if(!u.auto || u.stab<=0) return false;
    const k = this.kael;
    if(!k || !k.alive || cheb(u,k)!==1) return false;
    u.stab--;
    k.desync = Math.max(0, k.desync-25);
    this.logAdd('Vesper anchors Kael \u2014 desync \u221225.','anchor');
    return true;
  }

  /* ---------- surges ---------- */
  surgeCheck(){
    let guard = 0;
    while(this.clock >= this.nextSurge && guard++ < 10){
      const mark = this.nextSurge; this.nextSurge += 33;
      this.logAdd('\u2014 Q-'+mark+' MESH SURGE \u2014','surge');
      this.alive().filter(u=>u.node).forEach(n=>{
        this.adj(n).forEach(c=>{ const t=this.at(c.x,c.y);
          if(t && t.side==='player') this.dealDamage(t, 5, n); });
      });
      const r = Math.random();
      if(r < 0.25){
        this.alive().forEach(u=>{ if(!u.node) this.dealDamage(u, 4, null); });
        this.logAdd('Reality tear: everything takes 4 damage.','surge');
      } else if(r < 0.5){
        const nx = this.current();
        if(nx){ nx.q += 8; this.logAdd(nx.name+' stutters in time (+8Q).','surge'); }
      } else if(r < 0.75){
        const k = this.kael;
        if(k && k.alive){ k.glitchMarkUntil = this.clock+40; this.logAdd('Kael is GLITCH-MARKED (+10% misfire).','surge'); }
      } else {
        this.alive().filter(u=>u.side==='enemy' && !u.node).forEach(u=>this.dealDamage(u, 6, null));
        this.logAdd('Surge feedback: enemies take 6 damage.','surge');
      }
    }
  }

  /* ---------- AI ---------- */
  aiAct(u){
    if(!u.alive || this.over) return;
    if(u.node){ this.takeTurn(u,{kind:'pass'}); return; }
    if(u.auto){ this.vesperAI(u); return; }
    const foes = this.foesOf(u);
    if(!foes.length) return;
    let best=null, bd=99;
    foes.forEach(f=>{ const d=cheb(u,f); if(d<bd){ bd=d; best=f; } });
    u.count++;
    const et = u.etype;
    if(bd<=1){
      if(et==='enforcer' && best.hero && Math.random()<0.3){ this.takeTurn(u,{kind:'strike',x:best.x,y:best.y}); this.suppressFollow(u,best); return; }
      if(et==='elite' && u.count%3===0){ this.takeTurn(u,{kind:'pulse'}); return; }
      if(et==='prime'){
        if(u.count%4===0){ this.takeTurn(u,{kind:'summon'}); return; }
        if(u.count%4===2){ this.takeTurn(u,{kind:'slam',x:best.x,y:best.y}); return; }
      }
      this.takeTurn(u,{kind:'strike',x:best.x,y:best.y});
    } else {
      const opts = this.adj(u).filter(c=>!this.at(c.x,c.y));
      if(!opts.length){ this.takeTurn(u,{kind:'pass'}); return; }
      opts.sort((a,b)=>cheb(a,best)-cheb(b,best));
      this.takeTurn(u,{kind:'move',x:opts[0].x,y:opts[0].y});
    }
  }
  suppressFollow(u, best){
    // enforcer suppress: small hit + desync — folded into strike via extra effect
    if(best.hero && best.alive){ this.addDesync(6); this.logAdd(u.name+' suppresses '+best.name+' (+desync).','warn'); }
  }
  vesperAI(u){
    const k = this.kael;
    if(u.stab>0 && k && k.alive && k.desync>=70){
      if(cheb(u,k)<=1){ this.takeTurn(u,{kind:'stabilize'}); return; }
      const opts = this.adj(k).filter(c=>!this.at(c.x,c.y));
      if(opts.length){
        opts.sort((a,b)=>cheb(a,u)-cheb(b,u));
        this.takeTurn(u,{kind:'move',x:opts[0].x,y:opts[0].y}); return;
      }
    }
    const foes = this.foesOf(u);
    if(!foes.length){ this.takeTurn(u,{kind:'pass'}); return; }
    let best=null, bd=99;
    foes.forEach(f=>{ const d=cheb(u,f); if(d<bd){ bd=d; best=f; } });
    if(bd<=1){ this.takeTurn(u,{kind:'strike',x:best.x,y:best.y}); return; }
    const opts = this.adj(u).filter(c=>!this.at(c.x,c.y));
    if(!opts.length){ this.takeTurn(u,{kind:'pass'}); return; }
    opts.sort((a,b)=>cheb(a,best)-cheb(b,best));
    this.takeTurn(u,{kind:'move',x:opts[0].x,y:opts[0].y});
  }

  /* ---------- end ---------- */
  checkEnd(){
    if(this.over) return;
    if(!this.kael.alive) this.over = 'lose';
    else if(!this.alive().some(u=>u.side==='enemy')) this.over = 'win';
  }
  desyncLevel(){
    const d = this.kael ? this.kael.desync : 0;
    return d>=70 ? 2 : d>=40 ? 1 : 0;
  }
}
