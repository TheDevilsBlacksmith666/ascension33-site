#!/usr/bin/env node
/*
 * Pirgitori onion routing — Step 6 (relay v0.5.0).
 *
 * This module is the ONE implementation of the onion layer
 * format specified in PROTOCOL.md ("Onion routing (Step 6)").
 * relay.js uses peelOnion() + generateOnionKeys(); senders (the
 * tests today; node.py and the browser game client later) use
 * buildOnion(). The Python and browser ports must mirror this
 * file byte-for-byte in behavior: same curve, same HKDF, same
 * layer JSON. Node stdlib crypto only — no dependencies.
 *
 * Construction (per layer):
 *  - Keys: P-256 (prime256v1) ECDH. A relay's onion keypair is
 *    EPHEMERAL per run (even for roster/identity-file relays) and
 *    its private half never leaves the process. The sender
 *    generates a FRESH ephemeral keypair per layer per message.
 *  - Public form: the raw uncompressed point, 65 bytes
 *    0x04 || X || Y, hex (130 chars), assembled from the JWK
 *    export's x/y coordinates.
 *  - Layer key: ECDH(sender ephemeral private, recipient onion
 *    public) -> HKDF-SHA256 (salt empty, info
 *    "pirgitori-onion-v1", 32 bytes) -> AES-256-GCM key.
 *  - Layer JSON (all binary as hex):
 *      {v:1, eph:<sender ephemeral pubkey hex>, iv:<12-byte hex>,
 *       tag:<16-byte hex>, ct:<hex>}
 *  - Layer plaintext (JSON): {next:<relay id | node id |
 *    "registry">, body:<inner layer object>} for every layer
 *    except that the INNERMOST layer's body is the final payload
 *    envelope {final:true, to:<destination>, payload:<string>}
 *    and its `next` is that destination. So peeling the exit
 *    relay's layer yields {next:<destination>, body:{final:true,
 *    to, payload}}; peeling any other layer yields only the next
 *    relay's id and the still-encrypted inner layer.
 *
 * What this buys, honestly: an intermediate relay learns only
 * the previous hop (from the connection) and the next hop (from
 * its layer). It cannot read the payload, cannot learn the final
 * destination (unless it IS the exit), and cannot learn the
 * sender (unless it is the entry). It does NOT defeat timing
 * correlation, a global observer, or a compromised endpoint —
 * see PROTOCOL.md and the design §4.4.
 */
'use strict';
const crypto = require('crypto');

const ONION_HKDF_INFO = 'pirgitori-onion-v1';
const ONION_PUB_HEX_RE = /^[0-9a-f]{130}$/;

// ---- P-256 public key <-> raw uncompressed point hex -------------------
function publicHexFromKey(publicKey) {
  const jwk = publicKey.export({ format: 'jwk' });
  const x = Buffer.from(jwk.x, 'base64url');
  const y = Buffer.from(jwk.y, 'base64url');
  if (x.length !== 32 || y.length !== 32) throw new Error('not a P-256 key');
  return Buffer.concat([Buffer.from([0x04]), x, y]).toString('hex');
}
function isOnionPubHex(s) {
  return typeof s === 'string' && ONION_PUB_HEX_RE.test(s) && s.startsWith('04');
}
function publicKeyFromHex(hex) {
  if (!isOnionPubHex(hex)) throw new Error('invalid P-256 onion public key hex');
  const raw = Buffer.from(hex, 'hex');
  const jwk = {
    kty: 'EC', crv: 'P-256',
    x: raw.subarray(1, 33).toString('base64url'),
    y: raw.subarray(33, 65).toString('base64url'),
  };
  return crypto.createPublicKey({ key: jwk, format: 'jwk' });
}

// ---- Key generation ------------------------------------------------------
// Returns {privateKey, publicKey, publicHex}. The private key is a
// KeyObject: it stays in the caller's memory and is never
// serialized by this module.
function generateOnionKeys() {
  const kp = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  return {
    privateKey: kp.privateKey,
    publicKey: kp.publicKey,
    publicHex: publicHexFromKey(kp.publicKey),
  };
}

// ---- Per-layer key derivation ---------------------------------------------
function deriveLayerKey(myPrivateKey, peerPubHex) {
  const secret = crypto.diffieHellman({
    privateKey: myPrivateKey,
    publicKey: publicKeyFromHex(peerPubHex),
  });
  const key = crypto.hkdfSync('sha256', secret, Buffer.alloc(0),
    Buffer.from(ONION_HKDF_INFO, 'utf8'), 32);
  return Buffer.from(key);
}

// ---- One layer -------------------------------------------------------------
function encryptLayer(plaintextStr, recipientPubHex) {
  const eph = generateOnionKeys(); // fresh ephemeral per layer
  const key = deriveLayerKey(eph.privateKey, recipientPubHex);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([cipher.update(plaintextStr, 'utf8'), cipher.final()]);
  return {
    v: 1,
    eph: eph.publicHex,
    iv: iv.toString('hex'),
    tag: cipher.getAuthTag().toString('hex'),
    ct: ct.toString('hex'),
  };
}

// buildOnion({payload, to, path}) -> the outermost layer object.
// path is [{relayId, onionPubHex}, ...] in entry -> exit order.
// The sender generates a fresh ephemeral keypair per layer (inside
// encryptLayer). The innermost layer's `next` is the destination
// itself and its body is the final payload envelope; every other
// layer's `next` is the following relay's id and its body is the
// next layer in.
function buildOnion({ payload, to, path }) {
  if (typeof payload !== 'string') throw new Error('payload must be a string');
  if (typeof to !== 'string' || !to) throw new Error('to must be a destination id string');
  if (!Array.isArray(path) || path.length === 0) {
    throw new Error('path must be a non-empty array of {relayId, onionPubHex}');
  }
  for (const hop of path) {
    if (!hop || typeof hop.relayId !== 'string' || !isOnionPubHex(hop.onionPubHex)) {
      throw new Error('each path entry needs {relayId, onionPubHex}');
    }
  }
  let body = { final: true, to, payload };
  let layer = null;
  for (let i = path.length - 1; i >= 0; i--) {
    const next = i === path.length - 1 ? to : path[i + 1].relayId;
    layer = encryptLayer(JSON.stringify({ next, body }), path[i].onionPubHex);
    body = layer;
  }
  return layer;
}

// peelOnion(layer, onionPrivateKey) -> the parsed plaintext object
// ({next, body}). Throws on ANY failure: malformed layer, bad
// ephemeral key, AEAD tag mismatch (wrong key or tampered
// ciphertext), non-JSON plaintext. Callers treat a throw as
// "drop silently" — a relay must never act on an unpeeled layer.
function peelOnion(layer, onionPrivateKey) {
  if (!layer || typeof layer !== 'object' || Array.isArray(layer) || layer.v !== 1) {
    throw new Error('not an onion layer');
  }
  if (!isOnionPubHex(layer.eph)) throw new Error('bad ephemeral key in onion layer');
  if (typeof layer.iv !== 'string' || !/^[0-9a-f]{24}$/.test(layer.iv)) {
    throw new Error('bad iv in onion layer');
  }
  if (typeof layer.tag !== 'string' || !/^[0-9a-f]{32}$/.test(layer.tag)) {
    throw new Error('bad tag in onion layer');
  }
  if (typeof layer.ct !== 'string' || !/^[0-9a-f]*$/.test(layer.ct)
    || layer.ct.length % 2 !== 0) {
    throw new Error('bad ciphertext in onion layer');
  }
  const key = deriveLayerKey(onionPrivateKey, layer.eph);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key,
    Buffer.from(layer.iv, 'hex'));
  decipher.setAuthTag(Buffer.from(layer.tag, 'hex'));
  const pt = Buffer.concat([
    decipher.update(Buffer.from(layer.ct, 'hex')),
    decipher.final(), // throws on AEAD failure — by design
  ]);
  return JSON.parse(pt.toString('utf8'));
}

module.exports = {
  generateOnionKeys,
  buildOnion,
  peelOnion,
  publicHexFromKey,
  publicKeyFromHex,
  isOnionPubHex,
  ONION_HKDF_INFO,
};
