"""In-between node core, prototype v1 — 2026-10-30.

Implements the v2 design's severed-cluster logic, WITHOUT any radio:
- append-only, hash-chained, Ed25519-signed event log (provisional receipts)
- vector-clock ordering, merge-by-type (LWW position, CRDT counters,
  OR-Set, quarantine for unique ownership)
- batch manifests with a Merkle root
- graded hash-rate fallback for blink authorization

This is a simulation/prototype. It proves the merge/reconcile logic.
It does NOT prove Wi-Fi Direct, BLE, or phone inference performance —
those need the device measurements listed in the v2 design doc.
"""
import bisect
import hashlib
import json
import math

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization


def _hash(obj) -> str:
    data = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def _merkle_root(hashes):
    if not hashes:
        return hashlib.sha256(b"").hexdigest()
    level = list(hashes)
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            pair = level[i] + (level[i + 1] if i + 1 < len(level) else level[i])
            nxt.append(hashlib.sha256(pair.encode()).hexdigest())
        level = nxt
    return level[0]


class Event:
    def __init__(self, actor, key, op, payload, clock, prev_hash, signature):
        self.actor = actor
        self.key = key
        self.op = op  # position | counter_inc | set_add | unique_claim
        self.payload = payload
        self.clock = dict(clock)
        self.prev_hash = prev_hash
        self.signature = signature
        self.event_id = _hash(
            [actor, key, op, payload, self.clock, prev_hash, signature.hex()]
        )

    def to_dict(self):
        return {
            "event_id": self.event_id,
            "actor": self.actor,
            "key": self.key,
            "op": self.op,
            "payload": self.payload,
            "clock": self.clock,
            "prev_hash": self.prev_hash,
            "signature": self.signature.hex(),
        }

    @staticmethod
    def from_dict(d):
        """Rebuild an Event from its wire dict.

        The event_id is a content hash and is NOT covered by the
        signature: a relay could otherwise rewrite event_id and get
        the same event applied twice (double-apply). The id is
        recomputed here from the content and a mismatch is rejected
        with ValueError, so a forged id never reaches the log.
        Malformed dicts (missing keys, bad hex, non-dict clock) also
        raise ValueError, so callers can reject a bad batch whole
        instead of crashing on a KeyError mid-reconcile.
        """
        try:
            actor, key, op = d["actor"], d["key"], d["op"]
            payload = d["payload"]
            clock = dict(d["clock"])
            prev_hash = d["prev_hash"]
            signature = bytes.fromhex(d["signature"])
            event_id = d["event_id"]
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"malformed event dict: {exc}") from exc
        expected = _hash(
            [actor, key, op, payload, clock, prev_hash, signature.hex()]
        )
        if event_id != expected:
            raise ValueError(
                "event_id does not match event content (forged or "
                "corrupted)"
            )
        ev = Event.__new__(Event)
        ev.actor, ev.key, ev.op = actor, key, op
        ev.payload, ev.clock = payload, clock
        ev.prev_hash = prev_hash
        ev.signature = signature
        ev.event_id = expected
        return ev


def _validate_payload(op, payload):
    """Payload shape for one op. Raises ValueError on a bad payload.

    counter_inc needs a finite number (a string would crash the
    rebuild's counter arithmetic); set_add needs a hashable payload
    (a dict or list would crash the set add, and later the sort).
    position and unique_claim payloads are stored as-is and cannot
    crash the rebuild, so they are not restricted here.
    """
    if op == "counter_inc":
        if isinstance(payload, bool) or not isinstance(
                payload, (int, float)):
            raise ValueError("counter_inc payload must be a number")
        if not math.isfinite(payload):
            raise ValueError("counter_inc payload must be finite")
    elif op == "set_add":
        try:
            hash(payload)
        except TypeError:
            raise ValueError(
                "set_add payload must be hashable"
            ) from None


def _validate_clock(clock):
    """Vector-clock shape. Raises ValueError on a malformed clock.

    A clock value that is not a non-negative integer would crash the
    rebuild (clock sums and comparisons assume ints), so a signed
    event with a malformed clock is dropped before it is applied.
    """
    if not isinstance(clock, dict):
        raise ValueError("clock is not a dict")
    for key, value in clock.items():
        if not isinstance(key, str):
            raise ValueError("clock key is not a string")
        if isinstance(value, bool) or not isinstance(value, int) \
                or value < 0:
            raise ValueError(
                "clock value is not a non-negative integer"
            )


_KNOWN_OPS = ("position", "counter_inc", "set_add", "unique_claim")


def _validate_event(ev):
    """Structural validation of a received event, before it is applied.

    Raises ValueError on anything that would crash the rebuild or
    corrupt state: an unknown op, a malformed vector clock, or a
    payload of the wrong type for its op. This is about shape, not
    authenticity — a bad signature is checked separately by receive().
    """
    if ev.op not in _KNOWN_OPS:
        raise ValueError(f"unknown op {ev.op!r}")
    _validate_clock(ev.clock)
    _validate_payload(ev.op, ev.payload)


def _set_sort_key(value):
    """Total sort order for set members.

    Sets may hold mixed hashable types (an int and a str are both
    hashable), and plain sorted() raises TypeError comparing them.
    Sorting by (type name, value) keeps the natural order inside one
    type and never compares values across types.
    """
    return (type(value).__name__, value)


def _clock_leq(a, b):
    return all(a.get(k, 0) <= b.get(k, 0) for k in set(a) | set(b))


def _concurrent(a, b):
    return not _clock_leq(a, b) and not _clock_leq(b, a)


# How many incremental applies run before the state is verified
# against a full rebuild. Bounds silent divergence: a bug in the
# incremental path is caught within _VERIFY_EVERY events at most,
# and verify_state() self-heals by keeping the rebuilt state.
_VERIFY_EVERY = 1000


def _apply_event_to_intermediates(ev, positions, counters, sets,
                                  unique_claims, quarantine):
    """Fold ONE event into the merge intermediates.

    This is the single home of the merge rules — byte-for-byte the
    loop body _rebuild_state() used to carry inline. Both the full
    rebuild and the incremental path call it, on the same events in
    the same order, so the intermediates they build are identical
    by construction. The only part that is NOT shared is the
    materialization of self.state (see _apply_incremental), and
    that is exactly what verify_state() checks.

    Rules, per op:
    - position: LWW by vector clock; a causally-later-or-equal
      clock wins; concurrent clocks tie-break on (clock-sum,
      actor id); a causally-older event loses silently.
    - counter_inc: CRDT counter, payloads sum.
    - set_add: add-only set (there is no set_remove op).
    - unique_claim: first claim stands; a concurrent claim, or a
      claim by a different actor, freezes the item (both events
      go to quarantine); a same-actor causally-later claim
      replaces the standing claim silently — even when the item
      is already frozen, in which case the key stays frozen AND
      reappears in "unique" (that is the rebuild's behavior,
      preserved here, not smoothed over).
    """
    if ev.op == "position":
        cur = positions.get(ev.key)
        if cur is None:
            positions[ev.key] = (ev.payload, ev.clock, ev.actor)
        elif _clock_leq(cur[1], ev.clock):
            positions[ev.key] = (ev.payload, ev.clock, ev.actor)
        elif _concurrent(cur[1], ev.clock):
            # Deterministic tie-break for concurrent positions:
            # higher clock-sum wins, then higher actor id.
            if (sum(ev.clock.values()), ev.actor) > (
                sum(cur[1].values()),
                cur[2],
            ):
                positions[ev.key] = (ev.payload, ev.clock, ev.actor)
    elif ev.op == "counter_inc":
        counters[ev.key] = counters.get(ev.key, 0) + ev.payload
    elif ev.op == "set_add":
        sets.setdefault(ev.key, set()).add(ev.payload)
    elif ev.op == "unique_claim":
        prior = unique_claims.get(ev.key)
        if prior is None:
            unique_claims[ev.key] = ev
        elif _concurrent(prior.clock, ev.clock) or prior.actor != ev.actor:
            # Concurrent or second claim on a unique item: freeze it.
            if ev not in quarantine and prior not in quarantine:
                quarantine.extend([prior, ev])
            elif ev not in quarantine:
                quarantine.append(ev)
        # else: same actor re-claiming causally later wins silently
        elif _clock_leq(prior.clock, ev.clock):
            unique_claims[ev.key] = ev


def _values_equal(a, b):
    """Deep equality that treats float NaN as equal to itself.

    Plain == says float("nan") != float("nan"), so a state holding
    a NaN payload (legal: a float is a hashable set member, and
    position payloads are stored as-is) would false-mismatch in
    verify_state(). This walks the state structure — dicts, lists,
    tuples, floats — and only falls back to == for leaves.
    """
    if isinstance(a, float) and isinstance(b, float):
        if math.isnan(a) and math.isnan(b):
            return True
        return a == b
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(
            _values_equal(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(
            _values_equal(x, y) for x, y in zip(a, b))
    return a == b


def _states_equal(a, b):
    """Top-level state comparison, NaN-aware (see _values_equal)."""
    if set(a.keys()) != set(b.keys()):
        return False
    return all(_values_equal(a[k], b[k]) for k in a)


class Node:
    def __init__(self, node_id, private_key=None):
        """node_id: the node's id. private_key: an optional
        Ed25519PrivateKey (or 32 raw private bytes) to sign with —
        the auth v1 identity seam (design §7). When omitted, a fresh
        keypair is generated exactly as before, so every existing
        caller that constructs a bare Node keeps working. The key
        is the node's identity: events, manifests, and (via node.py)
        registry attestations are all signed with it.
        """
        self.id = node_id
        if private_key is None:
            self._sk = Ed25519PrivateKey.generate()
        elif isinstance(private_key, Ed25519PrivateKey):
            self._sk = private_key
        else:
            self._sk = Ed25519PrivateKey.from_private_bytes(
                bytes(private_key))
        self.pk = self._sk.public_key().public_bytes(
            serialization.Encoding.Raw,
            serialization.PublicFormat.Raw,
        )
        self.clock = {node_id: 0}
        self.log = []          # Event objects, in local order
        self.seen_ids = set()
        # Materialized merged state, kept fresh by the incremental
        # path (see _apply_incremental). Always has the five keys;
        # _rebuild_state() replaces the whole dict, the incremental
        # path patches one key at a time.
        self.state = {
            "positions": {},
            "counters": {},
            "sets": {},
            "unique": {},
            "frozen_unique": [],
        }
        # Merge intermediates, maintained incrementally alongside
        # state so an emit never needs a full rebuild. They are
        # exactly what _rebuild_state() builds from the log, and
        # _rebuild_state() resets them — the two paths cannot drift
        # apart without verify_state() catching it.
        self._positions = {}       # key -> (payload, clock, actor)
        self._counters = {}        # key -> summed payload
        self._sets = {}            # key -> set of payloads
        self._unique_claims = {}   # key -> standing claim Event
        self._frozen_keys = set()  # keys with >= 1 quarantined event
        self._nan_set_keys = set()  # set keys holding a float NaN
        self.quarantine = []   # frozen unique-claim conflicts
        self.provisional = False  # True only while severed from core
        # Verifier bookkeeping: applies since the last full-rebuild
        # check, runs of the verifier, failures seen, and the last
        # check's outcome.
        self._applies_since_verify = 0
        self._verify_runs = 0
        self._verify_failures = 0
        self._last_verify = None

    def rotate_key(self, new_private_key):
        """Replace this node's signing key (auth v1 rotation, §6).

        Past events keep their old signatures — they were valid
        when signed, and rotation does not revoke them. New events,
        manifests, and attestations sign with the new key from here
        on. Accepts an Ed25519PrivateKey or 32 raw private bytes.
        """
        if isinstance(new_private_key, Ed25519PrivateKey):
            self._sk = new_private_key
        else:
            self._sk = Ed25519PrivateKey.from_private_bytes(
                bytes(new_private_key))
        self.pk = self._sk.public_key().public_bytes(
            serialization.Encoding.Raw,
            serialization.PublicFormat.Raw,
        )

    # -- local event creation -------------------------------------------
    def emit(self, key, op, payload):
        # Validate before the clock moves: a failed emit must not
        # consume a clock tick or leave a half-built event behind.
        if op not in _KNOWN_OPS:
            raise ValueError(f"unknown op {op!r}")
        _validate_payload(op, payload)
        self.clock[self.id] = self.clock.get(self.id, 0) + 1
        # The hash chain is PER ACTOR: prev is this actor's own last
        # event, or GENESIS for its first event. (It used to be the
        # last event in the whole log, which could be another actor's
        # relayed event — that made a per-actor chain check
        # impossible: a node that emitted after relaying would chain
        # onto the relayed event and fail its own chain check.)
        # The vector clock still records what the node had seen.
        prev = "GENESIS"
        for logged in reversed(self.log):
            if logged.actor == self.id:
                prev = logged.event_id
                break
        body = json.dumps(
            [self.id, key, op, payload, dict(self.clock), prev],
            sort_keys=True, separators=(",", ":"),
        ).encode()
        sig = self._sk.sign(body)
        ev = Event(self.id, key, op, payload, self.clock, prev, sig)
        self._apply_local(ev)
        return ev

    def _apply_local(self, ev, rebuild=True):
        self.log.append(ev)
        self.seen_ids.add(ev.event_id)
        for k, v in ev.clock.items():
            self.clock[k] = max(self.clock.get(k, 0), v)
        if rebuild:
            # Incremental apply (O1): fold the event into the
            # maintained state instead of rebuilding the whole log.
            # State stays fresh immediately after emit, exactly as
            # the old per-emit rebuild did, at O(1) per event.
            self._apply_incremental(ev)

    def _apply_incremental(self, ev):
        """Fold one event into the maintained state, in place.

        The merge decision itself is _apply_event_to_intermediates()
        — shared with _rebuild_state(), so the intermediates cannot
        diverge. This method only patches the materialized
        self.state view for the one key the event touches:

        - position: the winner's payload is written (O(1)).
        - counter_inc: the summed total is written (O(1)).
        - set_add: a new member is bisect.insort-ed into the
          already-sorted list (O(log m) search + memmove). Two
          exceptions: a float NaN payload, or a set that already
          holds a NaN — NaN breaks the total order sorted()
          assumes, so that key's list is re-sorted from the set,
          which is exactly what _rebuild_state() does.
        - unique_claim: the affected key's "unique" entry is
          recomputed from the standing claim and quarantine
          membership; "frozen_unique" only grows, and only on a
          new quarantine entry, via insort.

        Runs the verifier automatically every _VERIFY_EVERY applies.
        """
        if ev.op == "set_add":
            members = self._sets.get(ev.key)
            is_new = members is None or ev.payload not in members
            is_nan = isinstance(ev.payload, float) and math.isnan(
                ev.payload)
        else:
            is_new = False
            is_nan = False
        qlen_before = len(self.quarantine)
        _apply_event_to_intermediates(
            ev, self._positions, self._counters, self._sets,
            self._unique_claims, self.quarantine)
        if ev.op == "position":
            self.state["positions"][ev.key] = self._positions[ev.key][0]
        elif ev.op == "counter_inc":
            self.state["counters"][ev.key] = self._counters[ev.key]
        elif ev.op == "set_add":
            if is_new:
                if is_nan or ev.key in self._nan_set_keys:
                    if is_nan:
                        self._nan_set_keys.add(ev.key)
                    self.state["sets"][ev.key] = sorted(
                        self._sets[ev.key], key=_set_sort_key)
                else:
                    lst = self.state["sets"].setdefault(ev.key, [])
                    bisect.insort(lst, ev.payload, key=_set_sort_key)
        elif ev.op == "unique_claim":
            cur = self._unique_claims.get(ev.key)
            if cur is not None and cur not in self.quarantine:
                self.state["unique"][ev.key] = cur.actor
            else:
                self.state["unique"].pop(ev.key, None)
        if len(self.quarantine) > qlen_before:
            for qev in self.quarantine[qlen_before:]:
                if qev.key not in self._frozen_keys:
                    self._frozen_keys.add(qev.key)
                    bisect.insort(self.state["frozen_unique"], qev.key)
        self._applies_since_verify += 1
        if self._applies_since_verify >= _VERIFY_EVERY:
            self.verify_state()

    def verify_state(self):
        """Rebuild state from the full log and compare with the
        incrementally maintained state. Returns True when they
        match. On a mismatch the rebuilt state is kept as truth,
        the failure is counted in _verify_failures and recorded in
        _last_verify — the node self-heals instead of running on a
        diverged state. Runs automatically every _VERIFY_EVERY
        applies and at the end of every reconcile().
        """
        old = self.state
        self._rebuild_state()
        ok = _states_equal(old, self.state)
        self._verify_runs += 1
        self._last_verify = {"ok": ok, "log_len": len(self.log)}
        if not ok:
            self._verify_failures += 1
        return ok

    # -- receiving another node's log ------------------------------------
    def receive(self, events, public_keys):
        """Merge a batch of events from another node. Returns (applied, quarantined).

        Two passes. Pass 1 verifies the hash chain for the WHOLE batch
        before anything is applied: an event's prev_hash must equal
        the last known event id for its actor (GENESIS for its first
        event). A break rejects the whole batch — (0, new events) —
        because a chain that cannot be verified cannot be trusted.
        Pass 2 applies the events one by one, re-checking the chain
        as it goes (an event dropped here for a bad signature or
        payload also breaks the chain for its successors from the
        same actor, so they are dropped too), and counts every drop
        in `quarantined` instead of silently losing it. Each
        applied event is folded into state incrementally
        (_apply_incremental) — no full rebuild per batch.
        """
        # Last known event id per actor, from our own log.
        last_known = {}
        for logged in self.log:
            last_known[logged.actor] = logged.event_id
        new_events = [ev for ev in events if ev.event_id not in self.seen_ids]
        expected = dict(last_known)
        for ev in new_events:
            if ev.prev_hash != expected.get(ev.actor, "GENESIS"):
                return 0, len(new_events)
            expected[ev.actor] = ev.event_id
        applied, quarantined = 0, 0
        expected = dict(last_known)
        for ev in new_events:
            if ev.prev_hash != expected.get(ev.actor, "GENESIS"):
                quarantined += 1
                continue
            pk = public_keys.get(ev.actor)
            if pk is None:
                quarantined += 1
                continue  # unknown actor: drop, never apply
            try:
                _validate_event(ev)
            except ValueError:
                quarantined += 1
                continue  # malformed event: drop before applying
            # The event id is a content hash and is NOT covered by
            # the signature: a relay could rewrite it and get the
            # same event applied twice. Recompute it here and drop
            # a mismatch (from_dict already does the same check for
            # the reconcile path; this covers direct receive()).
            try:
                expected_id = _hash(
                    [ev.actor, ev.key, ev.op, ev.payload, ev.clock,
                     ev.prev_hash, ev.signature.hex()]
                )
            except (TypeError, AttributeError, ValueError):
                quarantined += 1
                continue  # unhashable content: drop, never apply
            if ev.event_id != expected_id:
                quarantined += 1
                continue  # forged event id: drop, never apply
            body = json.dumps(
                [ev.actor, ev.key, ev.op, ev.payload, ev.clock, ev.prev_hash],
                sort_keys=True, separators=(",", ":"),
            ).encode()
            try:
                Ed25519PublicKey.from_public_bytes(pk).verify(
                    ev.signature, body)
            except Exception:
                quarantined += 1
                continue  # bad signature: drop whole event
            self._apply_local(ev, rebuild=True)
            expected[ev.actor] = ev.event_id
            applied += 1
        return applied, quarantined

    def _rebuild_state(self):
        """Recompute merged state from the full log (deterministic).

        The merge rules live in _apply_event_to_intermediates(),
        shared with the incremental path, so a rebuild and the
        incremental path apply the same rule to the same event in
        the same order. This is the verifier: verify_state() runs
        it and compares against the incrementally maintained state.
        It also resets the maintained intermediates from the log,
        so after a rebuild the two paths are re-synced by
        construction, and resets the applies-since-verify count.
        """
        positions, counters, sets = {}, {}, {}
        unique_claims = {}
        quarantine = []
        for ev in self.log:
            _apply_event_to_intermediates(
                ev, positions, counters, sets, unique_claims, quarantine)
        self._positions, self._counters, self._sets = (
            positions, counters, sets)
        self._unique_claims = unique_claims
        self.quarantine = quarantine
        self._frozen_keys = {ev.key for ev in quarantine}
        self._nan_set_keys = {
            k for k, s in sets.items()
            if any(isinstance(v, float) and math.isnan(v) for v in s)
        }
        self.state = {
            "positions": {k: v[0] for k, v in positions.items()},
            "counters": dict(counters),
            "sets": {k: sorted(v, key=_set_sort_key) for k, v in sets.items()},
            "unique": {
                k: v.actor
                for k, v in unique_claims.items()
                if v not in quarantine
            },
            "frozen_unique": sorted(self._frozen_keys),
        }
        self._applies_since_verify = 0

    # -- batches / reconciliation ----------------------------------------
    def batch_manifest(self, batch_size=100):
        """Split log into batches; each batch gets a signed Merkle manifest."""
        manifests = []
        for i in range(0, len(self.log), batch_size):
            batch = self.log[i : i + batch_size]
            root = _merkle_root([e.event_id for e in batch])
            body = json.dumps([self.id, i, root], separators=(",", ":")).encode()
            manifests.append(
                {
                    "node": self.id,
                    "offset": i,
                    "merkle_root": root,
                    "signature": self._sk.sign(body).hex(),
                    "events": [e.to_dict() for e in batch],
                }
            )
        return manifests

    def reconcile(self, other_manifests, public_keys):
        """Pull missing batches, verify, merge. Returns total applied.

        A malformed batch is skipped, never fatal: a manifest missing
        "events", an event dict missing "signature"/"clock", or a
        manifest whose signature does not verify all skip the batch
        instead of raising into the caller (the caller is node.py's
        /reconcile handler, where a raise becomes a 500 and the good
        batches in the same call would be lost too).
        """
        total = 0
        for m in other_manifests:
            try:
                events = [Event.from_dict(d) for d in m["events"]]
            except (KeyError, TypeError, ValueError):
                continue  # malformed batch: skip, keep reconciling
            if _merkle_root([e.event_id for e in events]) != m["merkle_root"]:
                continue  # failed batch rejected whole
            if not _verify_manifest(m, public_keys):
                continue  # manifest signature or attribution failed
            applied, _ = self.receive(events, public_keys)
            total += applied
        # Verifier (O1): the receives above maintained state
        # incrementally; rebuild from the log once and compare.
        # A mismatch keeps the rebuilt state as truth and is
        # counted in _verify_failures — see verify_state().
        self.verify_state()
        return total


def _verify_manifest(manifest, public_keys):
    """Verify one manifest's signature.

    The manifest signature covers [node, offset, merkle_root] with
    the node's key, so a relay cannot forge a manifest claiming to
    be from a node it does not hold the key for, and cannot tamper
    with the batch (the Merkle root covers the event ids) without
    breaking the signature. The events themselves are verified
    separately by receive(): each event's signature is checked
    against public_keys[its own actor], and the actor is part of
    the signed body, so an event's authorship cannot be forged.

    What this deliberately does NOT require: every event's actor
    must equal the manifest's node. A node's log is a RELAY log —
    after node A reconciles node B's events, A's manifest contains
    B's events too, and requiring actor == node would reject every
    relayed batch. A relay may re-bundle another node's events
    under its own node id, but then the manifest honestly says the
    relay assembled the batch, and the events still carry their
    original authors' signatures.

    Residual gap, stated plainly: public_keys is caller-supplied —
    there is no independent key registry — so this proves the
    manifest was signed by the key the caller trusts for that node
    id. It cannot prove that key belongs to the real node; a relay
    that invents a new node id with its own key passes. That gap
    is the deferred registry-auth work (audit item 2), not
    something reconcile() can close on its own.
    """
    node = manifest.get("node")
    public_key = public_keys.get(node)
    if public_key is None:
        return False
    try:
        signature = bytes.fromhex(manifest["signature"])
        body = json.dumps(
            [node, manifest["offset"], manifest["merkle_root"]],
            separators=(",", ":"),
        ).encode()
        Ed25519PublicKey.from_public_bytes(public_key).verify(
            signature, body)
    except Exception:
        return False
    return True


def blink_fallback(hashes_per_sec, inbetween_rtt_ms=None):
    """Graded hash-rate fallback from the v2 design. Returns (mode, note)."""
    if hashes_per_sec >= 24_000_000:
        return ("full_blink_local", "modeled ~4 ms validation")
    if 8_000_000 <= hashes_per_sec < 24_000_000:
        if inbetween_rtt_ms is not None and inbetween_rtt_ms <= 5:
            return (
                "offload_to_inbetween",
                "modeled 8-15 ms total; blinks missing the 10 ms limit "
                "are rejected as late, not granted retroactively",
            )
        return ("manual_timed_dodge", "no auto-dodge benefit, no extra latency")
    return (
        "degraded_gameplay_only",
        "gameplay degrades; attestation-gated actions "
        "(rewards, unique claims) are locked out",
    )
