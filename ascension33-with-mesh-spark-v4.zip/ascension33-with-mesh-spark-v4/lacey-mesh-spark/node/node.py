"""Runnable in-between node: Lacey computing and existing on a node.

This is a real running process, not a unit test. It wires Lacey v1
(the research-mesh core) to the mesh registry over the registry's
WebSocket protocol and runs her sense / verify / attest / sever /
reconcile loop on real protocol messages as they arrive.

What is REAL here:
- the WebSocket session with the registry (hello, challenge,
  hello-proof, heartbeat, request_task, submit_task, attest,
  key_rotate) — the real auth-v1 protocol (mesh-auth-v1), spoken
  to the real registry server (server.js) when it runs locally;
- the identity: the node signs with the key from its identity
  file (--identity-file, design §7) when one is given, so the
  registry can verify the node is who it claims to be; without
  an identity file the node signs with a fresh ephemeral key and
  first-claim-registers it;
- the task solving: real SHA-256 nonce search at the registry's
  difficulty, counted and timed (measured);
- the attestation claims: signed with the node's real Ed25519 key
  over the auth-v1 body (design §4), sequenced with the per-node
  seq (== missionIdx on this leg), sampled at the approved 10% by
  the wired random per-index sampler (seeded; test seed for local
  runs); the welcome's attestWatermark fast-forwards the sequence
  after a lost state file;
- severance: declared by Lacey on missed heartbeats, local events
  kept going while severed, reconcile on reconnect via the real
  merge-by-type logic;
- the status endpoint: real node state, served live;
- the fog envelope link (Step 4, only with --fog-relay): a SECOND
  WebSocket to a parked relay, used only for node-to-node manifest
  envelopes. The node announces itself to the relay (envelope
  mode — no registry pairing on that socket), sends its signed
  manifest batches to a peer node id on POST /send-manifest, and
  reconciles manifest envelopes that arrive, but ONLY from
  senders whose public key was configured explicitly with
  --peer-key. Envelope-supplied keys are never trusted, and key
  distribution is a future step, not something this link does.
  The registry session is unaffected by the fog link in either
  direction: the fog link works with the registry entirely down,
  and a dead fog link changes nothing about the registry session.
  With --onion-relays (Step 6, only meaningful together with
  --fog-relay), POST /send-manifest instead wraps the manifest
  envelope's payload in an onion (onion_py.py — P-256 ECDH
  layers per the relay PROTOCOL.md spec) over the listed relay
  path and sends the onion frame to the first relay over the fog
  link, so intermediate relays can no longer read the manifest
  or learn its destination. Each path relay's onion key is
  fetched from its /onion-key endpoint at send time (the keys
  are ephemeral per relay run, so nothing is cached). If any
  fetch fails, the node falls back to the plain envelope and
  logs the fallback. Without --onion-relays, behavior is exactly
  as before.

What is STUB / SIMULATED here, stated on the log lines that use it:
- Pattern C runs on a STUB draft/verifier with fixed toy tokens.
  There is no inference model. It exercises the protocol path only.
- The local test runs over a loopback WebSocket, which stands in
  for the Wi-Fi link in the test; Pattern C is routed as wifi for
  that reason, and the log says so (SIMULATED). No radio behaviour
  is measured or claimed: BLE / Wi-Fi Aware / Wi-Fi Direct on the
  phone stay UNKNOWN until the phone measurement run.
- The registry this talks to by default is the LOCAL TEST REGISTRY
  (server.js on this machine). The production registry on the VPS
  is NOT deployed; pointing this process at it will fail to
  connect, and the node will keep acting locally in autonomous
  mode — that is the honest behaviour, not an error to hide.

Run: see RUN-NODE.md. The seed never lives in this repo: pass
--seed for local runs, or set LACEY_ATTEST_SEED. The factory
refuses to build without one. The attestation seed may also come
from a file (--seed-file or LACEY_ATTEST_SEED_FILE), which keeps it
out of the process command line and shell history. The node's
identity may come from a file too (--identity-file or
LACEY_IDENTITY_FILE); the ghost passes its own identity file, so
the node signs with the ghost's persistent key.
"""
import argparse
import hashlib
import json
import os
import signal
import ssl
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
)

_HERE = Path(__file__).resolve().parent
_LACEY_DIR = Path.home() / "workspace" / "lacey" / "v1"
for _p in (str(_HERE), str(_LACEY_DIR)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import onion_py  # noqa: E402
from lacey import Lacey  # noqa: E402
from lacey_config import (  # noqa: E402
    APPROVED_RATE,
    SAMPLING_MODE,
    TIME_CRITICAL_RATE,
    build_wired_lacey,
)
from pattern_c import PatternC, route_inference  # noqa: E402
from wsclient import ConnectionClosed, WebSocketClient  # noqa: E402
from identity import (  # noqa: E402
    confirm_rotation,
    load_identity_file,
    public_key_hex,
    write_pending_rotation,
)

VERSION = "0.3.0"  # hybrid release "Ghost v2": mesh-auth-v1 + O1
TEST_SEED_NOTE = "test seed for local runs only"

# Auth v1 (mesh-auth-v1, design §0): the domain separator is the
# first element of every signed body. The second element is the
# design's type tag ("auth-v1", "attest-v1", "key-rotate-v1") — the
# design's §2/§4/§6 bodies show the type tag first, while §0 and
# this build's spec put the domain separator first; the separator
# wins, the tag is kept second so the bodies stay recognizable
# against the design. All three sides (server, node, game client)
# sign these exact bodies.
AUTH_DOMAIN = "pirgitori-auth-v1"


def hello_proof_body(nonce, node_id):
    """Canonical bytes of a hello-proof signed body (design §2)."""
    return json.dumps(
        [AUTH_DOMAIN, "auth-v1", nonce, node_id],
        separators=(",", ":")).encode()


def attest_body(node_id, seq, mission_idx, events_attested):
    """Canonical bytes of a node attestation signed body (§4)."""
    return json.dumps(
        [AUTH_DOMAIN, "attest-v1", node_id, seq, mission_idx,
         events_attested],
        separators=(",", ":")).encode()


def key_rotate_body(node_id, old_pubkey_hex, new_pubkey_hex):
    """Canonical bytes of a key-rotation signed body (§6)."""
    return json.dumps(
        [AUTH_DOMAIN, "key-rotate-v1", node_id, old_pubkey_hex,
         new_pubkey_hex],
        separators=(",", ":")).encode()


class SessionActiveError(ConnectionError):
    """The registry rejected the hello: a live session already holds
    this node id (D1 session-active). The client must back off
    (10 s minimum) and retry, not reconnect-loop."""

    def __init__(self, message):
        super().__init__(message)
        self.reason = "session-active"


class AuthError(ConnectionError):
    """The registry rejected the hello-proof (auth-failed,
    key-mismatch, challenge-expired, bad-pubkey, ...). Carries the
    server's reason."""

    def __init__(self, message, reason=None):
        super().__init__(message)
        self.reason = reason


def _now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _stub_draft_infer(prompt):
    """STUB: fixed toy tokens. No model exists behind this."""
    return {"tokens": ["STUB-tok-1", "STUB-tok-2"], "confidence": 0.95}


def _stub_verify_infer(prompt, tokens):
    """STUB: accepts every toy token. No verification model exists."""
    return {"accepted_count": len(tokens), "authoritative_tokens": []}


def _stub_draft_classify(prompt):
    """STUB: fixed toy verdict. No model exists behind this."""
    return {"verdict": "STUB-verdict-benign", "confidence": 0.95}


def _stub_verify_classify(prompt, verdict):
    """STUB: confirms the toy verdict. No verification model exists."""
    return {"confirmed": True, "verdict": verdict}


class MeshNode:
    """One in-between node process: Lacey wired to the registry."""

    def __init__(self, node_id, registry_url, seed, status_port,
                 heartbeat_interval=5.0, missed_threshold=3,
                 log_file=None, seed_file=None, state_file=None,
                 ssl_context=None, identity_file=None,
                 fog_relay_url=None, peer_keys=None,
                 onion_relays=None):
        self.node_id = node_id
        self.registry_url = registry_url
        host = registry_url.split("://", 1)[-1].split(":", 1)[0]
        self.registry_kind = (
            "LOCAL TEST REGISTRY — real v0 registry server.js on this "
            "machine"
            if host in ("127.0.0.1", "localhost", "::1")
            else "PRODUCTION REGISTRY — VPS (not deployed; connection "
            "is expected to fail until Edward deploys it)"
        )
        self.status_port = status_port
        self.heartbeat_interval = heartbeat_interval
        self.missed_threshold = missed_threshold
        self._log_file = log_file
        self._log_lines = []
        self._lock = threading.RLock()
        self._shutdown = threading.Event()
        self._start_mono = time.monotonic()
        self._ssl_context = ssl_context

        # Auth v1 identity (design §7): when an identity file is
        # given, the node signs with the file's key — the ghost's
        # persistent key, or a test key — and the file's node_id
        # must equal the --node-id passed here, or startup fails
        # fast instead of running under a mismatched id. Without
        # a file, the core generates a fresh ephemeral key exactly
        # as before (first-claim-registered on hello).
        self._identity_file = (
            Path(identity_file) if identity_file else None)
        self._identity = None
        identity_key = None
        if self._identity_file is not None:
            self._identity = load_identity_file(self._identity_file)
            if self._identity["node_id"] != node_id:
                raise ValueError(
                    f"identity file {self._identity_file} is for node "
                    f"{self._identity['node_id']!r}, not {node_id!r}; "
                    "refusing to run under a mismatched id")
            identity_key = self._identity["private_key"]

        self.wired = build_wired_lacey(
            node_id, seed=seed, seed_file=seed_file,
            identity_key=identity_key)
        self.lacey = self.wired.lacey
        self.pattern_c = PatternC()
        self.pattern_c_runs = 0
        self.pattern_c_paths = {}

        self._ws = None
        self.connected = False

        # Fog envelope link (Step 4): entirely optional. With no
        # --fog-relay the node behaves exactly as before. Peer keys
        # come ONLY from explicit --peer-key config; they are
        # validated as hex here so a typo fails at startup, not
        # inside a reconcile on the fog reader thread.
        self.fog_relay_url = fog_relay_url
        self.peer_keys = dict(peer_keys or {})
        for _nid, _hex in self.peer_keys.items():
            try:
                bytes.fromhex(_hex)
            except ValueError:
                raise ValueError(
                    f"--peer-key for {_nid!r} is not hex")
        self._fog_ws = None
        self._fog_thread = None
        self.fog_connected = False
        self.fog_sent = 0
        # Onion manifest sends (Step 6): the ordered relay URLs
        # whose /onion-key endpoints form the wrap path. Empty
        # unless --onion-relays was given; the plain envelope
        # path above is untouched when it is empty.
        self.onion_relays = list(onion_relays or [])
        self.onion_sent = 0
        self.onion_fallbacks = 0
        self.fog_received = 0
        self.fog_rejected_untrusted = 0
        self.fog_last_reconcile = None

        self.peers = "unknown"
        self.session_id = None
        self._session_takeover = False
        self._reader_thread = None
        self._waiters = {}
        self._awaiting_ack = False
        self._last_hb_sent = 0.0
        self._next_backoff = 1.0

        # Measured counters (counted from this process's own runs).
        self.events_emitted = 0
        self.tasks_solved = 0
        self.nonces_tried = 0
        self.tpirg_test = 0
        self.attest_sent = 0
        self.attest_acked = 0
        self.attest_local_only = 0
        self.attest_unsent = 0
        self.time_critical_sent = 0
        self.next_mission_idx = 0
        # Fix 3: the next mission index is persisted to a state file
        # (default node-state-<node-id>.json in the working
        # directory). The registry remembers which mission indices
        # it has already seen, so a restarted node that re-sent
        # 0..N would have every attestation rejected as a duplicate
        # and could never attest again until the ledger was wiped.
        self._state_file = Path(state_file) if state_file else Path(
            f"node-state-{node_id}.json")
        self._load_state()

    # -- persisted attestation state (fix 3, fix 11) ---------------------
    def _load_state(self):
        """Resume next_mission_idx from the state file, if it is usable.

        A missing, corrupt, or mismatched state file (wrong node id,
        or a next_mission_idx that is not a non-negative integer)
        starts at 0 and logs a warning — the node can still run, but
        its first attestations may be rejected as duplicates by a
        registry that already saw those indices.
        """
        try:
            with open(self._state_file, encoding="utf-8") as fh:
                state = json.load(fh)
        except (OSError, ValueError):
            return
        if not isinstance(state, dict):
            self.log("MEASURED",
                     f"state file {self._state_file} is not a JSON "
                     "object; starting mission index at 0")
            return
        if state.get("node_id") != self.node_id:
            self.log("MEASURED",
                     f"state file {self._state_file} belongs to "
                     f"{state.get('node_id')!r}, not {self.node_id!r}; "
                     "starting mission index at 0")
            return
        idx = state.get("next_mission_idx")
        if isinstance(idx, bool) or not isinstance(idx, int) or idx < 0:
            self.log("MEASURED",
                     f"state file {self._state_file} has an unusable "
                     f"next_mission_idx {idx!r}; starting at 0")
            return
        self.next_mission_idx = idx
        self.log("MEASURED",
                 f"resumed mission index {idx} from {self._state_file}")

    def _save_state(self):
        """Persist next_mission_idx atomically (temp file + rename)."""
        tmp = self._state_file.with_suffix(".tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"node_id": self.node_id,
                           "next_mission_idx": self.next_mission_idx},
                          fh)
            os.replace(tmp, self._state_file)
        except OSError as exc:
            self.log("MEASURED",
                     f"could not save state file {self._state_file}: "
                     f"{exc} (attestations may duplicate after restart)")

    def _attest_log_path(self):
        """JSONL log for unsampled attestations, next to the state file."""
        return self._state_file.with_suffix(".attest.jsonl")

    def _log_unsampled(self, claim):
        """Append one unsampled claim to the local attestation log.

        Unsampled claims are never sent to the registry and never
        claimed as verified, but they are recorded — the record is
        what the sampler's audit trail is made of. A write failure
        is logged, not fatal: losing the local record must not stop
        the node from attesting.
        """
        record = dict(claim)
        record["sampled"] = False
        record["recorded_at"] = _now_iso()
        try:
            with open(self._attest_log_path(), "a",
                      encoding="utf-8") as fh:
                fh.write(json.dumps(record) + "\n")
        except OSError as exc:
            self.log("MEASURED",
                     f"could not append to attestation log "
                     f"{self._attest_log_path()}: {exc}")

    # -- logging --------------------------------------------------------
    def log(self, tag, message):
        line = f"[{_now_iso()}] [{tag}] {message}"
        with self._lock:
            self._log_lines.append(line)
            self._log_lines = self._log_lines[-500:]
        print(line, flush=True)
        if self._log_file:
            try:
                with open(self._log_file, "a", encoding="utf-8") as fh:
                    fh.write(line + "\n")
            except OSError:
                pass

    # -- registry session -------------------------------------------------
    # Waiters are keyed per call, not per message type: _waiters maps
    # a message type to a LIST of (event, box, match) triples, where
    # match is None (take the first message of that type) or a
    # predicate on the message (for example the taskId or missionIdx
    # the caller is waiting for). A waiter is always registered
    # BEFORE the request is sent, so a fast reply cannot arrive
    # before anyone is listening, and two concurrent calls of the
    # same type no longer overwrite each other's waiter.
    def _new_waiter(self, msg_type, match=None):
        event = threading.Event()
        box = {}
        with self._lock:
            self._waiters.setdefault(msg_type, []).append(
                (event, box, match))
        return event, box

    def _drop_waiter(self, msg_type, event, box):
        with self._lock:
            waiters = self._waiters.get(msg_type, [])
            self._waiters[msg_type] = [
                w for w in waiters if w[0] is not event or w[1] is not box
            ]
            if not self._waiters[msg_type]:
                self._waiters.pop(msg_type, None)

    def _await_waiter(self, msg_type, event, box, timeout):
        try:
            if event.wait(timeout):
                return box.get("message")
            return None
        finally:
            self._drop_waiter(msg_type, event, box)

    def _send_and_wait(self, obj, msg_type, timeout, match=None):
        """Register the waiter, then send, then wait for the reply.

        Registering first is the fix: the old code sent before
        registering, so a reply that arrived in between was silently
        dropped and the caller timed out. If the send itself raises,
        the waiter is dropped again so it cannot swallow a later
        reply of the same type.
        """
        event, box = self._new_waiter(msg_type, match)
        try:
            self._send(obj)
        except Exception:
            self._drop_waiter(msg_type, event, box)
            raise
        return self._await_waiter(msg_type, event, box, timeout)

    def _dispatch(self, msg):
        mtype = msg.get("type")
        with self._lock:
            waiters = self._waiters.get(mtype, [])
            for index, (event, box, match) in enumerate(list(waiters)):
                if match is None or match(msg):
                    box["message"] = msg
                    event.set()
                    waiters.pop(index)
                    break
            if not waiters:
                self._waiters.pop(mtype, None)
        if mtype == "welcome":
            self.peers = msg.get("peers", "unknown")
            self.log("MEASURED",
                     f"welcome from registry: peers={self.peers} "
                     f"ledgerHeight={msg.get('ledgerHeight')} "
                     f"tpirg={msg.get('tpirg')}")
            # A welcome means the link is live: reset the missed
            # count, and leave autonomous mode if we were in it.
            self.lacey.heartbeat(True, self.missed_threshold)
        elif mtype == "hb-ack":
            self._awaiting_ack = False
            self.peers = msg.get("peers", self.peers)
            self.lacey.heartbeat(True, self.missed_threshold)
        elif mtype == "peers":
            self.peers = msg.get("count", self.peers)
        elif mtype == "error":
            self.log("MEASURED", f"registry error: {msg.get('reason')}")

    def _reader_loop(self):
        while not self._shutdown.is_set():
            try:
                text = self._ws.recv_text(timeout=1.0)
            except TimeoutError:
                continue
            except (ConnectionClosed, OSError, ValueError) as exc:
                if self._shutdown.is_set():
                    # Shutdown closes the socket under the reader;
                    # that is a clean stop, not a lost connection.
                    return
                # Close code 4000 is a session-takeover: another
                # process with this key took over a stale session.
                # Log it as a takeover (not a network error) so the
                # run loop backs off 10 s before reconnecting.
                ws = self._ws
                if ws is not None and ws.close_code == 4000:
                    self._session_takeover = True
                    self.log("MEASURED",
                             "registry session taken over by another "
                             "process with this key (close code 4000); "
                             "backing off before reconnecting")
                else:
                    self.log("MEASURED",
                             f"registry connection lost: {exc}")
                with self._lock:
                    self.connected = False
                return
            try:
                msg = json.loads(text)
            except json.JSONDecodeError:
                self.log("MEASURED", "registry sent a non-JSON message; ignored")
                continue
            self._dispatch(msg)

    def _send(self, obj):
        if self._ws is None or not self.connected:
            raise ConnectionClosed("not connected to registry")
        self._ws.send_text(json.dumps(obj))

    def connect(self):
        """One connect attempt: upgrade, start the reader, hello,
        challenge, hello-proof, welcome (auth v1, design §2).

        The reader thread must start BEFORE hello is sent: it is the
        only thing reading the socket, so a challenge can only arrive
        through it. Waiters for challenge / welcome / error are
        registered BEFORE hello is sent, for the same reason (fix 10).
        """
        ws = WebSocketClient(self.registry_url,
                             ssl_context=self._ssl_context)
        ws.connect()
        with self._lock:
            self._ws = ws
            self.connected = True
            self._awaiting_ack = False
            self._next_backoff = 1.0
        self._reader_thread = threading.Thread(
            target=self._reader_loop, daemon=True)
        self._reader_thread.start()
        try:
            self._auth_handshake(ws)
        except Exception:
            with self._lock:
                self.connected = False
            try:
                ws.close()
            except Exception:
                pass
            raise
        self.log("MEASURED",
                 f"connected to registry {self.registry_url} "
                 f"({self.registry_kind})")

    def _error_from_message(self, msg):
        """Turn a registry {type:'error'} into the matching exception."""
        reason = (msg or {}).get("reason") or "unknown"
        if reason == "session-active":
            return SessionActiveError(
                "registry rejected hello: session-active — a live "
                f"session already holds {self.node_id}; backing off")
        return AuthError(
            f"registry rejected hello: {reason}", reason=reason)

    def _wait_for_either(self, event_a, box_a, event_b, box_b,
                         timeout, what):
        """Wait for the first of two waiter events; the second event
        is an error message, which raises the matching exception.
        Polls in 0.1 s slices so the error is noticed promptly."""
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ConnectionError(
                    f"no {what} from registry in {timeout}s")
            if event_a.wait(min(remaining, 0.1)):
                return box_a.get("message")
            if event_b.wait(0):
                raise self._error_from_message(box_b.get("message"))

    def _hello_proof_attempt(self, ws, key):
        """One hello + challenge + hello-proof round with one key.

        Returns after the welcome is received (and _on_welcome has
        run). Raises SessionActiveError / AuthError /
        ConnectionError on any rejection or timeout.
        """
        pub_hex = public_key_hex(key)
        challenge_event, challenge_box = self._new_waiter("challenge")
        error_event, error_box = self._new_waiter("error")
        try:
            ws.send_text(json.dumps({
                "type": "hello",
                "nodeId": self.node_id,
                "pubkeyHex": pub_hex,
                "protocol": "mesh-auth-v1",
                "deviceCaps": {
                    "lacey": "v1",
                    "mode": "research-mesh",
                    "transport": "local-ws-test",
                    "pattern_c": "stub",
                },
                "gameVersion": VERSION,
            }))
            challenge = self._wait_for_either(
                challenge_event, challenge_box,
                error_event, error_box, 5.0, "challenge")
            if not challenge or "nonce" not in challenge:
                raise ConnectionError(
                    "registry sent a malformed challenge")
            sig = key.sign(
                hello_proof_body(challenge["nonce"], self.node_id)).hex()
            welcome_event, welcome_box = self._new_waiter("welcome")
            error_event2, error_box2 = self._new_waiter("error")
            try:
                ws.send_text(json.dumps({
                    "type": "hello-proof",
                    "nodeId": self.node_id,
                    "pubkeyHex": pub_hex,
                    "nonce": challenge["nonce"],
                    "sig": sig,
                }))
                welcome = self._wait_for_either(
                    welcome_event, welcome_box,
                    error_event2, error_box2, 5.0, "welcome")
            finally:
                self._drop_waiter("welcome", welcome_event, welcome_box)
                self._drop_waiter("error", error_event2, error_box2)
            self._on_welcome(welcome)
        finally:
            self._drop_waiter("challenge", challenge_event, challenge_box)
            self._drop_waiter("error", error_event, error_box)

    def _on_welcome(self, welcome):
        """Record the session and fast-forward the attestation
        sequence from the welcome's watermark (design §4).

        If this node lost its state file, its next seq restarts at
        0 and every attestation would be rejected stale-seq forever;
        the watermark closes that lockout: next seq becomes
        max(local next, watermark + 1), persisted before anything
        is sent.
        """
        self.session_id = welcome.get("sessionId")
        watermark = welcome.get("attestWatermark")
        if isinstance(watermark, int) and watermark >= 0:
            with self._lock:
                if watermark + 1 > self.next_mission_idx:
                    self.next_mission_idx = watermark + 1
                    self._save_state()
                    self.log("MEASURED",
                             f"welcome watermark {watermark}: "
                             "fast-forwarded mission index to "
                             f"{self.next_mission_idx} (lost state "
                             "file recovery)")
        self.log("MEASURED",
                 f"welcome from registry: session={self.session_id} "
                 f"peers={welcome.get('peers')} "
                 f"ledgerHeight={welcome.get('ledgerHeight')} "
                 f"tpirg={welcome.get('tpirg')} "
                 f"attestWatermark={watermark}")

    def _auth_handshake(self, ws):
        """Hello-proof exchange, with lost-ack rotation recovery (§6).

        Keys are tried in order: the current key, then the previous
        key if a rotation is pending in the identity file. Only a
        key-mismatch on the new key justifies trying the old key
        (the rotation may not have landed on the server). Any other
        failure is final for this connect attempt.
        """
        attempts = [self.lacey.node._sk]
        pending = (self._identity is not None
                   and self._identity.get("rotation_pending")
                   and self._identity.get("previous_key") is not None)
        if pending:
            attempts.append(
                self._identity["previous_key"]["private_key"])
        last_error = None
        for index, key in enumerate(attempts):
            # The in-memory signing key always matches the key being
            # tried, so after the handshake it equals the key the
            # session authenticated with.
            self.lacey.node.rotate_key(key)
            try:
                self._hello_proof_attempt(ws, key)
            except AuthError as exc:
                last_error = exc
                if (pending and index == 0
                        and exc.reason == "key-mismatch"):
                    # The rotation may not have landed: the next
                    # attempt signs with the old key.
                    continue
                raise
            if pending and index == 1:
                # Connected with the old key: the rotation did not
                # land. Re-issue it on this live session.
                self._recover_pending_rotation()
            elif pending and index == 0:
                # The new key verified: the rotation landed and only
                # the ack was lost. Mark it complete in the file.
                self._confirm_pending_rotation()
            return
        raise last_error

    def _send_key_rotate(self, old_key, new_key):
        """Send one key_rotate message on the live session and wait
        for the ack. Raises TimeoutError / ConnectionClosed when the
        ack never arrives (the rotation stays pending in the file).
        """
        old_hex = public_key_hex(old_key)
        new_hex = public_key_hex(new_key)
        sig = old_key.sign(
            key_rotate_body(self.node_id, old_hex, new_hex)).hex()
        ack = self._send_and_wait(
            {"type": "key_rotate", "nodeId": self.node_id,
             "oldPubkeyHex": old_hex, "newPubkeyHex": new_hex,
             "sig": sig},
            "key_rotate_ack", 5.0)
        if ack is None:
            raise TimeoutError("no key_rotate_ack from registry in time")
        return ack

    def _confirm_pending_rotation(self, ack=None):
        """Mark the identity file's pending rotation complete."""
        if self._identity_file is None:
            return
        expires_at = None
        if ack is not None:
            expires_at = ack.get("previousKeyExpiresAt")
        if expires_at is None:
            expires_at = int(time.time() * 1000) + 7 * 24 * 3600 * 1000
        try:
            self._identity = confirm_rotation(
                self._identity_file, expires_at)
        except ValueError as exc:
            self.log("MEASURED",
                     f"could not confirm pending rotation: {exc}")

    def _recover_pending_rotation(self):
        """Re-issue a rotation that did not land (old key verified).

        The identity file already holds both keys with
        rotation_pending=true; this sends key_rotate on the live
        session and, on ack, confirms the file and switches the
        signing key to the new one.
        """
        new_key = self._identity["private_key"]
        old_key = self._identity["previous_key"]["private_key"]
        try:
            ack = self._send_key_rotate(old_key, new_key)
        except (ConnectionClosed, OSError, TimeoutError) as exc:
            self.log("MEASURED",
                     f"pending rotation re-issue got no ack ({exc}); "
                     "rotation stays pending; the next connect "
                     "recovers it")
            return
        if not ack.get("ok"):
            self.log("MEASURED",
                     "pending rotation re-issue rejected: "
                     f"{ack.get('reason')}")
            return
        self._confirm_pending_rotation(ack)
        self.lacey.node.rotate_key(new_key)
        self.log("MEASURED",
                 "pending rotation recovered: server registered the "
                 f"new key {public_key_hex(new_key)[:12]}...; signing "
                 "with it from here on")

    def rotate_key(self):
        """Rotate this node's registry key (design §6, manual /
        operator-triggered, via POST /rotate-key).

        Returns a summary dict. Needs a live session and an
        identity file. Generates a fresh keypair, records the
        pending rotation in the identity file FIRST (so a lost ack
        still leaves both keys on disk for the next connect), sends
        key_rotate on the live session, and on ack confirms the
        file and switches the signing key. The session is NOT
        closed by the rotation.
        """
        if self._identity_file is None:
            return {"ok": False, "reason": "no-identity-file"}
        if not self.connected:
            return {"ok": False, "reason": "not-connected"}
        new_key = Ed25519PrivateKey.generate()
        old_key = self.lacey.node._sk
        self._identity = write_pending_rotation(
            self._identity_file, new_key)
        try:
            ack = self._send_key_rotate(old_key, new_key)
        except (ConnectionClosed, OSError, TimeoutError) as exc:
            self.log("MEASURED",
                     f"rotation sent but no ack ({exc}); rotation "
                     "stays pending in the identity file; the next "
                     "connect recovers it")
            return {"ok": False, "reason": "no-ack", "pending": True}
        if not ack.get("ok"):
            # The server refused: roll the file back to the old key.
            try:
                from identity import cancel_pending_rotation  # noqa: E402
                self._identity = cancel_pending_rotation(
                    self._identity_file)
            except ValueError as exc:
                self.log("MEASURED",
                         f"rotation refused and rollback failed: {exc}")
            return {"ok": False, "reason": ack.get("reason")}
        self._confirm_pending_rotation(ack)
        self.lacey.node.rotate_key(new_key)
        self.log("MEASURED",
                 "key rotated: server registered "
                 f"{public_key_hex(new_key)[:12]}...; previous key "
                 "valid inside its grace window")
        return {"ok": True,
                "new_public_key_hex": public_key_hex(new_key),
                "previous_key_expires_at": ack.get(
                    "previousKeyExpiresAt")}

    # -- local node actions ----------------------------------------------
    def emit_event(self, op, key, payload):
        if op not in ("position", "counter_inc", "set_add", "unique_claim"):
            raise ValueError(f"unknown op {op!r}")
        with self._lock:
            ev = self.lacey.node.emit(key, op, payload)
            self.events_emitted += 1
        self.log("MEASURED",
                 f"local event emitted: op={op} key={key} "
                 f"event_id={ev.event_id[:12]}... "
                 f"provisional={self.lacey.node.provisional}")
        return ev

    def solve_task(self, task):
        """Real SHA-256 nonce search at the registry's difficulty.

        Returns (solutions, nonces_tried, seconds) — all measured.
        """
        started = time.monotonic()
        solutions = []
        tried = 0
        difficulty = int(task["difficulty"])
        prefix = "0" * difficulty
        for seed in task["seeds"]:
            nonce = 0
            while True:
                tried += 1
                digest = hashlib.sha256(
                    f"{seed}:{nonce}".encode("ascii")).hexdigest()
                if digest.startswith(prefix):
                    solutions.append({"seed": seed, "nonce": nonce})
                    break
                nonce += 1
        elapsed = time.monotonic() - started
        return solutions, tried, elapsed

    def request_task(self, timeout=15.0):
        """Ask the registry for a task, solve it, submit it.

        Returns the task_result message dict.
        """
        task_msg = self._send_and_wait(
            {"type": "request_task"}, "task", timeout)
        if task_msg is None:
            raise TimeoutError("no task from registry in time")
        task = task_msg.get("task")
        if not task:
            return {"ok": False, "reason": "no_task"}
        solutions, tried, elapsed = self.solve_task(task)
        with self._lock:
            self.nonces_tried += tried
        self.log("MEASURED",
                 f"task {task['taskId']} solved: {tried} nonces tried "
                 f"in {elapsed:.2f}s (measured); submitting")
        result = self._send_and_wait(
            {"type": "submit_task", "taskId": task["taskId"],
             "solutions": solutions},
            "task_result", timeout,
            match=lambda m, tid=task["taskId"]: m.get("taskId") == tid)
        if result is None:
            raise TimeoutError("no task_result from registry in time")
        if result.get("ok"):
            with self._lock:
                self.tasks_solved += 1
                self.tpirg_test = result.get("tpirg", self.tpirg_test)
            self.log("MEASURED",
                     f"task_result: verified={result.get('verified')} "
                     f"tpirg(test)={result.get('tpirg')}")
        else:
            self.log("MEASURED",
                     f"task_result: NOT accepted: {result.get('reason')}")
        return result

    def _sign_claim(self, mission_idx, events_attested):
        """Sign one attestation claim (auth v1, design §4).

        The signed body is ["pirgitori-auth-v1", "attest-v1",
        nodeId, seq, missionIdx, eventsAttested] with seq ==
        missionIdx on this leg. The server verifies it against the
        registered key (or the previous key inside its grace).
        """
        body = attest_body(self.node_id, mission_idx, mission_idx,
                           events_attested)
        return self.lacey.node._sk.sign(body).hex()

    def attest_batch(self, count, time_critical=0, timeout=5.0):
        """Create attestation claims and send the sampled ones.

        Standard claims go through the wired 10% random per-index
        sampler: sampled claims are sent to the registry, unsampled
        ones are appended to the local attestation log (JSONL next
        to the state file) — recorded locally, never sent, never
        claimed as verified. Time-critical claims are always sent
        (100%). The mission index is saved to the state file after
        every allocation, so a restarted node resumes where it left
        off instead of re-sending indices the registry already saw.
        Returns a summary dict with measured counts.
        """
        sent = acked = local_only = tc_sent = 0
        for _ in range(int(count)):
            with self._lock:
                mission_idx = self.next_mission_idx
                self.next_mission_idx += 1
                events_attested = len(self.lacey.node.log)
                self._save_state()
            claim = {
                "nodeId": self.node_id,
                "seq": mission_idx,
                "missionIdx": mission_idx,
                "desyncEnd": None,  # no desync meter in this process
                "eventsAttested": events_attested,
                "sig": self._sign_claim(mission_idx, events_attested),
            }
            sampled = self.wired.attest_standard(mission_idx)
            if not sampled:
                local_only += 1
                self._log_unsampled(claim)
                continue
            try:
                ack = self._send_and_wait(
                    {"type": "attest", "attestation": claim},
                    "attest_ack", timeout,
                    match=lambda m, midx=mission_idx: (
                        m.get("missionIdx") == midx
                        and m.get("seq") == midx))
            except (ConnectionClosed, OSError):
                with self._lock:
                    self.attest_unsent += 1
                self.log("MEASURED",
                         f"attestation {mission_idx} unsent: registry "
                         "unreachable (counted, not claimed verified)")
                continue
            sent += 1
            if ack is not None and ack.get("ok"):
                acked += 1
                with self._lock:
                    self.tpirg_test = ack.get("tpirg", self.tpirg_test)
        for _ in range(int(time_critical)):
            with self._lock:
                mission_idx = self.next_mission_idx
                self.next_mission_idx += 1
                events_attested = len(self.lacey.node.log)
                self._save_state()
            claim = {
                "nodeId": self.node_id,
                "seq": mission_idx,
                "missionIdx": mission_idx,
                "desyncEnd": None,
                "eventsAttested": events_attested,
                "sig": self._sign_claim(mission_idx, events_attested),
                "kind": "time-critical",
            }
            self.wired.attest_time_critical(mission_idx)
            try:
                ack = self._send_and_wait(
                    {"type": "attest", "attestation": claim},
                    "attest_ack", timeout,
                    match=lambda m, midx=mission_idx: (
                        m.get("missionIdx") == midx
                        and m.get("seq") == midx))
            except (ConnectionClosed, OSError):
                with self._lock:
                    self.attest_unsent += 1
                continue
            tc_sent += 1
            if ack is not None and ack.get("ok"):
                acked += 1
                with self._lock:
                    self.tpirg_test = ack.get("tpirg", self.tpirg_test)
        with self._lock:
            self.attest_sent += sent + tc_sent
            self.attest_acked += acked
            self.attest_local_only += local_only
            self.time_critical_sent += tc_sent
        self.log("MEASURED",
                 f"attest batch: standard sent={sent} "
                 f"local-only(unsampled)={local_only}; "
                 f"time-critical sent={tc_sent}; acked total={acked}")
        return {"sent": sent + tc_sent, "acked": acked,
                "local_only": local_only, "time_critical_sent": tc_sent}

    def pattern_c_run(self, mode, prompt):
        """One Pattern C job through the STUB draft/verifier.

        The local loopback WebSocket stands in for the Wi-Fi link
        in this test, so the job is routed as wifi and the log says
        so (SIMULATED). The draft and verifier are STUBs with fixed
        toy values — no real model exists behind them.
        """
        self.log("SIMULATED",
                 "Pattern C transport=wifi: local loopback WebSocket "
                 "stands in for the Wi-Fi link in this test; no radio "
                 "measurement exists")
        if mode == "infer":
            draft, verify = _stub_draft_infer, _stub_verify_infer
        elif mode == "classify":
            draft, verify = _stub_draft_classify, _stub_verify_classify
        else:
            raise ValueError("mode must be 'infer' or 'classify'")
        result = route_inference(self.lacey, self.pattern_c, prompt,
                                 mode, draft, verify, "wifi")
        with self._lock:
            self.pattern_c_runs += 1
            self.pattern_c_paths[result["path"]] = (
                self.pattern_c_paths.get(result["path"], 0) + 1)
        self.log("STUB",
                 f"Pattern C {mode}: path={result['path']} "
                 "(STUB draft/verifier — fixed toy tokens, no real "
                 "model; acceptance counted from this run only)")
        return result

    def manifest(self):
        with self._lock:
            return self.lacey.node.batch_manifest()

    def reconcile(self, manifests, public_keys):
        """Merge another node's manifests; returns Lacey's report."""
        keys = {}
        for node_id, key_hex in public_keys.items():
            try:
                keys[node_id] = bytes.fromhex(key_hex)
            except ValueError:
                raise ValueError(
                    f"public key for {node_id!r} is not hex")
        lines = self.lacey.reconcile_cluster(manifests, keys)
        for line in lines:
            self.log("MEASURED", f"reconcile: {line}")
        return lines

    # -- fog envelope link (Step 4) ---------------------------------------
    # A second WebSocket to a parked relay, envelopes only. The
    # first frame on the socket is the announce envelope, which
    # puts the socket into the relay's envelope mode: no registry
    # pairing exists on it, so registry downtime cannot kill it,
    # and its own death changes nothing about the registry session.
    def _fog_announce(self):
        return {
            "relay": "v1", "to": "relay", "from": self.node_id,
            "ttl": 1, "hop": 0,
            "payload": json.dumps(
                {"type": "announce", "node": self.node_id}),
        }

    def _fog_loop(self):
        backoff = 1.0
        while not self._shutdown.is_set():
            try:
                ws = WebSocketClient(
                    self.fog_relay_url, ssl_context=self._ssl_context)
                ws.connect()
            except Exception as exc:
                self.log("MEASURED",
                         f"fog link connect failed: {exc}; retry in "
                         f"{backoff:.0f}s (registry session "
                         "unaffected)")
                self._shutdown.wait(backoff)
                backoff = min(backoff * 2, 10.0)
                continue
            with self._lock:
                self._fog_ws = ws
                self.fog_connected = True
            backoff = 1.0
            try:
                ws.send_text(json.dumps(self._fog_announce()))
                self.log("MEASURED",
                         f"fog link connected to relay "
                         f"{self.fog_relay_url}; announce sent "
                         "(envelope mode; no registry in this path)")
                while not self._shutdown.is_set():
                    try:
                        text = ws.recv_text(timeout=1.0)
                    except TimeoutError:
                        continue
                    self._on_fog_frame(text)
            except (ConnectionClosed, OSError, ValueError) as exc:
                if not self._shutdown.is_set():
                    self.log("MEASURED",
                             f"fog link lost: {exc}; reconnecting "
                             "(registry session unaffected)")
            finally:
                with self._lock:
                    if self._fog_ws is ws:
                        self._fog_ws = None
                    self.fog_connected = False
                try:
                    ws.close()
                except Exception:
                    pass
            self._shutdown.wait(backoff)
            backoff = min(backoff * 2, 10.0)

    def _on_fog_frame(self, text):
        try:
            env = json.loads(text)
        except json.JSONDecodeError:
            self.log("MEASURED", "fog link sent a non-JSON frame; ignored")
            return
        if (not isinstance(env, dict) or env.get("relay") != "v1"
                or not isinstance(env.get("payload"), str)):
            self.log("MEASURED",
                     "fog link sent a non-envelope frame; ignored")
            return
        try:
            payload = json.loads(env["payload"])
        except json.JSONDecodeError:
            self.log("MEASURED",
                     "fog envelope payload is not JSON; ignored")
            return
        if not isinstance(payload, dict):
            return
        if payload.get("type") == "manifest":
            self._on_fog_manifest(env, payload)
        else:
            self.log("MEASURED",
                     f"fog envelope with payload type "
                     f"{payload.get('type')!r}; ignored")

    def _on_fog_manifest(self, env, payload):
        sender = payload.get("from") or env.get("from")
        manifests = payload.get("manifests")
        if not isinstance(manifests, list):
            self.log("MEASURED",
                     "fog manifest envelope has no manifests list; "
                     "ignored")
            return
        with self._lock:
            self.fog_received += 1
        if sender not in self.peer_keys:
            # Keys come ONLY from explicit --peer-key config. An
            # envelope that carries its own key proves nothing and
            # is never trusted.
            with self._lock:
                self.fog_rejected_untrusted += 1
                self.fog_last_reconcile = {
                    "peer": sender, "outcome": "rejected-untrusted",
                    "at": _now_iso()}
            self.log("MEASURED",
                     f"fog manifest rejected-untrusted: sender "
                     f"{sender!r} has no configured --peer-key; NOT "
                     "reconciled (envelope-supplied keys are never "
                     "trusted; key distribution is a future step)")
            return
        lines = self.reconcile(manifests, dict(self.peer_keys))
        with self._lock:
            self.fog_last_reconcile = {
                "peer": sender, "outcome": "reconciled",
                "report": lines, "at": _now_iso()}

    def send_manifest(self, to_node):
        """Send this node's manifest batches to a peer node id as
        ONE fog envelope. Returns what was sent."""
        with self._lock:
            ws = self._fog_ws
            connected = self.fog_connected
        if ws is None or not connected:
            self.log("MEASURED",
                     f"fog send-manifest to {to_node}: fog link is "
                     "down; nothing sent")
            return {"to": to_node, "batches": 0, "envelopes": 0,
                    "sent": False, "reason": "fog link down"}
        manifests = self.manifest()
        envelope = {
            "relay": "v1", "to": to_node, "from": self.node_id,
            "ttl": 5, "hop": 0,
            "payload": json.dumps({
                "type": "manifest", "from": self.node_id,
                "manifests": manifests}),
        }
        # Step 6: with --onion-relays, wrap the envelope's payload
        # in an onion over the configured relay path and send the
        # onion frame to the first relay instead of the plain
        # envelope. Any failure (a path relay's /onion-key fetch,
        # the wrap itself) falls back to the plain envelope, and
        # the fallback is logged — never silent, never fatal.
        frame = envelope
        onion_path_ids = None
        if self.onion_relays:
            try:
                path = []
                for relay_url in self.onion_relays:
                    info = onion_py.fetch_onion_key(
                        relay_url, ssl_context=self._ssl_context)
                    path.append((info["relayId"], info["onionPub"]))
                blob = onion_py.build_onion(
                    envelope["payload"], to_node, path)
                frame = {"relay": "v1", "type": "onion", "blob": blob,
                         "ttl": 5, "hop": 0}
                onion_path_ids = [relay_id for relay_id, _ in path]
            except Exception as exc:
                with self._lock:
                    self.onion_fallbacks += 1
                self.log("MEASURED",
                         f"fog send-manifest to {to_node}: onion "
                         f"path unavailable ({exc}); falling back "
                         "to the plain envelope")
                frame = envelope
                onion_path_ids = None
        try:
            ws.send_text(json.dumps(frame))
        except (ConnectionClosed, OSError) as exc:
            self.log("MEASURED",
                     f"fog send-manifest to {to_node} failed: {exc}")
            return {"to": to_node, "batches": 0, "envelopes": 0,
                    "sent": False, "reason": str(exc)}
        with self._lock:
            self.fog_sent += 1
            if onion_path_ids is not None:
                self.onion_sent += 1
        if onion_path_ids is not None:
            self.log("MEASURED",
                     f"fog send-manifest to {to_node}: "
                     f"{len(manifests)} manifest batch(es) "
                     "onion-wrapped over "
                     f"{len(onion_path_ids)} relay(s) "
                     f"[{', '.join(onion_path_ids)}] and sent to "
                     "the first relay over the fog link")
            return {"to": to_node, "batches": len(manifests),
                    "envelopes": 1, "sent": True, "onion": True,
                    "path": onion_path_ids}
        self.log("MEASURED",
                 f"fog send-manifest to {to_node}: "
                 f"{len(manifests)} manifest batch(es) in 1 envelope "
                 "over the fog link")
        return {"to": to_node, "batches": len(manifests),
                "envelopes": 1, "sent": True}

    # -- status -----------------------------------------------------------
    def status(self):
        with self._lock:
            lacey_status = self.lacey.status()
        return {
            "node": self.node_id,
            "version": VERSION,
            "mode": self.lacey.mode,
            "core_connected": self.lacey.core_connected,
            "missed_heartbeats": self.lacey.missed_heartbeats,
            "registry_url": self.registry_url,
            "registry_kind": self.registry_kind,
            "peers": self.peers,
            "session_id": self.session_id,
            "identity_file": (str(self._identity_file)
                              if self._identity_file else None),
            "rotation_pending": bool(
                self._identity
                and self._identity.get("rotation_pending")),
            "public_key_hex": self.lacey.node.pk.hex(),
            "uptime_seconds": round(time.monotonic() - self._start_mono, 1),
            "events_emitted": self.events_emitted,
            "log_events": len(self.lacey.node.log),
            # O1 verifier health (hybrid v0.3.0): how many times the
            # full-rebuild verifier ran, how many divergences it
            # caught (each self-healed by keeping the rebuilt state),
            # and the last check's outcome. Read-only surfacing;
            # merge/auth behavior is untouched.
            "verifier": {
                "runs": self.lacey.node._verify_runs,
                "failures": self.lacey.node._verify_failures,
                "last": (dict(self.lacey.node._last_verify)
                         if self.lacey.node._last_verify is not None
                         else None),
                "applies_since_verify":
                    self.lacey.node._applies_since_verify,
            },
            "counters": lacey_status["state"].get("counters", {}),
            "positions": lacey_status["state"].get("positions", {}),
            "frozen_unique": lacey_status["state"].get("frozen_unique", []),
            "sampling": {
                "mode": SAMPLING_MODE,
                "standard_rate": APPROVED_RATE,
                "time_critical_rate": TIME_CRITICAL_RATE,
                "seed_source": self.wired.seed_source,
                "observed_rate": self.wired.observed_rate(),
            },
            "pattern_c": {
                "runs": self.pattern_c_runs,
                "paths": dict(self.pattern_c_paths),
                "acceptance_rate": self.pattern_c.acceptance_rate(),
                "engine": "STUB draft/verifier — no real model",
            },
            "tasks": {
                "solved": self.tasks_solved,
                "nonces_tried": self.nonces_tried,
                "tpirg_test": self.tpirg_test,
            },
            "attestations": {
                "sent": self.attest_sent,
                "acked": self.attest_acked,
                "local_only_unsampled": self.attest_local_only,
                "unsent_registry_unreachable": self.attest_unsent,
                "time_critical_sent": self.time_critical_sent,
                "state_file": str(self._state_file),
                "local_log": str(self._attest_log_path()),
            },
            "fog": {
                "relay_url": self.fog_relay_url,
                "connected": self.fog_connected,
                "sent_envelopes": self.fog_sent,
                "received_envelopes": self.fog_received,
                "rejected_untrusted": self.fog_rejected_untrusted,
                "peer_keys_configured": sorted(self.peer_keys),
                "fog_peer": (self.fog_last_reconcile or {}).get("peer"),
                "fog_last_reconcile": self.fog_last_reconcile,
                "onion_relays": list(self.onion_relays),
                "onion_sent": self.onion_sent,
                "onion_fallbacks": self.onion_fallbacks,
            },
            "radio_transport": (
                "unknown — no measurement; this process uses a local "
                "WebSocket, not BLE / Wi-Fi Aware / Wi-Fi Direct"
            ),
            "lacey_report": list(self.lacey.report_lines[-20:]),
        }

    # -- main loop ----------------------------------------------------------
    def run(self):
        self.log("MEASURED",
                 f"node starting: id={self.node_id} version={VERSION} "
                 f"registry={self.registry_url} "
                 f"({self.registry_kind})")
        self.log("MEASURED",
                 "sampling: 10% random per-index, seeded "
                 f"(seed source: {self.wired.seed_source}); "
                 "time-critical always 100%")
        self.log("MEASURED",
                 "Pattern C: STUB draft/verifier only — no real model")
        self.log("MEASURED",
                 "radio transport: unknown — no measurement")
        if self.fog_relay_url:
            self._fog_thread = threading.Thread(
                target=self._fog_loop, daemon=True)
            self._fog_thread.start()
            self.log("MEASURED",
                     f"fog envelope link enabled: relay="
                     f"{self.fog_relay_url}; peer keys configured "
                     f"for {sorted(self.peer_keys) or 'none'}")
            if self.onion_relays:
                self.log("MEASURED",
                         "onion manifest sends enabled (Step 6): "
                         f"path relays in order: "
                         f"{self.onion_relays}; plain-envelope "
                         "fallback on any key-fetch failure")
        while not self._shutdown.is_set():
            if not self.connected:
                try:
                    self.connect()
                except Exception as exc:
                    wait = self._next_backoff
                    # A live session holding this id (session-active)
                    # or a takeover (close code 4000) means another
                    # process with this key is alive: back off at
                    # least 10 s instead of hammering the registry.
                    if (isinstance(exc, SessionActiveError)
                            or self._session_takeover):
                        wait = max(wait, 10.0)
                        self._session_takeover = False
                    self.log("MEASURED",
                             f"registry connect failed: {exc}; "
                             f"retry in {wait:.0f}s "
                             "(acting locally in autonomous mode)")
                    self._missed_beat()
                    self._shutdown.wait(wait)
                    self._next_backoff = min(self._next_backoff * 2, 10.0)
                    continue
            # Connected: heartbeat cadence + missed-beat detection.
            now = time.monotonic()
            if now - self._last_hb_sent >= self.heartbeat_interval:
                if self._awaiting_ack:
                    self._missed_beat()
                if self.connected:
                    try:
                        self._send({"type": "heartbeat"})
                        self._awaiting_ack = True
                        self._last_hb_sent = now
                    except (ConnectionClosed, OSError):
                        with self._lock:
                            self.connected = False
            self._shutdown.wait(0.1)
        self.log("MEASURED", "node stopping")
        self._close_ws()
        self._close_fog()

    def _missed_beat(self):
        before = self.lacey.mode
        mode = self.lacey.heartbeat(False, self.missed_threshold)
        if mode == "autonomous" and before != "autonomous":
            self.log("MEASURED",
                     f"severance declared after "
                     f"{self.lacey.missed_heartbeats} missed "
                     "heartbeats; all new receipts provisional")

    def _close_ws(self):
        if self._ws is not None:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None
        with self._lock:
            self.connected = False

    def _close_fog(self):
        ws = self._fog_ws
        if ws is not None:
            try:
                ws.close()
            except Exception:
                pass
            self._fog_ws = None
        with self._lock:
            self.fog_connected = False

    def stop(self):
        self._shutdown.set()
        self._close_fog()


def _make_handler(node):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def _json(self, code, obj):
            body = json.dumps(obj).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _read_json(self):
            length = int(self.headers.get("Content-Length") or 0)
            if not length:
                return {}
            return json.loads(self.rfile.read(length) or b"{}")

        def do_GET(self):
            try:
                if self.path == "/status":
                    self._json(200, node.status())
                elif self.path == "/health":
                    self._json(200, {"ok": True, "mode": node.lacey.mode,
                                     "node": node.node_id})
                elif self.path == "/manifest":
                    self._json(200, {"manifests": node.manifest()})
                else:
                    self._json(404, {"ok": False, "reason": "not-found"})
            except Exception as exc:
                self._json(500, {"ok": False, "reason": str(exc)})

        def do_POST(self):
            try:
                body = self._read_json()
                if self.path == "/act":
                    ev = node.emit_event(body["op"], body["key"],
                                         body.get("payload"))
                    self._json(200, {"ok": True,
                                     "event_id": ev.event_id})
                elif self.path == "/pattern-c":
                    result = node.pattern_c_run(
                        body.get("mode", "classify"),
                        body.get("prompt", ""))
                    self._json(200, {"ok": True, "result": result})
                elif self.path == "/attest-batch":
                    summary = node.attest_batch(
                        body.get("count", 0),
                        body.get("time_critical", 0))
                    self._json(200, {"ok": True, "summary": summary})
                elif self.path == "/request-task":
                    result = node.request_task()
                    self._json(200, {"ok": True, "result": result})
                elif self.path == "/rotate-key":
                    result = node.rotate_key()
                    self._json(200, {"ok": result.get("ok", False),
                                     "result": result})
                elif self.path == "/reconcile":
                    lines = node.reconcile(
                        body.get("manifests", []),
                        body.get("public_keys", {}))
                    self._json(200, {"ok": True, "report": lines})
                elif self.path == "/send-manifest":
                    result = node.send_manifest(body["to"])
                    self._json(200, {"ok": True, "result": result})
                else:
                    self._json(404, {"ok": False, "reason": "not-found"})
            except ValueError as exc:
                # A malformed request body or payload (for example a
                # bad op or payload type on /act) is a client error,
                # not a server crash: 400, not 500.
                self._json(400, {"ok": False, "reason": str(exc)})
            except Exception as exc:
                self._json(500, {"ok": False, "reason": str(exc)})

    return Handler


def main():
    parser = argparse.ArgumentParser(
        description="Runnable in-between node: Lacey on a node.")
    parser.add_argument("--node-id", required=True)
    parser.add_argument("--registry", default="ws://127.0.0.1:8787")
    parser.add_argument("--status-port", type=int, required=True)
    parser.add_argument("--seed", default=None,
                        help="attestation seed (test seed for local "
                        "runs); or set LACEY_ATTEST_SEED")
    parser.add_argument("--seed-file", default=None,
                        help="file holding the attestation seed (keeps "
                        "it out of the command line and shell history); "
                        "or set LACEY_ATTEST_SEED_FILE")
    parser.add_argument("--state-file", default=None,
                        help="where to persist next_mission_idx "
                        "(default node-state-<node-id>.json in the "
                        "working directory)")
    parser.add_argument("--registry-ca-file", default=None,
                        help="CA certificate file trusting a TLS "
                        "registry (for a self-signed test registry); "
                        "without it, wss:// verifies against the "
                        "system trust store")
    parser.add_argument("--identity-file", default=None,
                        help="identity file holding this node's "
                        "Ed25519 keypair (design §7); or set "
                        "LACEY_IDENTITY_FILE. The file's node_id must "
                        "equal --node-id. Without it, the node signs "
                        "with a fresh ephemeral key.")
    parser.add_argument("--heartbeat-interval", type=float, default=5.0)
    parser.add_argument("--missed-threshold", type=int, default=3)
    parser.add_argument("--log-file", default=None)
    parser.add_argument("--fog-relay", default=None,
                        help="parked relay URL for the fog envelope "
                        "link (Step 4): a second WebSocket used only "
                        "for node-to-node manifest envelopes. Without "
                        "it, the node behaves exactly as before. A "
                        "wss:// fog relay verifies against the same "
                        "CA as --registry-ca-file.")
    parser.add_argument("--peer-key", action="append", default=[],
                        metavar="NODEID=PUBKEYHEX",
                        help="public key of a fog peer whose manifest "
                        "envelopes this node will reconcile; "
                        "repeatable. Keys come only from this "
                        "explicit config — a key carried inside an "
                        "envelope is never trusted.")
    parser.add_argument("--onion-relays", default=None,
                        metavar="WSURL[,WSURL...]",
                        help="comma-separated parked relay URLs, in "
                        "path order (Step 6; only meaningful with "
                        "--fog-relay): /send-manifest wraps the "
                        "manifest in an onion over these relays "
                        "(their /onion-key endpoints are fetched at "
                        "send time) and sends it to the first relay "
                        "over the fog link. If any key fetch fails, "
                        "the node falls back to the plain envelope "
                        "and logs the fallback. Without this flag, "
                        "behavior is exactly as before.")
    args = parser.parse_args()

    onion_relays = []
    if args.onion_relays:
        onion_relays = [u.strip() for u in
                        args.onion_relays.split(",") if u.strip()]

    peer_keys = {}
    for item in args.peer_key:
        if "=" not in item:
            parser.error(
                f"--peer-key must be NODEID=PUBKEYHEX, got {item!r}")
        _nid, _hex = item.split("=", 1)
        peer_keys[_nid.strip()] = _hex.strip()

    ssl_context = None
    if args.registry_ca_file:
        ssl_context = ssl.create_default_context(
            cafile=args.registry_ca_file)

    node = MeshNode(
        node_id=args.node_id,
        registry_url=args.registry,
        seed=args.seed,
        seed_file=args.seed_file,
        state_file=args.state_file,
        ssl_context=ssl_context,
        identity_file=(args.identity_file
                       or os.environ.get("LACEY_IDENTITY_FILE")),
        status_port=args.status_port,
        heartbeat_interval=args.heartbeat_interval,
        missed_threshold=args.missed_threshold,
        log_file=args.log_file,
        fog_relay_url=args.fog_relay,
        peer_keys=peer_keys,
        onion_relays=onion_relays,
    )
    server = ThreadingHTTPServer(
        ("127.0.0.1", args.status_port), _make_handler(node))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    node.log("MEASURED",
             f"status endpoint: http://127.0.0.1:{args.status_port}/status")

    def _stop(signum, frame):
        node.stop()

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)
    try:
        node.run()
    finally:
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
