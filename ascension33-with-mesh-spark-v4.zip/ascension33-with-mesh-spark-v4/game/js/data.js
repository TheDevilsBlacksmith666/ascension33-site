'use strict';
/* ================= ASCENSION33 — DATA =================
   Book 1: The Desync. Missions, story, boons, techniques. */

const ENEMIES = {
  drone:     { name:'Sentinel Drone',  hp:20, dmg:[4,7],   moveQ:4, actQ:6 },
  construct: { name:'Training Construct', hp:16, dmg:[3,5], moveQ:4, actQ:6 },
  enforcer:  { name:'Arbiter Enforcer', hp:36, dmg:[6,9],   moveQ:5, actQ:7, suppress:true },
  elite:     { name:'Arbiter Elite',   hp:58, dmg:[8,12],   moveQ:6, actQ:8, pulse:true },
  prime:     { name:'Arbiter Prime',   hp:140,dmg:[9,12],   moveQ:5, actQ:7, boss:true },
};

const TECHNIQUES = {
  flow:  { name:'Kinetic Flow',   q:8,  desync:6,  desc:'Spinning strike: 7 damage to ALL 8 adjacent cells.' },
  guard: { name:'Ninefold Guard', q:3,  desync:2,  desc:'Take 60% less damage until your next turn.' },
  rend:  { name:'Temporal Rend',  q:10, desync:12, desc:'22 damage to one adjacent cell.' },
  phase: { name:'Phase Step',     q:6,  desync:6,  desc:'Teleport to any free mark on the stage.' },
};
const TECH_ORDER = ['flow','guard','rend','phase'];

const BOONS = [
  { id:'hp',     name:'Vital Surge',    desc:'+30 max HP, and heal 30 now.' },
  { id:'anchor', name:'Anchor Cell',    desc:'+1 Ru\u2019ya Anchor charge (max 5).' },
  { id:'qedge',  name:'Q-Time Edge',    desc:'All your Q costs reduced by 1 (min 2).', once:true },
  { id:'ward',   name:'Desync Ward',    desc:'All desync gained reduced by 30%.', once:true },
  { id:'tech',   name:'New Technique',  desc:'Learn an unlearned Kha\u2019zari technique.', tech:true },
  { id:'vesper', name:'Vesper\u2019s Bond', desc:'Vesper gains +20 max HP and +3 damage.' },
];

/* missions: x = column 0..2 (left..right), y = row 0..2 (top..bottom) */
const MISSIONS = [
  {
    name:'M1 \u2014 SIGNAL LOST',
    cine:'mission',
    tip:'Click Kael, choose STRIKE, then click a glowing enemy. Move with MOVE.',
    story:[
      'Kael runs the Tailscale \u2014 off-grid courier routes through the Glove\u2019s undermesh. Tonight\u2019s delivery is routine.',
      'Then the sky stutters. His manifest dissolves into static, his hands leave afterimages, and the city mesh flags him with a single word: ANOMALY.',
      'Two Sentinel Drones detach from a lamppost and come looking. Run the grid, Kael. Run it like you mean it.'
    ],
    kael:{x:0,y:1}, vesper:false,
    enemies:[{t:'drone',x:2,y:0},{t:'drone',x:2,y:2}], nodes:[], waves:[]
  },
  {
    name:'M2 \u2014 HEMORRHAGE',
    cine:'desync',
    tip:'Watch the DESYNC meter. Strikes and heavy hits raise it. Your Ru\u2019ya Anchor (1 charge) resets it to zero.',
    story:[
      'The desync is getting worse. Time hiccups. His reflection moves half a second late.',
      'A dead runner\u2019s cache yields a Ru\u2019ya Anchor \u2014 a device that pins consciousness to the moment. It has one charge. Make it count.',
      'The Arbiters are already scanning for him. Three drones close in.'
    ],
    kael:{x:0,y:1}, vesper:false,
    enemies:[{t:'drone',x:2,y:0},{t:'drone',x:2,y:1},{t:'drone',x:2,y:2}], nodes:[], waves:[]
  },
  {
    name:'M3 \u2014 THE NINE',
    cine:'combat',
    tip:'Try STANCES: IRON (take less, deal less), EMBER (deal more, take more), FLOW (cheap moves + combo chains on one target).',
    story:[
      'In a derelict dojo beneath the transit lines, Kael finds the Kha\u2019zari manual \u2014 a left-handed somatic combat matrix mapped across nine grid cells.',
      'Direction is intent. Stance is survival. The manual\u2019s training constructs boot up, patient as gravity.',
      'He drills until the grid is muscle memory.'
    ],
    kael:{x:0,y:1}, vesper:false,
    enemies:[{t:'construct',x:2,y:0},{t:'construct',x:2,y:1},{t:'construct',x:2,y:2}], nodes:[], waves:[]
  },
  {
    name:'M4 \u2014 ENFORCEMENT',
    cine:'combat',
    tip:'The turn bar shows Q-Time order \u2014 lowest Q acts first. Every action costs Q. Surges strike every 33 Q.',
    story:[
      'First contact. An Arbiter enforcement team corners him in a drainage culvert \u2014 two Enforcers and a drone.',
      'They move on Base-33 Q-Time, the same tick-system the whole mesh runs on. He can see their rhythm now.',
      'He can break it.'
    ],
    kael:{x:0,y:1}, vesper:false,
    enemies:[{t:'enforcer',x:2,y:0},{t:'drone',x:2,y:1},{t:'enforcer',x:2,y:2}], nodes:[], waves:[]
  },
  {
    name:'M5 \u2014 VESPER',
    cine:'desync',
    tip:'Vesper fights beside you (AI-controlled). She can STABILIZE you (\u221225 desync) when you hemorrhage.',
    story:[
      'She finds him between ticks \u2014 Vesper, a rogue mesh-diver who cut her own tether years ago.',
      '\u2018You leak time everywhere you go,\u2019 she says. \u2018Stay close to me, or you\u2019ll bleed out before the war starts.\u2019',
      'An enforcement team moves in. Time to show her what the Nine taught him.'
    ],
    kael:{x:0,y:2}, vesper:true, vesperPos:{x:0,y:0},
    enemies:[{t:'enforcer',x:2,y:0},{t:'enforcer',x:2,y:1},{t:'enforcer',x:2,y:2}], nodes:[], waves:[]
  },
  {
    name:'M6 \u2014 NODE SEVEN',
    cine:'mission',
    tip:'Destroy the CITY MESH NODE (it pulses 5 damage every 33 Q). Expect reinforcements when it starts to crack.',
    story:[
      'The plan: dismantle city mesh node seven, the relay keeping Sector 9 compliant. Break the node, break the signal.',
      'The Arbiters know. They\u2019re waiting.',
      'Vesper rigs the approach. Kael goes in loud.'
    ],
    kael:{x:0,y:1}, vesper:true, vesperPos:{x:0,y:0},
    enemies:[{t:'enforcer',x:2,y:0},{t:'enforcer',x:2,y:1}],
    nodes:[{x:1,y:2,hp:50}],
    waves:[
      {trigger:'nodeHalf', spawn:[{t:'drone',x:2,y:2}]},
      {trigger:'nodeDown', spawn:[{t:'drone',x:2,y:2}]}
    ]
  },
  {
    name:'M7 \u2014 WRATH',
    cine:'combat',
    tip:'Elites pulse AoE damage every 3rd action. Spread out, use IRON stance, and focus them down.',
    story:[
      'The mesh answers with an elite hunter cadre. No warnings. No demands.',
      'Just deletion orders.'
    ],
    kael:{x:0,y:1}, vesper:true, vesperPos:{x:0,y:0},
    enemies:[{t:'elite',x:2,y:0},{t:'enforcer',x:1,y:1},{t:'enforcer',x:2,y:1},{t:'elite',x:2,y:2}],
    nodes:[], waves:[]
  },
  {
    name:'M8 \u2014 NODE THIRTEEN',
    cine:'mission',
    tip:'Node thirteen is hardened (65 HP). Crack it fast \u2014 its 33-Q pulse punishes anyone standing adjacent.',
    story:[
      'Node thirteen is hardened \u2014 shielded relays, heavier guard. Vesper rigs the approach through a maintenance duct.',
      'One more node down and the sector grid starts to starve.',
      'The mesh has learned his rhythm. Change it.'
    ],
    kael:{x:0,y:1}, vesper:true, vesperPos:{x:0,y:0},
    enemies:[{t:'enforcer',x:2,y:0},{t:'elite',x:2,y:2},{t:'enforcer',x:2,y:1}],
    nodes:[{x:1,y:2,hp:65}],
    waves:[
      {trigger:'nodeHalf', spawn:[{t:'drone',x:1,y:0}]},
      {trigger:'nodeDown', spawn:[{t:'drone',x:0,y:2}]}
    ]
  },
  {
    name:'M9 \u2014 THE HUNTER',
    cine:'desync',
    tip:'The ARBITER PRIME slams (heavy damage + desync) and summons drones. Kill the drones first, then focus the Prime.',
    story:[
      'They sent the Prime. An Arbiter Prime doesn\u2019t enforce \u2014 it concludes.',
      'Kael has one advantage: the Prime still thinks he runs on mesh time.',
      'Vesper checks her anchor charges. \u2018Don\u2019t die,\u2019 she says. \u2018I\u2019m not carrying you out.\u2019'
    ],
    kael:{x:0,y:1}, vesper:true, vesperPos:{x:0,y:0},
    enemies:[{t:'prime',x:2,y:1,hp:150},{t:'drone',x:2,y:0},{t:'drone',x:2,y:2}],
    nodes:[], waves:[]
  },
  {
    name:'M10 \u2014 COLLAPSE',
    cine:'combat',
    tip:'Two nodes, the Prime, and everything the sector has left. Destroy the nodes, survive the Prime. End it.',
    story:[
      'Two nodes. The Prime. Everything the sector has left.',
      'Kael and Vesper walk into the teeth of the mesh to tear it out by the roots.',
      'If the grid falls tonight, the Glove starts to wake up.'
    ],
    kael:{x:0,y:2}, vesper:true, vesperPos:{x:0,y:0},
    enemies:[{t:'prime',x:2,y:1,hp:140},{t:'enforcer',x:2,y:0}],
    nodes:[{x:1,y:0,hp:45},{x:1,y:2,hp:45}],
    waves:[
      {trigger:'nodeDown', spawn:[{t:'drone',x:1,y:1}]}
    ]
  }
];

const ENDING = [
  'The sector mesh collapses in a cascade of dead static.',
  'Across the Glove, a million sleepers dream the same dream for the first time: a door, opening.',
  'BOOK 1 COMPLETE \u2014 the Desync has begun. The war for the Spire awaits in Book 2: PIRGITORI.'
];

const HOWTO = [
  ['THE STAGE','You are Kael, live in the scene. Click Kael, pick an action, then click a glowing mark. Enemies act on their own.'],
  ['MOVE (2\u20134Q)','Step to an adjacent mark (8 directions).'],
  ['STRIKE (6Q)','Hit an adjacent enemy. In FLOW stance, consecutive strikes on the same target chain combos (+25% each, up to 3 stacks).'],
  ['STANCES (3Q)','IRON: take 40% less, deal 25% less. EMBER: deal 30% more, take 20% more. FLOW: cheap moves (2Q) + combo chains.'],
  ['TECHNIQUES','Unlocked via boons between missions. Powerful \u2014 but they raise DESYNC fast.'],
  ['Q-TIME','Lowest Q acts first. Every action costs Q. The turn bar shows who moves next.'],
  ['DESYNC (0\u2013100)','Rises when you strike (+2), use techniques, or take heavy hits (+6). At 40+: your attacks can GLITCH off-target. At 70+: heavy distortion. At 100: DELETION EVENT \u2014 dropped to 1 HP, desync reset to 50.'],
  ['RU\u2019YA ANCHOR','Resets desync to 0 and purges glitch marks. Limited charges \u2014 refilled each mission.'],
  ['MESH SURGES','Every 33 Q the mesh surges: nodes pulse damage, reality tears, time stutters.'],
  ['VICTORY','Destroy all enemies \u2014 and every city mesh node. If Kael falls, the run ends. Retry as needed.']
];
