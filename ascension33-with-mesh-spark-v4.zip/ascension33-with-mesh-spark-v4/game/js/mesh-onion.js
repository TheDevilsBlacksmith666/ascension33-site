/* =====================================================================
 * ASCENSION33 — MESH ONION (Step 6 browser port)
 * WebCrypto implementation of the Pirgitori onion layer, wire-
 * compatible with the relay reference implementation
 * (pirgitori-mesh/relay/onion.js) and the Python port
 * (in-between-node-v1/onion_py.py). The full spec is
 * pirgitori-mesh/relay/PROTOCOL.md, "Onion routing (Step 6)":
 * P-256 ECDH per layer (fresh sender ephemeral keypair per
 * layer), HKDF-SHA256 (salt empty, info "pirgitori-onion-v1",
 * 32-byte key), AES-256-GCM (12-byte iv, 16-byte tag). Layer
 * JSON {v:1, eph, iv, tag, ct} with all binary as lowercase hex;
 * public keys are the raw uncompressed point (65 bytes,
 * 0x04||X||Y) hex — which is exactly WebCrypto's exportKey
 * ('raw') form for an ECDH P-256 public key. Layer plaintext is
 * {next, body}; the innermost body is {final:true, to, payload}.
 *
 * STATUS: WIRED (2026-11-18, Track B). index.html loads this
 * file before mesh.js, and mesh.js calls it in the fog-link
 * send path when ?relay= and ?onion= are set; with neither
 * set the client behaves exactly as before. Shipping still
 * happens via Edward-gated itch uploads (v7 build staged,
 * not uploaded).
 *
 * INTEGRATION POINT (when Edward ships a build that uses it):
 *   1. index.html: add <script src="js/mesh-onion.js"></script>
 *      BEFORE js/mesh.js.
 *   2. mesh.js: where the client sends a manifest envelope
 *      through a relay (the relay envelope send path), fetch
 *      each path relay's GET /onion-key ({relayId, onionPub}),
 *      build the path as [{relayId, onionPubHex}, ...] in
 *      entry -> exit order, then:
 *        var blob = await MeshOnion.buildOnion(
 *          { payload: envelopePayloadString, to: destNodeId,
 *            path: path });
 *        ws.send(JSON.stringify({ relay: 'v1', type: 'onion',
 *          blob: blob, ttl: 5, hop: 0 }));
 *      instead of sending the plain envelope. If any /onion-key
 *      fetch fails, fall back to the plain envelope (the same
 *      policy node.py --onion-relays uses).
 *
 * Exposes an async global `MeshOnion`:
 *   buildOnion({payload, to, path}) -> Promise<layer object>
 *   peelOnion(layer, privateKey)    -> Promise<{next, body}>
 *   generateOnionKeys()             -> Promise<{privateKey,
 *                                      publicKey, publicHex}>
 *   publicHexFromKey(publicKey)     -> Promise<hex>
 *   importPublicKey(pubHex)         -> Promise<CryptoKey>
 *   importPrivateKeyJwk(jwk)        -> Promise<CryptoKey>
 *   hexToBytes / bytesToHex / isOnionPubHex helpers.
 * No external dependencies, no build step.
 * ===================================================================== */
(function(global){
'use strict';

var ONION_HKDF_INFO = 'pirgitori-onion-v1';
var ONION_PUB_HEX_RE = /^[0-9a-f]{130}$/;

function subtle(){
  if(!global.crypto || !global.crypto.subtle){
    throw new Error('WebCrypto (crypto.subtle) is not available');
  }
  return global.crypto.subtle;
}
function utf8Encode(str){ return new TextEncoder().encode(str); }
function utf8Decode(buf){ return new TextDecoder().decode(buf); }
function hexToBytes(h){
  var b = new Uint8Array(h.length / 2);
  for(var i = 0; i < b.length; i++) b[i] = parseInt(h.substr(i * 2, 2), 16);
  return b;
}
function bytesToHex(b){
  var s = '';
  for(var i = 0; i < b.length; i++){
    var x = b[i].toString(16);
    s += (x.length < 2 ? '0' : '') + x;
  }
  return s;
}
function isOnionPubHex(s){
  return typeof s === 'string' && ONION_PUB_HEX_RE.test(s)
    && s.substr(0, 2) === '04';
}

/* ---------- key forms ---------- */
function importPublicKey(pubHex){
  if(!isOnionPubHex(pubHex)){
    return Promise.reject(new Error('invalid P-256 onion public key hex'));
  }
  return subtle().importKey('raw', hexToBytes(pubHex),
    { name: 'ECDH', namedCurve: 'P-256' }, false, []);
}
function publicHexFromKey(publicKey){
  return subtle().exportKey('raw', publicKey).then(function(raw){
    return bytesToHex(new Uint8Array(raw));
  });
}
function importPrivateKeyJwk(jwk){
  return subtle().importKey('jwk', jwk,
    { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
}
async function generateOnionKeys(){
  var kp = await subtle().generateKey(
    { name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  var publicHex = await publicHexFromKey(kp.publicKey);
  return { privateKey: kp.privateKey, publicKey: kp.publicKey,
           publicHex: publicHex };
}

/* ---------- HKDF-SHA256 (RFC 5869), done manually over HMAC ----------
 * salt = empty (zero bytes) is exactly a salt of 32 zero bytes:
 * HKDF defines an absent salt as HashLen zeros, and HMAC pads a
 * short key with zeros, so all three readings derive the same
 * key — this matches Node hkdfSync('sha256', secret,
 * Buffer.alloc(0), 'pirgitori-onion-v1', 32) and Python's
 * HKDF(salt=b"") bit-for-bit. */
function hmacSha256(keyBytes, dataBytes){
  return subtle().importKey('raw', keyBytes,
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
    .then(function(k){ return subtle().sign('HMAC', k, dataBytes); })
    .then(function(sig){ return new Uint8Array(sig); });
}
async function hkdfSha256(secretBytes, infoStr){
  var prk = await hmacSha256(new Uint8Array(32), secretBytes);
  var info = utf8Encode(infoStr);
  var data = new Uint8Array(info.length + 1);
  data.set(info, 0);
  data[info.length] = 1; // expand block 1: T(1) = HMAC(PRK, info || 0x01)
  return hmacSha256(prk, data); // 32 bytes — the full layer key
}

/* ---------- per-layer key derivation ---------- */
async function deriveLayerKey(myPrivateKey, peerPubHex){
  var pub = await importPublicKey(peerPubHex);
  var secret = await subtle().deriveBits(
    { name: 'ECDH', public: pub }, myPrivateKey, 256);
  var okm = await hkdfSha256(new Uint8Array(secret), ONION_HKDF_INFO);
  return subtle().importKey('raw', okm,
    { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

/* ---------- one layer ---------- */
async function encryptLayer(plaintextStr, recipientPubHex){
  var eph = await generateOnionKeys(); // fresh ephemeral per layer
  var key = await deriveLayerKey(eph.privateKey, recipientPubHex);
  var iv = global.crypto.getRandomValues(new Uint8Array(12));
  var ctBuf = await subtle().encrypt(
    { name: 'AES-GCM', iv: iv, tagLength: 128 }, key,
    utf8Encode(plaintextStr));
  var all = new Uint8Array(ctBuf); // WebCrypto appends the tag
  var ct = all.subarray(0, all.length - 16);
  var tag = all.subarray(all.length - 16);
  return { v: 1, eph: eph.publicHex, iv: bytesToHex(iv),
           tag: bytesToHex(tag), ct: bytesToHex(ct) };
}

/* buildOnion({payload, to, path}) -> Promise<outermost layer>.
 * path is [{relayId, onionPubHex}, ...] in entry -> exit order.
 * Mirrors onion.js buildOnion exactly. */
async function buildOnion(opts){
  var payload = opts && opts.payload;
  var to = opts && opts.to;
  var path = opts && opts.path;
  if(typeof payload !== 'string') throw new Error('payload must be a string');
  if(typeof to !== 'string' || !to){
    throw new Error('to must be a destination id string');
  }
  if(!Array.isArray(path) || path.length === 0){
    throw new Error('path must be a non-empty array of {relayId, onionPubHex}');
  }
  for(var j = 0; j < path.length; j++){
    if(!path[j] || typeof path[j].relayId !== 'string'
       || !isOnionPubHex(path[j].onionPubHex)){
      throw new Error('each path entry needs {relayId, onionPubHex}');
    }
  }
  var body = { final: true, to: to, payload: payload };
  var layer = null;
  for(var i = path.length - 1; i >= 0; i--){
    var next = (i === path.length - 1) ? to : path[i + 1].relayId;
    layer = await encryptLayer(
      JSON.stringify({ next: next, body: body }), path[i].onionPubHex);
    body = layer;
  }
  return layer;
}

/* peelOnion(layer, privateKey) -> Promise<{next, body}>.
 * Rejects on ANY failure: malformed layer, bad ephemeral key,
 * AES-GCM authentication failure (wrong key or tampered
 * ciphertext), non-JSON plaintext. */
async function peelOnion(layer, privateKey){
  if(!layer || typeof layer !== 'object' || Array.isArray(layer)
     || layer.v !== 1){
    throw new Error('not an onion layer');
  }
  if(!isOnionPubHex(layer.eph)){
    throw new Error('bad ephemeral key in onion layer');
  }
  if(typeof layer.iv !== 'string' || !/^[0-9a-f]{24}$/.test(layer.iv)){
    throw new Error('bad iv in onion layer');
  }
  if(typeof layer.tag !== 'string' || !/^[0-9a-f]{32}$/.test(layer.tag)){
    throw new Error('bad tag in onion layer');
  }
  if(typeof layer.ct !== 'string' || !/^[0-9a-f]*$/.test(layer.ct)
     || layer.ct.length % 2 !== 0){
    throw new Error('bad ciphertext in onion layer');
  }
  var key = await deriveLayerKey(privateKey, layer.eph);
  var ctBytes = hexToBytes(layer.ct);
  var tagBytes = hexToBytes(layer.tag);
  var combined = new Uint8Array(ctBytes.length + tagBytes.length);
  combined.set(ctBytes, 0);
  combined.set(tagBytes, ctBytes.length);
  var pt = await subtle().decrypt(
    { name: 'AES-GCM', iv: hexToBytes(layer.iv), tagLength: 128 },
    key, combined); // rejects on AEAD failure — by design
  return JSON.parse(utf8Decode(new Uint8Array(pt)));
}

global.MeshOnion = {
  buildOnion: buildOnion,
  peelOnion: peelOnion,
  generateOnionKeys: generateOnionKeys,
  publicHexFromKey: publicHexFromKey,
  importPublicKey: importPublicKey,
  importPrivateKeyJwk: importPrivateKeyJwk,
  isOnionPubHex: isOnionPubHex,
  hexToBytes: hexToBytes,
  bytesToHex: bytesToHex,
  ONION_HKDF_INFO: ONION_HKDF_INFO,
};

})(typeof window !== 'undefined' ? window : globalThis);
