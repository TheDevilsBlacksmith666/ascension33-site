#!/bin/sh
# Pirgitori relay — generic POSIX launcher (Linux, macOS, *BSD,
# any box with Node.js >= 18).
#
# Run it from a directory containing relay.js, onion.js,
# roster_tool.js and package.json (copy them from
# pirgitori-mesh/relay/, or run this script from that directory).
# It installs the one dependency (ws) if node_modules is missing,
# then execs the relay.
#
# Configuration is environment-driven — same variable names as
# the Docker entrypoint:
#   REGISTRY_URL     (required) ws:// or wss:// URL of the registry
#   PORT             listen port                     (default 8788)
#   PEER             space-separated bootstrap peer URLs; ONE is
#                    enough — auto-join learns the rest
#   ADVERTISE        this relay's public ws:// URL, if dialable
#   HOLD_SECONDS     store-and-forward hold          (relay default 600)
#   MAX_PEERS        peer-link capacity cap          (relay default 16)
#   MAX_CLIENTS      client capacity cap             (relay default 256)
#   IDENTITY_FILE    roster-mode relay key file
#   ROSTER_FILE      signed roster file
#   OPERATOR_PUBKEY  operator public key hex (with ROSTER_FILE)
#
# Example:
#   REGISTRY_URL=wss://registry.example/ \
#   PEER=ws://203.0.113.10:8788 \
#   ADVERTISE=ws://198.51.100.23:8788 \
#   ./start-relay.sh
set -eu

cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

if [ ! -f relay.js ]; then
  echo "start-relay: relay.js not found in $(pwd)" >&2
  echo "Copy relay.js, onion.js, roster_tool.js and package.json" >&2
  echo "from pirgitori-mesh/relay/ into this directory first." >&2
  exit 1
fi
if ! command -v node >/dev/null 2>&1; then
  echo "start-relay: node is not installed (need Node.js >= 18)" >&2
  exit 1
fi
if [ ! -d node_modules/ws ]; then
  echo "start-relay: installing dependencies (ws)..."
  npm install --omit=dev --no-audit --no-fund
fi
if [ -z "${REGISTRY_URL:-}" ]; then
  echo "start-relay: REGISTRY_URL is required (ws:// or wss:// URL of the registry)" >&2
  exit 2
fi

ARGS="--registry $REGISTRY_URL --port ${PORT:-8788}"
# PEER is a space-separated list; word splitting is intended.
for p in ${PEER:-}; do
  ARGS="$ARGS --peer $p"
done
[ -n "${ADVERTISE:-}" ]       && ARGS="$ARGS --advertise $ADVERTISE"
[ -n "${HOLD_SECONDS:-}" ]    && ARGS="$ARGS --hold-seconds $HOLD_SECONDS"
[ -n "${MAX_PEERS:-}" ]       && ARGS="$ARGS --max-peers $MAX_PEERS"
[ -n "${MAX_CLIENTS:-}" ]     && ARGS="$ARGS --max-clients $MAX_CLIENTS"
[ -n "${IDENTITY_FILE:-}" ]   && ARGS="$ARGS --identity-file $IDENTITY_FILE"
[ -n "${ROSTER_FILE:-}" ]     && ARGS="$ARGS --roster $ROSTER_FILE"
[ -n "${OPERATOR_PUBKEY:-}" ] && ARGS="$ARGS --operator-pubkey $OPERATOR_PUBKEY"

# $ARGS word splitting is intended: every value is a single
# whitespace-free token (URLs, numbers, hex, paths).
exec node relay.js $ARGS
