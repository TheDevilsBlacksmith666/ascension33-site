# The Lacey Mesh Spark

Every copy of Ascension33 carries a **spark**: the seed of the Pirgitori
mesh, folded into the game download. The objective, as published on
pirgitori.sbs: **your rig is the network.** Playing the game is what
builds and coordinates the world — the spark is how your copy takes
part.

## What the spark is

- `relay/` — the parked relay (relay.js v0.7.0): carries and routes
  signed envelopes between players' copies. Peering, gossip, synaptic
  routing weights, store-and-forward, roster verification, and onion
  routing are all in the one file, with onion.js beside it.
- `node/` — the in-between node (node.py + inbetween.py): the hybrid
  node that *creates* mesh state — sense, verify, attest, severance,
  reconcile — with signed Merkle manifests no relay can forge.

Relays carry; nodes create. That separation is the design, not a
detail.

## Light it (local / LAN, works today)

1. In `relay/`: `npm install` once, then `bash start-relay.sh`
   (or `node relay.js --port 8788`).
2. In `node/`: run a node per RUN-NODE.md, with `--fog-relay
   ws://127.0.0.1:8788` to speak through your relay.
3. Open the game (`game/index.html` served locally, or the live itch
   build) with `?relay=ws://127.0.0.1:8788&onion=1` — the game's mesh
   client wraps its manifests in onion layers through your relay.
   Without the parameters, the game plays exactly as it always has.

## World building & coordinating

- **World building:** nodes reconcile signed world-state manifests
  through the relays — what one copy builds, attested and verified,
  becomes part of the shared world every other copy can merge.
  Forged state is rejected whole (wrong key = zero applied; proven).
- **Coordinating:** relays gossip who is where and route by learned
  synaptic weights; the operator roster decides which relays are
  trusted for public play.

## Honest limits

- Internet-wide play needs one publicly reachable rendezvous relay
  (a bootstrap, not a home) — that deployment is a separate step,
  tracked by the project. LAN and single-machine meshes work now.
- The spark is dormant by default: nothing runs, phones home, or
  joins anything until you start it. Your keys are yours; the node
  refuses state signed by keys you did not configure.
