#!/usr/bin/env node
/*
 * Pirgitori parked relay — roster tool (Step 5).
 *
 * Operator-side tooling for the relay roster: the operator-signed
 * allowlist of relay public keys (design §4.5). This tool runs on
 * the OPERATOR's machine, never on a relay host. It creates:
 *
 *   - the operator keypair (the roster's trust root — whoever
 *     holds this private key decides which relays are legitimate;
 *     guard it like one),
 *   - relay identity keypairs (operator-provisioned; a relay
 *     booted with --identity-file keeps the same relay id across
 *     restarts, trading the default per-run ephemerality for
 *     roster Sybil resistance — that trade is inherent, see
 *     PROTOCOL.md),
 *   - the signed roster file relays verify at boot.
 *
 * Key files are SECRETS: JSON {pubkeyHex, privateKeyHex} written
 * with mode 0600, refused if the target already exists, and their
 * private halves are never printed. The roster itself is public
 * material (public keys + a signature) and is safe to distribute —
 * HOW it is distributed for a public deploy is still an open
 * decision; this prototype ships the signed file.
 *
 * Canonical signing bytes (shared with relay.js — keep the two
 * implementations identical): JSON.stringify of the roster object
 * WITHOUT the signature field, object keys sorted recursively,
 * compact separators, UTF-8. The signature is Ed25519 over those
 * bytes with the operator key.
 *
 * Usage:
 *   node roster_tool.js operator-keygen --out <file>
 *   node roster_tool.js relay-keygen    --out <file>
 *   node roster_tool.js sign --operator <key-file> --relays <list-file> --out <roster.json>
 *   node roster_tool.js verify --operator-pubkey <hex> --roster <roster.json>
 *
 * The relays list file is one relay pubkeyHex per line (blank
 * lines and #-comments ignored) or a JSON array of hex strings.
 */
'use strict';
const fs = require('fs');
const crypto = require('crypto');

const ED25519_SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');

function pubHexFromKey(publicKey) {
  return publicKey.export({ format: 'der', type: 'spki' }).slice(-32).toString('hex');
}
function pubKeyFromHex(hex) {
  return crypto.createPublicKey({
    key: Buffer.concat([ED25519_SPKI_PREFIX, Buffer.from(hex, 'hex')]),
    format: 'der', type: 'spki',
  });
}
function relayIdFor(pubHex) { return 'relay-' + pubHex.slice(0, 12); }
function isPubHex(s) { return typeof s === 'string' && /^[0-9a-f]{64}$/.test(s); }

// Canonical JSON: object keys sorted recursively, compact
// separators. MUST match relay.js byte-for-byte.
function canonicalize(value) {
  if (Array.isArray(value)) return '[' + value.map(canonicalize).join(',') + ']';
  if (value && typeof value === 'object') {
    return '{' + Object.keys(value).sort()
      .map((k) => JSON.stringify(k) + ':' + canonicalize(value[k])).join(',') + '}';
  }
  return JSON.stringify(value);
}
function rosterSigningBytes(roster) {
  const rest = { ...roster };
  delete rest.signature;
  return Buffer.from(canonicalize(rest), 'utf8');
}

function fail(msg) {
  console.error(`roster_tool: ${msg}`);
  process.exit(2);
}
function parseFlags(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) out[a.slice(2)] = argv[++i];
    else fail(`unexpected argument ${a}`);
  }
  return out;
}
function need(flags, name, cmd) {
  if (!flags[name]) fail(`${cmd} requires --${name} <value>`);
  return flags[name];
}

function writeKeyFile(outPath, kind) {
  if (fs.existsSync(outPath)) {
    fail(`${outPath} already exists — refusing to overwrite a key file`);
  }
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const pubHex = pubHexFromKey(publicKey);
  const privHex = privateKey.export({ format: 'der', type: 'pkcs8' }).toString('hex');
  fs.writeFileSync(outPath, JSON.stringify({ pubkeyHex: pubHex, privateKeyHex: privHex }, null, 2) + '\n',
    { mode: 0o600 });
  // writeFileSync's mode applies at creation; enforce 0600 even
  // under a permissive umask race by chmod after the write.
  fs.chmodSync(outPath, 0o600);
  return pubHex;
}
function loadPrivateKey(file, what) {
  let data;
  try { data = JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) { fail(`cannot read ${what} key file ${file}: ${e.message}`); }
  if (!data || typeof data.privateKeyHex !== 'string') {
    fail(`${file} is not a key file (no privateKeyHex)`);
  }
  try {
    return crypto.createPrivateKey({
      key: Buffer.from(data.privateKeyHex, 'hex'), format: 'der', type: 'pkcs8',
    });
  } catch (e) { fail(`cannot load private key from ${file}: ${e.message}`); }
  return null; // unreachable
}
function readRelaysList(file) {
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); }
  catch (e) { fail(`cannot read relays list ${file}: ${e.message}`); }
  let entries = null;
  const trimmed = raw.trim();
  if (trimmed.startsWith('[')) {
    try { entries = JSON.parse(trimmed); } catch (e) { fail(`relays list ${file} is not valid JSON: ${e.message}`); }
  } else {
    entries = trimmed.split('\n').map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#'));
  }
  if (!Array.isArray(entries) || entries.length === 0) {
    fail(`relays list ${file} has no entries`);
  }
  for (const e of entries) {
    if (!isPubHex(e)) fail(`relays list entry is not a 64-hex public key: ${JSON.stringify(e)}`);
  }
  return [...new Set(entries)];
}

function main() {
  const [cmd, ...rest] = process.argv.slice(2);
  const flags = parseFlags(rest);
  if (cmd === 'operator-keygen') {
    const out = need(flags, 'out', cmd);
    const pubHex = writeKeyFile(out, 'operator');
    // ONLY the public key is printed — the private half never leaves the file.
    console.log(pubHex);
  } else if (cmd === 'relay-keygen') {
    const out = need(flags, 'out', cmd);
    const pubHex = writeKeyFile(out, 'relay');
    console.log(`${relayIdFor(pubHex)} ${pubHex}`);
  } else if (cmd === 'sign') {
    const opFile = need(flags, 'operator', cmd);
    const listFile = need(flags, 'relays', cmd);
    const out = need(flags, 'out', cmd);
    const opKey = loadPrivateKey(opFile, 'operator');
    const relays = readRelaysList(listFile);
    const roster = { version: 1, issued: new Date().toISOString(), relays };
    const sig = crypto.sign(null, rosterSigningBytes(roster), opKey).toString('hex');
    const signed = { ...roster, signature: sig };
    fs.writeFileSync(out, JSON.stringify(signed, null, 2) + '\n');
    console.log(`signed roster with ${relays.length} relay(s) -> ${out}`);
  } else if (cmd === 'verify') {
    const opPub = need(flags, 'operator-pubkey', cmd);
    const rosterFile = need(flags, 'roster', cmd);
    if (!isPubHex(opPub)) fail('--operator-pubkey must be a 64-hex Ed25519 public key');
    let roster;
    try { roster = JSON.parse(fs.readFileSync(rosterFile, 'utf8')); }
    catch (e) { fail(`cannot read roster ${rosterFile}: ${e.message}`); }
    if (!roster || !Array.isArray(roster.relays)
      || typeof roster.signature !== 'string'
      || !roster.relays.every(isPubHex)) {
      console.error('roster verify: FAIL — roster is malformed');
      process.exit(1);
    }
    let ok = false;
    try {
      ok = crypto.verify(null, rosterSigningBytes(roster),
        pubKeyFromHex(opPub), Buffer.from(roster.signature, 'hex'));
    } catch (e) { ok = false; }
    if (ok) {
      console.log(`roster verify: OK (${roster.relays.length} relays, issued ${roster.issued})`);
      process.exit(0);
    }
    console.error('roster verify: FAIL — signature does not verify against the operator public key');
    process.exit(1);
  } else {
    console.error('usage: node roster_tool.js <operator-keygen|relay-keygen|sign|verify> [flags]');
    console.error('  operator-keygen --out <file>');
    console.error('  relay-keygen    --out <file>');
    console.error('  sign --operator <key-file> --relays <list-file> --out <roster.json>');
    console.error('  verify --operator-pubkey <hex> --roster <roster.json>');
    process.exit(2);
  }
}
main();
