'use strict';
/* ================= ASCENSION33 — UI ================= */
const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r=>setTimeout(r,ms));

const App = {
  P:null, combat:null, missionIdx:0,
  ui:{ mode:null, tech:null, input:false, selected:'kael' },
  logRendered:0, boonChoices:[],
};

const SAVE_KEY = 'asc33save';

/* ---------- persistent state ---------- */
function freshP(){
  return { maxhp:75, hp:75, anchorMax:1, anchorCharges:1, techniques:[],
           qEdge:false, ward:false, vesperHp:50, vesperBond:0, boonsTaken:[] };
}
function saveGame(){
  try{ localStorage.setItem(SAVE_KEY, JSON.stringify({m:App.missionIdx, P:App.P})); }catch(e){}
}
function loadSave(){
  try{ const s = JSON.parse(localStorage.getItem(SAVE_KEY)); return (s && s.P) ? s : null; }catch(e){ return null; }
}
function clearSave(){ try{ localStorage.removeItem(SAVE_KEY); }catch(e){} }

/* ---------- screens ---------- */
function show(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  $(id).classList.add('active');
  window.scrollTo(0,0);
  // v6: stop the combat reel when leaving the combat screen so it never
  // plays behind another screen (or after quitting to title).
  const gc = $('grid-cine');
  if(gc && id!=='scr-combat') gc.pause();
}
function openModal(title, bodyHTML, buttons){
  $('modal-title').textContent = title;
  $('modal-body').innerHTML = bodyHTML;
  const bb = $('modal-btns'); bb.innerHTML = '';
  buttons.forEach(b=>{
    const btn = document.createElement('button');
    btn.className = 'btn' + (b.primary ? ' primary' : '');
    btn.textContent = b.label;
    btn.onclick = ()=>{ closeModal(); b.fn && b.fn(); };
    bb.appendChild(btn);
  });
  $('modal').classList.add('active');
}
function closeModal(){ $('modal').classList.remove('active'); }

function showHowto(){
  const html = HOWTO.map(h=>'<div class="howrow"><div class="howh">'+h[0]+'</div><div class="howb">'+h[1]+'</div></div>').join('');
  openModal('HOW TO PLAY', '<div class="howto">'+html+'</div>', [{label:'CLOSE', primary:true}]);
}

/* ---------- title / story / boon / end ---------- */
function toTitle(){
  show('scr-title');
  $('btn-continue').style.display = loadSave() ? '' : 'none';
}
function newGame(){
  clearSave();
  App.P = freshP(); App.missionIdx = 0;
  showStory();
}
function continueGame(){
  const s = loadSave(); if(!s) return;
  App.P = s.P; App.missionIdx = Math.min(s.m, MISSIONS.length-1);
  showStory();
}
function showStory(){
  const m = MISSIONS[App.missionIdx];
  $('story-kicker').textContent = 'BOOK 1 \u00b7 THE DESYNC \u00b7 '+(App.missionIdx+1)+' / '+MISSIONS.length;
  $('story-title').textContent = m.name;
  $('story-body').innerHTML = m.story.map(p=>'<p>'+p+'</p>').join('');
  $('story-tip').innerHTML = '<span class="tiplabel">FIELD BRIEF</span> '+m.tip;
  show('scr-story');
  const cine = $('story-cine');
  cine.poster = 'img/stage/'+m.cine+'.jpg';
  cine.src = 'cine/'+m.cine+'.mp4';
  cine.load();
  // Start playback only once the screen is visible: play() issued while the
  // story screen is display:none never starts in Chrome. Retry once shortly
  // after, in case the first attempt lands before layout.
  const kick = ()=>{ const pr = cine.play(); if(pr && pr.catch) pr.catch(()=>setTimeout(()=>{ const r2 = cine.play(); if(r2 && r2.catch) r2.catch(()=>{}); }, 300)); };
  requestAnimationFrame(kick);
}
function deploy(){
  App.P.hp = App.P.maxhp;
  App.P.anchorCharges = App.P.anchorMax;
  App.combat = new Combat(MISSIONS[App.missionIdx], App.P);
  const cineKey = MISSIONS[App.missionIdx].cine;
  // v6: the mission's stage still is the wrap's background (fallback if the
  // reel fails); the reel itself plays behind the grid.
  $('grid-wrap').style.backgroundImage = "url('img/stage/"+cineKey+".jpg')";
  App.ui = { mode:null, tech:null, input:false, selected:'kael' };
  App.logRendered = 0;
  App.runId = (App.runId||0)+1;
  show('scr-combat');
  $('combat-mission').textContent = MISSIONS[App.missionIdx].name;
  // v6: the combat grid plays the mission's live-action reel as its moving
  // backdrop, so gameplay looks like the reels. Same ordering rule as the
  // story cinematic: start playback only once the screen is visible.
  const gc = $('grid-cine');
  gc.poster = 'img/stage/'+cineKey+'.jpg';
  gc.src = 'cine/'+cineKey+'.mp4';
  gc.load();
  const kick = ()=>{ const pr = gc.play(); if(pr && pr.catch) pr.catch(()=>setTimeout(()=>{ const r2 = gc.play(); if(r2 && r2.catch) r2.catch(()=>{}); }, 300)); };
  requestAnimationFrame(kick);
  renderAll();
  beginPlayerTurn();
}

function availableBoons(){
  const P = App.P;
  const pool = BOONS.filter(b=>{
    if(b.once && P.boonsTaken.includes(b.id)) return false;
    if(b.tech && TECH_ORDER.every(t=>P.techniques.includes(t))) return false;
    return true;
  });
  const picks = [];
  const cpool = pool.slice();
  while(picks.length < 3 && cpool.length){
    picks.push(cpool.splice(Math.floor(Math.random()*cpool.length), 1)[0]);
  }
  // fallback fillers (repeatable)
  const fillers = [BOONS[0], BOONS[1], BOONS[5]];
  let fi = 0;
  while(picks.length < 3){ picks.push(fillers[fi++ % fillers.length]); }
  return picks;
}
function showBoons(){
  App.boonChoices = availableBoons();
  const wrap = $('boon-cards'); wrap.innerHTML = '';
  App.boonChoices.forEach((b,i)=>{
    const d = document.createElement('div');
    d.className = 'boon-card';
    d.innerHTML = '<div class="boon-name">'+b.name+'</div><div class="boon-desc">'+b.desc+'</div><div class="boon-pick">SALVAGE</div>';
    d.onclick = ()=>takeBoon(i);
    wrap.appendChild(d);
  });
  show('scr-boon');
}
function takeBoon(i){
  const b = App.boonChoices[i]; const P = App.P;
  P.boonsTaken.push(b.id);
  let learned = '';
  if(b.id==='hp'){ P.maxhp += 25; }
  else if(b.id==='anchor'){ P.anchorMax = Math.min(5, P.anchorMax+1); }
  else if(b.id==='qedge'){ P.qEdge = true; }
  else if(b.id==='ward'){ P.ward = true; }
  else if(b.id==='vesper'){ P.vesperBond += 1; P.vesperHp += 20; }
  else if(b.id==='tech'){
    const un = TECH_ORDER.filter(t=>!P.techniques.includes(t));
    if(un.length){ const t = un[Math.floor(Math.random()*un.length)]; P.techniques.push(t); learned = TECHNIQUES[t].name; }
  }
  App.missionIdx++;
  saveGame();
  showStory();
}
function showEnding(){
  clearSave();
  $('end-body').innerHTML = ENDING.map(p=>'<p>'+p+'</p>').join('');
  show('scr-end');
}

/* ---------- combat rendering ---------- */
function kael(){ return App.combat.kael; }
function selUnit(){
  const c = App.combat;
  const s = App.ui.selected;
  if(s && typeof s === 'object' && s.alive) return s;
  if(s==='vesper' && c.vesper && c.vesper.alive) return c.vesper;
  return c.kael;
}
function renderAll(){
  renderGrid(); renderBar(); renderPanel(); renderQ(); renderLog(); renderDesyncFx();
}
function renderGrid(){
  const c = App.combat, g = $('grid'); g.innerHTML = '';
  const hl = highlightCells();
  for(let y=0;y<3;y++) for(let x=0;x<3;x++){
    const cell = document.createElement('div');
    cell.className = 'cell'; cell.dataset.x = x; cell.dataset.y = y;
    const u = c.at(x,y);
    if(u){
      const t = document.createElement('div');
      t.className = 'token ' + u.side + (u.hero?' hero':'') + (u.node?' node':'') + (u.etype==='prime'?' prime':'');
      if(u===c.current() && !c.over) t.classList.add('active-turn');
      t.innerHTML = '<img class="timg" src="img/'+imgFor(u)+'" alt="">' +
        '<div class="toverlay"><div class="hpbar"><div class="hpfill" style="width:'+Math.max(0,Math.round(100*u.hp/u.maxhp))+'%"></div></div>' +
        '<div class="tname">'+u.name.split(' ')[0]+'</div></div>';
      if(u.hero) t.innerHTML += '<div class="stancebadge">'+u.stance[0].toUpperCase()+'</div>';
      if(u===selUnit()) t.classList.add('selected');
      cell.appendChild(t);
      cell.onclick = ()=>onTokenClick(u);
    } else {
      cell.onclick = ()=>onCellClick(x,y);
    }
    const key = x+','+y;
    if(hl.move.has(key)) cell.classList.add('hl-move');
    if(hl.target.has(key)) cell.classList.add('hl-target');
    g.appendChild(cell);
  }
  // floaters
  (c.fx||[]).forEach(f=>{
    if(f.type!=='dmg') return;
    const u = c.units.find(v=>v.id===f.id);
    if(!u) return;
    const cells = g.children;
    const cell = cells[u.y*3+u.x];
    if(cell){
      const s = document.createElement('div');
      s.className = 'floater'; s.textContent = '-'+f.amt;
      cell.appendChild(s); setTimeout(()=>s.remove(), 950);
    }
  });
  c.fx = [];
}
function imgFor(u){
  if(u.hero) return 'kael.jpg';
  if(u.node) return 'node.jpg';
  if(u.etype==='prime') return 'prime.jpg';
  if(u.etype==='elite') return 'elite.jpg';
  if(u.etype==='enforcer') return 'enforcer.jpg';
  if(u.etype==='construct') return 'construct.jpg';
  if(u.etype==='drone') return 'drone.jpg';
  if(u.auto) return 'vesper.jpg';
  return 'construct.jpg';
}
function highlightCells(){
  const c = App.combat, move = new Set(), target = new Set();
  const u = selUnit();
  if(!App.ui.input || c.over || !u || !u.alive) return {move,target};
  const cur = c.current();
  if(cur !== u || u.auto) return {move,target};
  const m = App.ui.mode;
  if(m==='move'){
    c.adj(u).forEach(cl=>{ if(!c.at(cl.x,cl.y)) move.add(cl.x+','+cl.y); });
  } else if(m==='strike' || m==='tech:rend'){
    c.adj(u).forEach(cl=>{ const t=c.at(cl.x,cl.y); if(t && t.side!==u.side) target.add(cl.x+','+cl.y); });
  } else if(m==='tech:phase'){
    for(let y=0;y<3;y++) for(let x=0;x<3;x++) if(!c.at(x,y)) move.add(x+','+y);
  }
  return {move,target};
}
function renderBar(){
  const c = App.combat, k = kael();
  const cur = c.current();
  const canAct = App.ui.input && !c.over && cur===k && k.alive;
  const bar = $('actionbar'); bar.innerHTML = '';
  const P = App.P;
  const qd = q => Math.max(2, q-(P.qEdge?1:0));
  function btn(label, sub, fn, dis, active){
    const b = document.createElement('button');
    b.className = 'abtn'+(active?' active':'');
    b.innerHTML = '<span class="alabel">'+label+'</span>'+(sub?'<span class="asub">'+sub+'</span>':'');
    b.disabled = !!dis;
    b.onclick = fn;
    bar.appendChild(b); return b;
  }
  btn('MOVE', qd(k.stance==='flow'?2:4)+'Q', ()=>setMode('move'), !canAct, App.ui.mode==='move');
  btn('STRIKE', qd(6)+'Q', ()=>setMode('strike'), !canAct, App.ui.mode==='strike');
  P.techniques.forEach(t=>{
    const T = TECHNIQUES[t];
    const isTargeted = (t==='rend'||t==='phase');
    btn(T.name.toUpperCase(), qd(T.q)+'Q', ()=>setMode(isTargeted?('tech:'+t):null, t, ()=>doPlayerTech(t)),
        !canAct, App.ui.tech===t);
  });
  const st = document.createElement('div'); st.className = 'stance-row';
  ['iron','ember','flow'].forEach(s=>{
    const b = document.createElement('button');
    b.className = 'sbtn'+(k.stance===s?' active':'');
    b.textContent = s.toUpperCase()+' '+qd(3)+'Q';
    b.disabled = !canAct;
    b.onclick = ()=>playerAct({kind:'stance', stance:s});
    st.appendChild(b);
  });
  bar.appendChild(st);
  const ab = document.createElement('button');
  ab.className = 'abtn anchorbtn'; ab.id = 'btn-anchor';
  ab.innerHTML = '<span class="alabel">RU\u2019YA ANCHOR</span><span class="asub">'+P.anchorCharges+' charges</span>';
  ab.disabled = !canAct || P.anchorCharges<=0;
  ab.onclick = ()=>playerAct({kind:'anchor'});
  bar.appendChild(ab);
  const cb = document.createElement('button');
  cb.className = 'abtn'; cb.innerHTML = '<span class="alabel">CANCEL</span>';
  cb.disabled = !App.ui.mode;
  cb.onclick = cancelMode;
  bar.appendChild(cb);
}
function renderPanel(){
  const u = selUnit(), c = App.combat;
  let html = '<div class="pcard"><div class="pname">'+u.name+'</div>';
  html += '<div class="php">HP '+Math.max(0,u.hp)+' / '+u.maxhp+'</div>';
  html += '<div class="hpbar big"><div class="hpfill" style="width:'+Math.max(0,Math.round(100*u.hp/u.maxhp))+'%"></div></div>';
  if(u.hero){
    html += '<div class="pstat">STANCE: <b>'+u.stance.toUpperCase()+'</b>'+(u.flow>0?' · FLOW x'+(u.flow+1):'')+(u.guard?' · <span class="good">GUARDED</span>':'')+'</div>';
    html += '<div class="pstat">DMG '+u.dmg[0]+'\u2013'+u.dmg[1]+' · Q-EDGE '+(App.P.qEdge?'ON':'OFF')+'</div>';
  } else if(u.auto){
    html += '<div class="pstat">ALLY (AI) · DMG '+u.dmg[0]+'\u2013'+u.dmg[1]+' · STABILIZE '+u.stab+' left</div>';
  } else if(u.node){
    html += '<div class="pstat">MESH NODE · pulses 5 dmg every 33Q</div>';
  } else {
    const d = ENEMIES[u.etype]||{dmg:['?','?']};
    html += '<div class="pstat">DMG '+(u.dmg?u.dmg[0]+'\u2013'+u.dmg[1]:'')+(u.etype==='enforcer'?' · SUPPRESS':u.etype==='elite'?' · PULSE':u.etype==='prime'?' · SLAM/SUMMON':'')+'</div>';
  }
  html += '</div>';
  $('unitcard').innerHTML = html;
  // desync
  const k = kael(), d = k.desync;
  $('desync-fill').style.width = d+'%';
  $('desync-num').textContent = Math.round(d);
  const st = d>=70?'HEMORRHAGING':d>=40?'FRAYING':'STABLE';
  $('desync-state').textContent = st + (k.glitchMarkUntil>c.clock?' · GLITCH-MARKED':'');
  $('desync-state').className = 'dstate lv'+(d>=70?2:d>=40?1:0);
}
function renderQ(){
  const c = App.combat;
  $('q-clock').textContent = 'Q ' + c.clock;
  const toSurge = c.nextSurge - c.clock;
  $('q-surge').textContent = 'SURGE IN ' + toSurge + 'Q';
  $('q-surge').className = toSurge<=8 ? 'surge-warn' : '';
  const ol = $('qorder'); ol.innerHTML = '';
  c.order(6).forEach(u=>{
    const li = document.createElement('li');
    li.className = 'qchip '+u.side + (u===c.current()?' cur':'');
    li.textContent = u.name.split(' ')[0] + ' \u00b7 Q' + u.q;
    ol.appendChild(li);
  });
}
function renderLog(){
  const c = App.combat, box = $('clog');
  for(let i=App.logRendered;i<c.log.length;i++){
    const e = c.log[i];
    const d = document.createElement('div');
    d.className = 'logline '+e.cls; d.textContent = e.text;
    box.appendChild(d);
  }
  App.logRendered = c.log.length;
  box.scrollTop = box.scrollHeight;
}
function renderDesyncFx(){
  const lvl = App.combat.desyncLevel();
  document.body.dataset.desync = lvl;
  $('glitch-overlay').className = lvl>0 ? 'on lv'+lvl : '';
}

/* ---------- input ---------- */
function setMode(mode, tech, instantFn){
  const c = App.combat;
  if(!App.ui.input || c.over) return;
  if(mode && App.ui.mode===mode){ cancelMode(); return; }
  App.ui.selected = 'kael';
  App.ui.mode = mode; App.ui.tech = tech||null;
  if(instantFn){ instantFn(); return; }
  renderAll();
}
function cancelMode(){ App.ui.mode = null; App.ui.tech = null; renderAll(); }
function onTokenClick(u){
  if(App.ui.mode){ // targeting an occupied cell
    const c = App.combat, m = App.ui.mode;
    const me = kael();
    if(m==='strike' || m==='tech:rend'){
      const ok = c.adj(me).some(cl=>cl.x===u.x&&cl.y===u.y) && u.side!==me.side;
      if(ok){ m==='strike' ? playerAct({kind:'strike',x:u.x,y:u.y}) : doPlayerTech(App.ui.tech, u.x, u.y); }
    }
    return;
  }
  App.ui.selected = u; // store unit directly; selUnit() validates
  renderAll();
}
function onCellClick(x,y){
  const c = App.combat, m = App.ui.mode;
  if(!m || !App.ui.input) return;
  const u = selUnit();
  if(m==='move'){
    if(c.adj(u).some(cl=>cl.x===x&&cl.y===y) && !c.at(x,y)) playerAct({kind:'move',x,y});
  } else if(m==='tech:phase'){
    if(!c.at(x,y)) doPlayerTech('phase', x, y);
  }
}
function doPlayerTech(t, x, y){
  const needTarget = (t==='rend'||t==='phase');
  if(needTarget && (x===undefined)){
    // shouldn't happen; targeting mode handles it
    return;
  }
  playerAct({kind:'tech', tech:t, x, y});
  App.ui.mode = null; App.ui.tech = null;
}
function playerAct(act){
  const c = App.combat;
  if(!App.ui.input || c.over) return;
  const u = kael();
  if(c.current()!==u || !u.alive) return;
  cancelModeSilent();
  const r = c.takeTurn(u, act);
  if(!r.ok){ renderAll(); return; }
  App.ui.input = false;
  renderAll();
  if(c.over) return finishMission();
  $('phase-banner').textContent = 'MESH TURN';
  setTimeout(enemyPhase, 350);
}
function cancelModeSilent(){ App.ui.mode = null; App.ui.tech = null; }

async function enemyPhase(){
  const rid = App.runId, c = App.combat;
  while(!c.over && rid===App.runId && App.combat===c){
    const u = c.current();
    if(!u) break;
    if(u.side==='player' && !u.auto) break;
    c.aiAct(u);
    renderAll();
    await sleep(520);
  }
  if(rid!==App.runId || App.combat!==c) return; // mission was restarted
  $('phase-banner').textContent = '';
  if(c.over) return finishMission();
  beginPlayerTurn();
}
function beginPlayerTurn(){
  App.ui.input = true;
  App.ui.selected = 'kael';
  renderAll();
}

/* ---------- mission end ---------- */
function finishMission(){
  renderAll();
  const c = App.combat;
  App.ui.input = false;
  if(c.over==='win'){
    const last = App.missionIdx >= MISSIONS.length-1;
    openModal('SIGNAL SEVERED',
      '<p>'+MISSIONS[App.missionIdx].name+' complete. Desync at mission end: '+Math.round(c.kael.desync)+'.</p>'+
      (last?'':'<p>Salvage the wreckage \u2014 choose a boon.</p>'),
      [{label: last?'FINISH BOOK 1':'SALVAGE', primary:true, fn:()=>{ last?showEnding():showBoons(); }}]);
  } else {
    openModal('KAEL HAS FALLEN',
      '<p>The mesh reclaims its anomaly. But deletion is just another kind of signal.</p><p>Retry the mission \u2014 your boons are kept.</p>',
      [{label:'RETRY MISSION', primary:true, fn:()=>deploy()},
       {label:'ABANDON RUN', fn:()=>{ clearSave(); toTitle(); }}]);
  }
}

/* ---------- boot ---------- */
document.addEventListener('DOMContentLoaded', ()=>{
  $('btn-new').onclick = newGame;
  $('btn-continue').onclick = continueGame;
  $('btn-howto').onclick = showHowto;
  $('btn-howto2').onclick = showHowto;
  $('btn-deploy').onclick = deploy;
  $('btn-restart').onclick = ()=>{ if(confirm('Restart this mission?')) deploy(); };
  $('btn-menu').onclick = ()=>{ if(confirm('Quit to title? Progress is saved.')){ saveGame(); toTitle(); } };
  $('btn-end-title').onclick = toTitle;
  document.addEventListener('keydown', e=>{
    if(e.key==='Escape') cancelMode();
    if($('scr-combat').classList.contains('active') && App.ui.input && !App.combat.over){
      const k = e.key.toLowerCase();
      if(k==='1') setMode('move');
      else if(k==='2') setMode('strike');
    }
  });
  $('grid').addEventListener('contextmenu', e=>{ e.preventDefault(); cancelMode(); });
  // Mission cinematic: tap the video to start/pause it (covers any browser
  // that still refuses autoplay). Surface a real load error in the label.
  const cine = $('story-cine');
  cine.addEventListener('click', ()=>{ if(cine.paused) cine.play(); else cine.pause(); });
  cine.addEventListener('error', ()=>{
    const e = cine.error;
    $('story-cine-label').textContent = 'MISSION CINEMATIC — VIDEO ERROR ' + (e ? e.code : '?');
  });
  toTitle();
});
